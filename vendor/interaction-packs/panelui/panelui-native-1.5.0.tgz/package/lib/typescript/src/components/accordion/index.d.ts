/**
 * Accordion — collapsible sections.
 *
 * Split into Item / Trigger / Indicator / Content so a section header can hold
 * anything — a badge, a price, a second line — instead of only a string. The
 * chevron rotates rather than swapping glyphs, and the panel expands through a
 * layout transition, both on the UI thread.
 *
 * `selectionMode` decides whether opening one section closes the others, which
 * also changes the shape of `value`: a string when single, an array when
 * multiple.
 *
 * With the operating system set to reduce motion the section arrives at its new
 * height and the chevron at its new angle without travelling to either. The
 * disclosure is the point and it still happens; the movement is what goes.
 *
 * A closed section costs nothing, because its body is unmounted. That is the
 * right default and the wrong one for a body with state in it: a half-filled
 * form, a list scrolled to the middle, a video part-way through. Collapsing
 * such a section throws that away and reopening it starts over. `keepMounted`
 * is the way out — the body stays mounted and is hidden from layout instead,
 * so it takes up no room, the same layout transition carries the change, and
 * everything inside is exactly where it was left.
 */
import { type ReactNode } from 'react';
import { type PressableProps, type ViewProps } from 'react-native';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
export type AccordionVariant = 'default' | 'surface' | 'separated' | 'bordered' | 'ghost';
export type AccordionSelectionMode = 'single' | 'multiple';
export interface AccordionProps extends ViewProps {
    className?: string;
    variant?: AccordionVariant;
    /** `single` collapses the open item when another opens. */
    selectionMode?: AccordionSelectionMode;
    /** Expanded item value(s), controlled. */
    value?: string | string[];
    defaultValue?: string | string[];
    onValueChange?: (value: string | string[]) => void;
    /** Hide the hairlines drawn between items. */
    hideSeparator?: boolean;
    /**
     * Keep every body mounted while its section is closed, so state inside it —
     * a part-filled form, a scroll position, a running animation — survives being
     * collapsed. Costs the render of every section up front; set it per section
     * on `Accordion.Content` instead when only one of them needs it.
     */
    keepMounted?: boolean;
    children?: ReactNode;
}
export interface AccordionItemProps extends ViewProps {
    className?: string;
    /** Identifies this item in the accordion's value. */
    value: string;
    isDisabled?: boolean;
    children?: ReactNode;
}
export interface AccordionTriggerProps extends Omit<PressableProps, 'children'> {
    className?: string;
    children?: ReactNode;
}
export interface AccordionIndicatorProps extends ViewProps {
    className?: string;
    /** Replaces the default chevron. */
    children?: ReactNode;
}
export interface AccordionContentProps extends ViewProps {
    className?: string;
    /**
     * Stay mounted while closed instead of unmounting, so state inside the body
     * survives the section being collapsed. Overrides the accordion's own
     * setting, either way round.
     */
    keepMounted?: boolean;
    children?: ReactNode;
}
export declare const Accordion: import("react").ForwardRefExoticComponent<AccordionProps & import("react").RefAttributes<ViewRef>> & {
    Item: import("react").ForwardRefExoticComponent<AccordionItemProps & import("react").RefAttributes<ViewRef>>;
    Trigger: import("react").ForwardRefExoticComponent<AccordionTriggerProps & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Indicator: import("react").ForwardRefExoticComponent<AccordionIndicatorProps & import("react").RefAttributes<ViewRef>>;
    Content: import("react").ForwardRefExoticComponent<AccordionContentProps & import("react").RefAttributes<ViewRef>>;
};
//# sourceMappingURL=index.d.ts.map