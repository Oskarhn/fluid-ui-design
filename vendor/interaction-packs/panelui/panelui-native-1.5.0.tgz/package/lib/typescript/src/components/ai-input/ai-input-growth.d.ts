/**
 * How tall the composer's field is allowed to be.
 *
 * Separated from the component because it is the one piece of AI Input with a
 * right answer that can be checked without a device: a composer that opens at
 * the wrong height, or grows past where it was told to stop, is a bug nobody
 * notices until the send button is off the bottom of the screen.
 *
 * ## Bounds, not a measured height
 *
 * The obvious way to grow a field is to measure its content and set a height
 * from it. That is a loop with a different answer on each platform — the
 * measurement reports the text's height on one and the clipped height of the
 * box we just set on another, where the field can then never grow at all.
 *
 * So nothing is measured. The field is given a floor and a ceiling and left to
 * size itself between them, which is the layout engine's job and which it does
 * without telling anybody. Past the ceiling a multiline field scrolls its own
 * content, and that is the whole mechanism.
 */
/** Type size and the leading it is given, per `size`. */
export declare const AI_INPUT_METRICS: {
    readonly sm: {
        readonly fontSize: 15;
        readonly lineHeight: 20;
        readonly padding: 10;
    };
    readonly md: {
        readonly fontSize: 16;
        readonly lineHeight: 22;
        readonly padding: 12;
    };
    readonly lg: {
        readonly fontSize: 17;
        readonly lineHeight: 24;
        readonly padding: 14;
    };
};
export type AIInputSize = keyof typeof AI_INPUT_METRICS;
export interface GrowthMetrics {
    lineHeight: number;
    padding: number;
}
/** The box a whole number of lines asks for: the lines, plus both paddings. */
export declare function heightForLines(metrics: GrowthMetrics, lines: number): number;
export interface GrowthBounds {
    minHeight: number;
    maxHeight: number;
}
/**
 * The floor and ceiling a field grows between.
 *
 * At least one line, so an empty composer is the size of an empty composer.
 * Never below the floor, so a `maxRows` under `minRows` — a caller
 * contradicting itself — resolves to the height that was asked for outright
 * rather than to one shorter than the field was told to open at.
 */
export declare function growthBounds(metrics: GrowthMetrics, minRows: number, maxRows: number): GrowthBounds;
//# sourceMappingURL=ai-input-growth.d.ts.map