/**
 * Alert — a status message with an optional leading status icon.
 *
 * The indicator derives its icon and colour from the variant, so a success
 * alert cannot end up with a warning icon. Pass `icon` on the root to override
 * it everywhere, or give `Alert.Indicator` children to override one.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
declare const alertVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        default: {
            root: string;
            title: string;
        };
        info: {
            root: string;
            title: string;
        };
        success: {
            root: string;
            title: string;
        };
        warning: {
            root: string;
            title: string;
        };
        destructive: {
            root: string;
            title: string;
        };
    };
}, {
    root: string;
    indicator: string;
    content: string;
    title: string;
    description: string;
}, undefined, {
    variant: {
        default: {
            root: string;
            title: string;
        };
        info: {
            root: string;
            title: string;
        };
        success: {
            root: string;
            title: string;
        };
        warning: {
            root: string;
            title: string;
        };
        destructive: {
            root: string;
            title: string;
        };
    };
}, {
    root: string;
    indicator: string;
    content: string;
    title: string;
    description: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        default: {
            root: string;
            title: string;
        };
        info: {
            root: string;
            title: string;
        };
        success: {
            root: string;
            title: string;
        };
        warning: {
            root: string;
            title: string;
        };
        destructive: {
            root: string;
            title: string;
        };
    };
}, {
    root: string;
    indicator: string;
    content: string;
    title: string;
    description: string;
}>>;
export interface AlertProps extends ViewProps, VariantProps<typeof alertVariants> {
    className?: string;
    /**
     * Leading element rendered before the content.
     *
     * @deprecated Prefer `<Alert.Indicator>`, which picks a status icon for you.
     * Still honoured so v0.2 call sites keep rendering.
     */
    icon?: ReactNode;
    children?: ReactNode;
}
export interface AlertIndicatorProps extends ViewProps {
    className?: string;
    /** Overrides the size/colour of the default status icon. */
    iconProps?: {
        size?: number;
        color?: string;
    };
    /** Replaces the default status icon entirely. */
    children?: ReactNode;
}
export declare const Alert: import("react").ForwardRefExoticComponent<AlertProps & import("react").RefAttributes<ViewRef>> & {
    /** @optional Status icon rendered as the leading visual element. */
    Indicator: import("react").ForwardRefExoticComponent<AlertIndicatorProps & import("react").RefAttributes<ViewRef>>;
    /** @optional Wrapper for title and description. */
    Content: import("react").ForwardRefExoticComponent<ViewProps & {
        className?: string;
    } & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Description: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map