/**
 * Attachment — a file, with its upload life.
 *
 * A file in a chat composer or an upload list is the same row shape `Item`
 * already draws — media, a name, a size, a remove button — so this is that row,
 * not a second one. What it adds is the part `Item` has no opinion on: the
 * file's *state*. A file is picked, then uploading, then processing, then done
 * (or failed), and each of those has to look different or the user cannot tell
 * a stuck upload from a finished one.
 *
 * ```tsx
 * <Attachment state="uploading">
 *   <Attachment.Media><FileIcon /></Attachment.Media>
 *   <Attachment.Content>
 *     <Attachment.Title>report.pdf</Attachment.Title>
 *     <Attachment.Description>PDF · 2.4 MB</Attachment.Description>
 *   </Attachment.Content>
 *   <Attachment.Actions>
 *     <Attachment.Action aria-label="Cancel"><XIcon size={14} /></Attachment.Action>
 *   </Attachment.Actions>
 * </Attachment>
 * ```
 *
 * While uploading or processing the title shimmers — the same sweep the rest of
 * the library uses for "in progress" — and an optional bar tracks `progress`.
 * A failed file tints its name and description in the destructive colour, which
 * carries the state without relying on an icon nobody reads.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type AnimatedPressableProps } from '../../primitives/animated-pressable.js';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
export type AttachmentState = 'idle' | 'uploading' | 'processing' | 'error' | 'done';
type AttachmentSize = 'default' | 'sm' | 'xs';
export interface AttachmentProps extends Omit<AnimatedPressableProps, 'children' | 'disabled'> {
    className?: string;
    /**
     * Where the file is in its life. `uploading`/`processing` shimmer the name;
     * `error` tints the row destructive. Default `done`.
     */
    state?: AttachmentState;
    /** Row density, passed through to the underlying Item. */
    size?: AttachmentSize;
    /** Stack the row into a card — for a horizontal group of thumbnails. */
    orientation?: 'horizontal' | 'vertical';
    /** Upload progress 0–1. Draws a thin bar along the bottom while busy. */
    progress?: number;
    disabled?: boolean;
    children?: ReactNode;
}
export interface AttachmentGroupProps extends ViewProps {
    className?: string;
    orientation?: 'horizontal' | 'vertical';
    children?: ReactNode;
}
export interface AttachmentMediaProps extends ViewProps {
    className?: string;
    /** `icon` frames it in a tile; `image` clips it for a thumbnail. */
    variant?: 'default' | 'icon' | 'image';
    children?: ReactNode;
}
export interface AttachmentContentProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface AttachmentTitleProps extends TextProps {
    className?: string;
    children?: ReactNode;
}
export interface AttachmentDescriptionProps extends TextProps {
    className?: string;
    children?: ReactNode;
}
export interface AttachmentActionsProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface AttachmentActionProps extends Omit<AnimatedPressableProps, 'children'> {
    className?: string;
    accessibilityLabel: string;
    children?: ReactNode;
}
export declare const Attachment: import("react").ForwardRefExoticComponent<AttachmentProps & import("react").RefAttributes<ViewRef>> & {
    Group: import("react").ForwardRefExoticComponent<AttachmentGroupProps & import("react").RefAttributes<ViewRef>>;
    Media: import("react").ForwardRefExoticComponent<AttachmentMediaProps & import("react").RefAttributes<ViewRef>>;
    Content: import("react").ForwardRefExoticComponent<AttachmentContentProps & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<AttachmentTitleProps & import("react").RefAttributes<TextRef>>;
    Description: import("react").ForwardRefExoticComponent<AttachmentDescriptionProps & import("react").RefAttributes<TextRef>>;
    Actions: import("react").ForwardRefExoticComponent<AttachmentActionsProps & import("react").RefAttributes<ViewRef>>;
    Action: import("react").ForwardRefExoticComponent<AttachmentActionProps & import("react").RefAttributes<ViewRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map