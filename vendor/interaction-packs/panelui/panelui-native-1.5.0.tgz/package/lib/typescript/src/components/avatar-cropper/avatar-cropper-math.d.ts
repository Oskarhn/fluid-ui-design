/**
 * The geometry behind the avatar cropper, kept apart from the component.
 *
 * The mask stays fixed in the middle of the canvas and the photo moves under
 * it, so everything here is one question asked different ways: where is the
 * mask, measured in the photo's own frame? Clamping asks it to keep the mask
 * on the photo — or, when the photo may be smaller than the mask, the photo
 * inside the mask — and the export asks it to find the same square in the
 * photo's pixels.
 *
 * The photo is drawn at a base size whose short side equals the mask, then
 * moved by `x`/`y`, turned by `rotation` and scaled by `scale` about its own
 * centre — the order React Native applies `translate`, `rotate`, `scale` in a
 * transform. Every function runs on the UI thread inside a gesture or an
 * animated style, so each is a worklet, and none touches React Native, which
 * is what lets the contract tests run them in Node.
 */
export type CropShape = 'circle' | 'squircle' | 'square';
export interface Size {
    width: number;
    height: number;
}
/** Where the photo sits under the mask. Rotation is in degrees, clockwise. */
export interface CropState {
    x: number;
    y: number;
    scale: number;
    rotation: number;
}
/** The fixed parts: the mask's side, and the photo's size at a scale of 1. */
export interface CropFrame {
    mask: number;
    image: Size;
}
/** A crop in the source's pixels, after the source is turned by `rotation`. */
export interface SourceCrop {
    /** The rectangle to cut, in the turned image's pixels. Always square. */
    originX: number;
    originY: number;
    width: number;
    height: number;
    /** Degrees to turn the source by first, clockwise, in (-180, 180]. */
    rotation: number;
    /** The size of the turned image the rectangle is measured in. */
    canvas: Size;
}
export declare const IDENTITY: CropState;
export declare function clamp(value: number, min: number, max: number): number;
/** An angle folded into (-180, 180]. */
export declare function normalizeDegrees(degrees: number): number;
/** The photo's size at a scale of 1: its short side exactly covers the mask. */
export declare function baseSize(source: Size, mask: number): Size;
/**
 * Half the mask's extent along the photo's axes, in screen points.
 *
 * A circle reaches the same distance whichever way the photo is turned. A
 * square turned against the photo reaches further — out to its corners — and
 * the squircle is held to its square, which contains it, so its corners can
 * never come off the photo either.
 */
export declare function maskReach(shape: CropShape, mask: number, rotation: number): number;
/**
 * The limits a crop is held to.
 *
 * With `cover` on, the photo always fills the mask. With it off, the photo may
 * also be smaller than the mask, down to `minZoom` — its long side as a
 * fraction of the mask's — and a smaller photo is kept inside the mask rather
 * than on it.
 */
export interface CropBounds {
    shape: CropShape;
    maxZoom: number;
    cover: boolean;
    minZoom: number;
}
/** The smallest scale the photo may settle at. */
export declare function minScale(bounds: CropBounds, frame: CropFrame, rotation: number): number;
/** The nearest translation inside the bounds. */
export declare function clampTranslation(state: CropState, bounds: CropBounds, frame: CropFrame): {
    x: number;
    y: number;
};
/** The state a gesture settles into: in range, and inside the bounds. */
export declare function settle(state: CropState, bounds: CropBounds, frame: CropFrame): CropState;
/**
 * True when every point of the mask is on the photo — when a crop needs no
 * background at all. Always true with `cover` on, once settled.
 */
export declare function coversMask(state: CropState, shape: CropShape, frame: CropFrame): boolean;
/** An overshoot past a bound, compressed so it gives but never runs away. */
export declare function rubberBand(overshoot: number, dimension: number): number;
/**
 * What to draw while a gesture is still going: the raw state, with anything
 * past a bound rubber-banded back towards it. At rest the raw state is already
 * settled and this returns it unchanged.
 */
export declare function present(state: CropState, bounds: CropBounds, frame: CropFrame): CropState;
/** Scale by `factor` about a point, given relative to the canvas centre. */
export declare function zoomAbout(state: CropState, factor: number, fx: number, fy: number): CropState;
/** Turn by `degrees` about a point, given relative to the canvas centre. */
export declare function rotateAbout(state: CropState, degrees: number, ax: number, ay: number): CropState;
/** The next quarter turn from wherever the photo is, in either direction. */
export declare function nextQuarterTurn(rotation: number, direction: 1 | -1): number;
/**
 * The square the mask covers, in the source's pixels.
 *
 * The export turns the source first and cuts an upright square from the
 * result, because a turned square cannot be cut directly. Turning grows the
 * canvas to the turned image's bounding box with the image still centred, and
 * a point at `p` from the source's centre lands at `R(θ)·p` from the canvas
 * centre. The mask's centre sits at `R(−θ)·(−x, −y) / scale` in the photo, so
 * after the turn it lands at `−(x, y) / scale` — the rotation cancels, and the
 * crop is the mask's offset scaled into pixels.
 */
export declare function sourceCrop(state: CropState, frame: CropFrame, source: Size, 
/** Keep the rectangle on the turned image. Off, it can reach past the edges. */
onImage?: boolean): SourceCrop;
/** The mask's outline as an SVG path, centred on (`cx`, `cy`). */
export declare function maskPath(shape: CropShape, cx: number, cy: number, mask: number): string;
//# sourceMappingURL=avatar-cropper-math.d.ts.map