/**
 * AvatarCropper — frame a photo under a circle, and get that circle back as an
 * image.
 *
 * ```tsx
 * const cropper = useRef<AvatarCropperHandle>(null);
 *
 * <AvatarCropper ref={cropper} source={photo} className="flex-1">
 *   <AvatarCropper.Canvas />
 *   <View className="flex-row justify-between p-4">
 *     <AvatarCropper.Reset />
 *     <AvatarCropper.Rotate />
 *   </View>
 * </AvatarCropper>
 *
 * const { uri } = await cropper.current!.crop({ size: 512 });
 * ```
 *
 * ## The mask stays put; the photo moves
 *
 * The mask sits in the middle of the canvas and never moves. Dragging, pinching
 * and turning all move the photo underneath it, which is what makes the result
 * predictable: the image you get back is exactly what is inside the outline
 * when you press Done. The photo is never allowed to leave part of the mask
 * empty — let go past an edge, or zoom out too far, and it springs back to the
 * nearest position that covers it. At an angle that takes extra zoom for a
 * square mask, whose corners reach further than a circle does, so the minimum
 * zoom follows the angle.
 *
 * ## One surface, three gestures at once
 *
 * Pan, pinch and rotation are recognised together, so a two-finger gesture can
 * move, zoom and turn in one motion the way a photo on a table would. Zoom and
 * turn happen about the point between the fingers, which keeps whatever is
 * under them under them.
 *
 * ## The export is the same arithmetic, in pixels
 *
 * `crop()` turns the source by the photo's angle, cuts the square the mask
 * covers and scales it to the size asked for, through the optional
 * `expo-image-manipulator`. The source is redrawn upright first: a camera photo
 * often stores its orientation as a flag rather than in its pixels, and the
 * turn and the cut both work on the raw pixels. `getCrop()` returns the same
 * rectangle without any dependency, for an app that crops on its server.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type ButtonProps } from '../button/index.js';
import { type CropShape, type SourceCrop } from './avatar-cropper-math.js';
export type { CropShape as AvatarCropperShape, SourceCrop as AvatarCrop };
/** True when `crop()` can write an image, because `expo-image-manipulator` is installed. */
export declare const hasAvatarCropperExport: boolean;
/** A photo to crop, as the picker returns it. */
export interface AvatarCropperSource {
    /** A local file or `data:` URI. */
    uri: string;
    /** Width in pixels, upright. Measured from the image when left out. */
    width?: number;
    /** Height in pixels, upright. Measured from the image when left out. */
    height?: number;
}
export interface PickAvatarImageOptions {
    /** Where the photo comes from. Default `'library'`. */
    from?: 'library' | 'camera';
    /** JPEG quality of the picked photo, 0–1. Default 1, since the crop compresses it again. */
    quality?: number;
}
/**
 * Let the user choose a photo or take one, ready to pass to `AvatarCropper`.
 *
 * Resolves `null` when the user cancels. Taking a photo asks for camera
 * permission first and throws when it is refused, so the app can explain why
 * nothing happened. Choosing from the library needs no permission. The
 * picker's own editing is left off, because the cropper is the editor.
 *
 * Needs the optional `expo-image-picker`, and throws if it is not installed.
 * In a development build the camera also needs the permission strings from
 * that package's config plugin.
 */
export declare function pickAvatarImage({ from, quality, }?: PickAvatarImageOptions): Promise<Required<AvatarCropperSource> | null>;
export interface AvatarCropResult {
    /** The cropped image, written to the app's cache directory. */
    uri: string;
    width: number;
    height: number;
}
export interface AvatarCropOptions {
    /**
     * Side of the image to write, in pixels. Default 1024. A crop with fewer
     * pixels than this is written at its own size rather than scaled up.
     */
    size?: number;
    /**
     * Default `'jpeg'`, or `'png'` when `background` is `'transparent'` so the
     * transparency survives. A crop with a background is written as PNG or
     * JPEG, so `'webp'` is written as PNG there.
     */
    format?: 'jpeg' | 'png' | 'webp';
    /** Quality, 0–1, for JPEG and WebP. Default 0.9. */
    compress?: number;
}
export interface AvatarCropperHandle {
    /**
     * Write what the mask covers to a new square image. The image is square for
     * every shape; draw it in a round `Avatar` to show it as a circle.
     *
     * Needs the optional `expo-image-manipulator`, and throws if it is not
     * installed — use `getCrop()` then. A crop with part of `background` in it
     * (only possible with `cover` off) is drawn and captured instead, and needs
     * the optional `react-native-view-shot`.
     */
    crop(options?: AvatarCropOptions): Promise<AvatarCropResult>;
    /**
     * The rectangle the mask covers, in the source's pixels, after turning the
     * source by `rotation` degrees clockwise. Null until the photo has been
     * measured and laid out. With `cover` off it can reach past the turned
     * image's edges; whatever lies outside is `background`.
     */
    getCrop(): SourceCrop | null;
    /** Turn a quarter clockwise, or a quarter back with `-1`. */
    rotate(direction?: 1 | -1): void;
    /** Back to the photo centred, unzoomed and upright. */
    reset(): void;
}
export interface AvatarCropperProps extends ViewProps {
    /** The photo. Changing it starts the crop again from the centre. */
    source: AvatarCropperSource;
    /**
     * The outline the photo is framed in. Default `'circle'`, which is how
     * `Avatar` draws it. The image written out is square for every shape.
     */
    shape?: CropShape;
    /** How far the photo can be zoomed past filling the mask. Default 5. */
    maxZoom?: number;
    /**
     * Keep the photo covering the whole outline. Default true: let go past an
     * edge, or zoom out too far, and it springs back to fill it.
     *
     * Set it to false to let the photo be zoomed out smaller than the outline,
     * down to `minZoom`. The space around it is filled with `background`, on
     * screen and in the image `crop()` writes.
     */
    cover?: boolean;
    /**
     * With `cover` off, how small the photo can get: its long side as a
     * fraction of the outline's width. Default 0.5.
     */
    minZoom?: number;
    /**
     * What fills the outline around a photo smaller than it, with `cover` off.
     * Any colour React Native accepts, or `'transparent'` — written out as PNG
     * so it stays transparent. Default: the theme's background colour.
     */
    background?: string;
    /** Space between the mask and the canvas's shorter side, in points. Default 24. */
    inset?: number;
    className?: string;
    /** `AvatarCropper.Canvas` and any controls. Left out, the canvas alone. */
    children?: ReactNode;
}
export interface AvatarCropperCanvasProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** What a screen reader calls the canvas. Default "Photo crop". */
    accessibilityLabel?: string;
}
/**
 * The photo under its mask, and the surface every gesture lands on. It fills
 * the space it is given, and the mask is drawn as large as the shorter side
 * allows, less the root's `inset`.
 */
declare function AvatarCropperCanvas({ className, accessibilityLabel, onLayout, ...props }: AvatarCropperCanvasProps): import("react").JSX.Element;
declare namespace AvatarCropperCanvas {
    var displayName: string;
}
export interface AvatarCropperRotateProps extends Omit<ButtonProps, 'onPress'> {
    /** Which way a press turns the photo. Default `'clockwise'`. */
    direction?: 'clockwise' | 'counterclockwise';
}
/** A quarter turn per press, about the middle of the mask. */
declare function AvatarCropperRotate({ direction, variant, size, children, accessibilityLabel, ...props }: AvatarCropperRotateProps): import("react").JSX.Element;
declare namespace AvatarCropperRotate {
    var displayName: string;
}
export type AvatarCropperResetProps = Omit<ButtonProps, 'onPress'>;
/** Back to the photo centred, unzoomed and upright. Labelled "Reset" unless given children. */
declare function AvatarCropperReset({ variant, size, children, ...props }: AvatarCropperResetProps): import("react").JSX.Element;
declare namespace AvatarCropperReset {
    var displayName: string;
}
export declare const AvatarCropper: import("react").ForwardRefExoticComponent<AvatarCropperProps & import("react").RefAttributes<AvatarCropperHandle>> & {
    Canvas: typeof AvatarCropperCanvas;
    Rotate: typeof AvatarCropperRotate;
    Reset: typeof AvatarCropperReset;
};
//# sourceMappingURL=index.d.ts.map