/**
 * The arithmetic behind a stack of avatars: how far each one slides under the
 * one before it, and how many faces are left over once the row is capped.
 *
 * It lives apart from the component because both answers are pure and both are
 * easy to get subtly wrong — a cap of zero that hides everybody, a `total`
 * lower than the number of faces already on screen, a negative overlap that
 * turns a stack into a gap.
 */
/** Rendered diameter of each avatar size, in points. */
export declare const AVATAR_SIZE_POINTS: {
    readonly sm: 32;
    readonly md: 40;
    readonly lg: 56;
    readonly xl: 80;
};
export type AvatarSizeName = keyof typeof AVATAR_SIZE_POINTS;
/**
 * How much of each avatar the next one covers, as a share of its diameter.
 * A third is enough for the faces to read as one group and to still leave the
 * widest part of every face visible.
 */
export declare const AVATAR_GROUP_OVERLAP_RATIO = 0.32;
/**
 * Points one avatar slides under its neighbour.
 *
 * Derived from the size rather than fixed, so the stack keeps its proportions
 * across the size ladder instead of looking crowded at `xl` and loose at `sm`.
 * A caller's own number wins, clamped so it can close a stack up entirely but
 * never open it into a gap — that is what a plain row is for.
 */
export declare function avatarGroupOverlap(size: AvatarSizeName, overlap?: number): number;
export interface AvatarGroupCount {
    /** How many avatars to render. */
    visible: number;
    /** How many are left over, for the trailing count. `0` renders no count. */
    overflow: number;
}
/**
 * Splits a row of faces into the ones shown and the number hidden behind them.
 *
 * `max` counts the faces, not the slots — a cap of three with five people shows
 * three avatars and a `+2`, rather than two and a `+3`.
 */
export declare function avatarGroupCount(count: number, max?: number, total?: number): AvatarGroupCount;
//# sourceMappingURL=avatar-group.d.ts.map