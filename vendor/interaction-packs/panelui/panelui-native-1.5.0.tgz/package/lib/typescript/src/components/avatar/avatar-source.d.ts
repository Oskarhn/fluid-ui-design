import type { ImageSourcePropType } from 'react-native';
/** Stable across equivalent inline source objects, but changes with request inputs. */
export declare function avatarSourceIdentity(source: ImageSourcePropType | undefined): string | undefined;
//# sourceMappingURL=avatar-source.d.ts.map