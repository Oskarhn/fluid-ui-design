import { type ReactNode } from 'react';
import { type ImageProps, type ImageSourcePropType, type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type AvatarSizeName } from './avatar-group.js';
import type { ViewRef } from '../../primitives/refs.js';
declare const avatarVariants: import("tailwind-variants").TVReturnType<{
    size: {
        sm: {
            root: string;
            fallback: string;
        };
        md: {
            root: string;
            fallback: string;
        };
        lg: {
            root: string;
            fallback: string;
        };
        xl: {
            root: string;
            fallback: string;
        };
    };
}, {
    root: string;
    image: string;
    fallback: string;
}, undefined, {
    size: {
        sm: {
            root: string;
            fallback: string;
        };
        md: {
            root: string;
            fallback: string;
        };
        lg: {
            root: string;
            fallback: string;
        };
        xl: {
            root: string;
            fallback: string;
        };
    };
}, {
    root: string;
    image: string;
    fallback: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        sm: {
            root: string;
            fallback: string;
        };
        md: {
            root: string;
            fallback: string;
        };
        lg: {
            root: string;
            fallback: string;
        };
        xl: {
            root: string;
            fallback: string;
        };
    };
}, {
    root: string;
    image: string;
    fallback: string;
}>>;
export interface AvatarProps extends ViewProps, VariantProps<typeof avatarVariants> {
    className?: string;
    /** Image source; falls back to initials when missing or on load error. */
    source?: ImageSourcePropType;
    /** Fallback text, e.g. initials ("KA"). */
    fallback?: string;
    imageProps?: Omit<ImageProps, 'source'>;
}
export interface AvatarBadgeProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface AvatarGroupProps extends ViewProps {
    className?: string;
    /** Size for every avatar in the stack. A child's own `size` still wins. */
    size?: AvatarSizeName;
    /**
     * How many faces to show. The rest are counted into a trailing `+N`.
     *
     * It caps the faces, not the row: `max={3}` with five people shows three
     * avatars and a `+2`.
     */
    max?: number;
    /**
     * How many people there are, when the children are only the first few of
     * them. The count is measured against this instead of against the number of
     * children, so a stack of three out of forty reads `+37`.
     */
    total?: number;
    /** Points each avatar slides under the one before it. Defaults to a third of the size. */
    overlap?: number;
}
export declare const Avatar: import("react").ForwardRefExoticComponent<AvatarProps & import("react").RefAttributes<ViewRef>> & {
    Badge: import("react").ForwardRefExoticComponent<AvatarBadgeProps & import("react").RefAttributes<ViewRef>>;
    Group: import("react").ForwardRefExoticComponent<AvatarGroupProps & import("react").RefAttributes<ViewRef>>;
};
export { AVATAR_GROUP_OVERLAP_RATIO, AVATAR_SIZE_POINTS, avatarGroupCount, avatarGroupOverlap, type AvatarGroupCount, type AvatarSizeName, } from './avatar-group.js';
//# sourceMappingURL=index.d.ts.map