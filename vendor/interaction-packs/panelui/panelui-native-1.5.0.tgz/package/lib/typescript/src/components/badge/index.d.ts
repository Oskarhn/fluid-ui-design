import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
declare const badgeVariants: import("tailwind-variants").TVReturnType<{
    size: {
        xs: {
            root: string;
            label: string;
        };
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
        xl: {
            root: string;
            label: string;
        };
    };
    shape: {
        default: {};
        /** A bare status dot, no label. */
        dot: {
            root: string;
        };
        /** Circular, for a count sitting over an avatar or an icon. */
        count: {
            root: string;
        };
    };
    variant: {
        default: {
            root: string;
            label: string;
        };
        secondary: {
            root: string;
            label: string;
        };
        outline: {
            root: string;
            label: string;
        };
        destructive: {
            root: string;
            label: string;
        };
        success: {
            root: string;
            label: string;
        };
        warning: {
            root: string;
            label: string;
        };
        info: {
            root: string;
            label: string;
        };
    };
}, {
    root: string;
    label: string;
}, undefined, {
    size: {
        xs: {
            root: string;
            label: string;
        };
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
        xl: {
            root: string;
            label: string;
        };
    };
    shape: {
        default: {};
        /** A bare status dot, no label. */
        dot: {
            root: string;
        };
        /** Circular, for a count sitting over an avatar or an icon. */
        count: {
            root: string;
        };
    };
    variant: {
        default: {
            root: string;
            label: string;
        };
        secondary: {
            root: string;
            label: string;
        };
        outline: {
            root: string;
            label: string;
        };
        destructive: {
            root: string;
            label: string;
        };
        success: {
            root: string;
            label: string;
        };
        warning: {
            root: string;
            label: string;
        };
        info: {
            root: string;
            label: string;
        };
    };
}, {
    root: string;
    label: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        xs: {
            root: string;
            label: string;
        };
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
        xl: {
            root: string;
            label: string;
        };
    };
    shape: {
        default: {};
        /** A bare status dot, no label. */
        dot: {
            root: string;
        };
        /** Circular, for a count sitting over an avatar or an icon. */
        count: {
            root: string;
        };
    };
    variant: {
        default: {
            root: string;
            label: string;
        };
        secondary: {
            root: string;
            label: string;
        };
        outline: {
            root: string;
            label: string;
        };
        destructive: {
            root: string;
            label: string;
        };
        success: {
            root: string;
            label: string;
        };
        warning: {
            root: string;
            label: string;
        };
        info: {
            root: string;
            label: string;
        };
    };
}, {
    root: string;
    label: string;
}>>;
/** How big a badge is. */
export type BadgeSize = NonNullable<VariantProps<typeof badgeVariants>['size']>;
export interface BadgeProps extends ViewProps, VariantProps<typeof badgeVariants> {
    children?: ReactNode;
    className?: string;
    labelClassName?: string;
    /**
     * Renders a number instead of children, clamped to "99+". Implies the
     * `count` shape unless you set one.
     */
    count?: number;
}
export declare const Badge: import("react").ForwardRefExoticComponent<BadgeProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map