import { type ComponentProps, type ReactElement, type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import Animated from 'react-native-reanimated';
export interface BottomSheetProps {
    children: ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    defaultOpen?: boolean;
    /**
     * Present the platform's own sheet instead of this one, so it gets the
     * system's detents, scroll interaction and dismiss gesture. Requires the
     * optional `@expo/ui` package; without it this prop does nothing.
     *
     * **Theme tokens do not apply to the sheet chrome** — the platform draws the
     * container, so `BottomSheet.Content`'s `className` and its drag handle are
     * ignored. The content inside is still yours.
     */
    native?: boolean;
    /**
     * Heights the native sheet can rest at. Omit to size to the content.
     * `{ fraction }` and `{ height }` are iOS-only; Android snaps them to the
     * nearest of `half` / `full`.
     */
    snapPoints?: ('half' | 'full' | {
        fraction: number;
    } | {
        height: number;
    })[];
    /**
     * Paint the native sheet a solid colour instead of the material the platform
     * draws it in by default.
     *
     * The platform's sheet is translucent — on iOS 26 that is Liquid Glass — and
     * what is behind it shows through. That is right for a sheet laid over
     * content worth glimpsing and wrong for one that is a surface of the app's
     * own, where the app's ground shifting under it reads as a mistake.
     *
     * `true` uses the theme's popover surface, so the sheet matches the rest of
     * the app in both schemes. A string paints that colour exactly.
     *
     * It only reaches the platform's sheet, so it does nothing without `native`.
     * On iOS below 16.4 the sheet keeps its material.
     */
    nativeBackground?: boolean | string;
}
/**
 * The height the content should at least fill for a given set of detents.
 *
 * Without this the hosted content sizes to itself and the platform centres
 * that smaller box inside the taller sheet, which is why a short sheet shows
 * its content floating in the middle. Filling the detent leaves nothing to
 * centre, so the content sits where it was written: at the top.
 *
 * Exported because a floor is not always enough. Content that is a *column* —
 * a list between a header and a composer — needs a definite height above it
 * before anything in it can be `flex-1`, and a minimum is not definite: the
 * list sizes to its own rows instead and pushes the composer off the bottom of
 * the sheet. Anything building that shape asks for the same number here rather
 * than working out the platform's detents a second time and disagreeing.
 */
export declare function bottomSheetDetentHeight(snapPoints: BottomSheetProps['snapPoints'], screenHeight: number): number | undefined;
declare function BottomSheetRoot({ children, open, onOpenChange, defaultOpen, native, snapPoints, nativeBackground, }: BottomSheetProps): import("react").JSX.Element;
interface BottomSheetTriggerProps {
    children: ReactElement<{
        onPress?: (...args: unknown[]) => void;
    }>;
}
declare function BottomSheetTrigger({ children }: BottomSheetTriggerProps): ReactElement<{
    onPress?: (...args: unknown[]) => void;
}, string | import("react").JSXElementConstructor<any>>;
export interface BottomSheetContentProps extends ViewProps {
    className?: string;
    /**
     * Whether the reader can close the sheet themselves — by tapping the
     * backdrop, dragging it down, or pressing back on Android. Default true.
     *
     * Off, only your own controls close it. On the native sheet this also stops
     * the drag on iOS, which is what a sheet whose content takes drags needs.
     */
    dismissible?: boolean;
    /**
     * Show a close button in the top trailing corner — the right in a
     * left-to-right app, the left in a right-to-left one. On by default for the
     * styled sheet; ignored by the native sheet, which has its own dismiss
     * affordances.
     */
    showClose?: boolean;
    /**
     * Show the drag handle at the top of the sheet. On by default, because a
     * sheet that can be dragged should say so.
     *
     * Turn it off when the sheet draws its own — a component wrapping this one
     * to give the surface a material of its own has to put the handle on that
     * material, and a handle floating above it belongs to nothing.
     *
     * On the native sheet it hides the platform's grabber on iOS.
     */
    showGrabber?: boolean;
    /**
     * Float the sheet clear of the screen edges instead of docking it to the
     * bottom, so it reads as a card laid over the app rather than a drawer
     * pulled out of it. All four corners round and the bottom border comes back,
     * since a floating sheet has four real edges where a docked one has three.
     * On Android it floats above the navigation bar, so the system buttons stay
     * uncovered. Ignored by the native sheet, which the platform positions itself.
     */
    detached?: boolean;
    /**
     * Frost the screen behind the sheet instead of dimming it, so what is behind
     * stays legible as shape and colour while losing its detail. Needs the
     * optional `expo-blur`; without it this dims, rather than failing.
     *
     * Someone who has Reduce Transparency switched on gets an opaque
     * backdrop instead, which is the whole point of the setting.
     */
    blur?: boolean;
    /**
     * How tall the sheet opens.
     *
     * `auto` sizes to the content, which is right for a sheet that is a handful
     * of rows. It stops short of the status bar, and a `Body` inside it scrolls
     * once the content is taller than that. `half` and `full` fix the height
     * instead, for content that has to be given the room rather than allowed to
     * ask for it — a list, a form, a document. For any other height, pass a
     * number of points (`320`) or a percentage of the screen (`'30%'`). Every
     * fixed height is clamped to leave the status bar clear, so `full` is as tall
     * as the screen allows rather than as tall as the screen.
     *
     * On the native sheet this maps onto the platform's detents: a number becomes
     * `{ height }` and a percentage `{ fraction }`, which Android snaps to the
     * nearer of `half` and `full`.
     */
    size?: 'auto' | 'half' | 'full' | number | `${number}%`;
    children?: ReactNode;
}
/** How tall `BottomSheet.Content` opens: a keyword, points, or a percentage of the screen. */
export type BottomSheetSize = NonNullable<BottomSheetContentProps['size']>;
declare function BottomSheetContent({ className, dismissible, showClose, showGrabber, detached, blur, size, children, ...props }: BottomSheetContentProps): import("react").JSX.Element | null;
export interface BottomSheetHeaderProps extends ViewProps {
    className?: string;
    /** Heading for the sheet. Strings are wrapped; anything else is drawn as given. */
    title?: ReactNode;
    /** A line under the title, for what the sheet is asking. */
    description?: ReactNode;
    children?: ReactNode;
}
/**
 * A fixed heading above the sheet's body.
 *
 * It exists mostly to reserve the top-right corner. The close button is
 * absolutely positioned there, so anything full-width at the top of a sheet
 * sits under it — a title is exactly that shape, and the end padding here is
 * what keeps the two from meeting. Being outside `Body` is the other half:
 * it stays put while the content scrolls under it, so the sheet still says
 * what it is once the list has moved.
 */
declare function BottomSheetHeader({ className, title, description, children, ...props }: BottomSheetHeaderProps): import("react").JSX.Element;
declare namespace BottomSheetHeader {
    var displayName: string;
}
export interface BottomSheetBodyProps extends Omit<ComponentProps<typeof Animated.ScrollView>, 'ref'> {
    className?: string;
    /**
     * Android's overscroll effect, drawn when the list is pulled past an end.
     * Off by default: at the top of the list that pull moves the sheet, and the
     * effect would draw the content stretching inside a sheet that is already
     * moving.
     */
    overScrollMode?: 'auto' | 'always' | 'never';
    children?: ReactNode;
}
export interface BottomSheetFooterProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/**
 * A row pinned below the body, for whatever the sheet is asking to be decided.
 * Outside `Body` so it stays reachable however far the content scrolls — an
 * action that has to be scrolled to is one people do not find.
 */
declare function BottomSheetFooter({ className, children, ...props }: BottomSheetFooterProps): import("react").JSX.Element;
declare namespace BottomSheetFooter {
    var displayName: string;
}
export declare const BottomSheet: typeof BottomSheetRoot & {
    Trigger: typeof BottomSheetTrigger;
    Content: typeof BottomSheetContent;
    Header: typeof BottomSheetHeader;
    Body: import("react").ForwardRefExoticComponent<BottomSheetBodyProps & import("react").RefAttributes<import("react-native").ScrollViewInstance>>;
    Footer: typeof BottomSheetFooter;
};
export {};
//# sourceMappingURL=index.d.ts.map