/**
 * Breadcrumb — the trail of where you are in a hierarchy.
 *
 * A row of links back up the tree, ending in the page you are on. The last
 * crumb is not a link: you cannot navigate to where you already are, so it is
 * a plain, current-marked label rather than a dead tappable target.
 *
 * The separators are the component's job, not yours. `Breadcrumb.List` drops a
 * chevron between each crumb it holds, so a trail is just its items — there is
 * no separator to forget, mis-order, or leave dangling at the end. Change the
 * glyph once with `separator` on the root and every gap follows.
 *
 * ```tsx
 * <Breadcrumb>
 *   <Breadcrumb.List>
 *     <Breadcrumb.Item>
 *       <Breadcrumb.Link onPress={goHome}>Home</Breadcrumb.Link>
 *     </Breadcrumb.Item>
 *     <Breadcrumb.Item>
 *       <Breadcrumb.Link onPress={goProjects}>Projects</Breadcrumb.Link>
 *     </Breadcrumb.Item>
 *     <Breadcrumb.Item>
 *       <Breadcrumb.Page>PanelUI</Breadcrumb.Page>
 *     </Breadcrumb.Item>
 *   </Breadcrumb.List>
 * </Breadcrumb>
 * ```
 *
 * A deep trail on a narrow phone does not wrap into a paragraph: give the list
 * a `maxItems` and it keeps the first and last crumbs, folding the middle into
 * a single ellipsis. Hand the ellipsis an `onEllipsisPress` and it becomes the
 * handle for a menu of the hidden steps.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type AnimatedPressableProps } from '../../primitives/animated-pressable.js';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
type BreadcrumbSize = 'sm' | 'default';
export interface BreadcrumbProps extends ViewProps {
    className?: string;
    /** Text density for every crumb. `sm` for a dense header bar. */
    size?: BreadcrumbSize;
    /**
     * The glyph `Breadcrumb.List` places between crumbs. Defaults to a chevron;
     * pass a `<Text>/</Text>`, a slash, or any node to change every gap at once.
     */
    separator?: ReactNode;
    children?: ReactNode;
}
export interface BreadcrumbListProps extends ViewProps {
    className?: string;
    /**
     * Collapse the trail once it holds more than this many crumbs, so a deep
     * path never wraps into a block of text on a narrow screen. The first
     * `itemsBeforeCollapse` and last `itemsAfterCollapse` survive; the middle
     * folds into a single ellipsis.
     */
    maxItems?: number;
    /** How many leading crumbs to keep when collapsing. Default 1. */
    itemsBeforeCollapse?: number;
    /** How many trailing crumbs to keep when collapsing. Default 1. */
    itemsAfterCollapse?: number;
    /**
     * Makes the collapsed ellipsis pressable — the handle for a menu listing the
     * hidden steps. Without it the ellipsis is a static marker.
     */
    onEllipsisPress?: () => void;
    children?: ReactNode;
}
export interface BreadcrumbItemProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface BreadcrumbLinkProps extends Omit<AnimatedPressableProps, 'children'> {
    className?: string;
    /** Text style for the crumb's label. */
    textClassName?: string;
    children?: ReactNode;
}
export interface BreadcrumbPageProps extends TextProps {
    className?: string;
}
export interface BreadcrumbSeparatorProps extends ViewProps {
    className?: string;
    /** Override the glyph for this one gap. Falls back to the root's separator. */
    children?: ReactNode;
}
export interface BreadcrumbEllipsisProps extends Omit<AnimatedPressableProps, 'children'> {
    className?: string;
}
export declare const Breadcrumb: import("react").ForwardRefExoticComponent<BreadcrumbProps & import("react").RefAttributes<ViewRef>> & {
    List: import("react").ForwardRefExoticComponent<BreadcrumbListProps & import("react").RefAttributes<ViewRef>>;
    Item: import("react").ForwardRefExoticComponent<BreadcrumbItemProps & import("react").RefAttributes<ViewRef>>;
    Link: import("react").ForwardRefExoticComponent<BreadcrumbLinkProps & import("react").RefAttributes<ViewRef>>;
    Page: import("react").ForwardRefExoticComponent<BreadcrumbPageProps & import("react").RefAttributes<TextRef>>;
    Separator: import("react").ForwardRefExoticComponent<BreadcrumbSeparatorProps & import("react").RefAttributes<ViewRef>>;
    Ellipsis: import("react").ForwardRefExoticComponent<BreadcrumbEllipsisProps & import("react").RefAttributes<ViewRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map