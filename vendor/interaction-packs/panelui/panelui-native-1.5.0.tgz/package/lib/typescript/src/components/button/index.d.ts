import { type ReactNode } from 'react';
import { type VariantProps } from 'tailwind-variants';
import { type AnimatedPressableProps } from '../../primitives/animated-pressable.js';
import { type SpinnerProps } from '../spinner/index.js';
import type { ViewRef } from '../../primitives/refs.js';
declare const buttonVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        primary: {
            root: string;
            label: string;
            spinner: string;
        };
        secondary: {
            root: string;
            label: string;
            spinner: string;
        };
        outline: {
            root: string;
            label: string;
            spinner: string;
        };
        ghost: {
            root: string;
            label: string;
            spinner: string;
        };
        destructive: {
            root: string;
            label: string;
            spinner: string;
        };
        /** Neutral surface for third-party sign-in, sized for a full-width stack. */
        social: {
            root: string;
            label: string;
            spinner: string;
        };
    };
    size: {
        xs: {
            root: string;
            label: string;
        };
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
        xl: {
            root: string;
            label: string;
        };
        icon: {
            root: string;
        };
    };
    fullWidth: {
        true: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    label: string;
    spinner: string;
}, undefined, {
    variant: {
        primary: {
            root: string;
            label: string;
            spinner: string;
        };
        secondary: {
            root: string;
            label: string;
            spinner: string;
        };
        outline: {
            root: string;
            label: string;
            spinner: string;
        };
        ghost: {
            root: string;
            label: string;
            spinner: string;
        };
        destructive: {
            root: string;
            label: string;
            spinner: string;
        };
        /** Neutral surface for third-party sign-in, sized for a full-width stack. */
        social: {
            root: string;
            label: string;
            spinner: string;
        };
    };
    size: {
        xs: {
            root: string;
            label: string;
        };
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
        xl: {
            root: string;
            label: string;
        };
        icon: {
            root: string;
        };
    };
    fullWidth: {
        true: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    label: string;
    spinner: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        primary: {
            root: string;
            label: string;
            spinner: string;
        };
        secondary: {
            root: string;
            label: string;
            spinner: string;
        };
        outline: {
            root: string;
            label: string;
            spinner: string;
        };
        ghost: {
            root: string;
            label: string;
            spinner: string;
        };
        destructive: {
            root: string;
            label: string;
            spinner: string;
        };
        /** Neutral surface for third-party sign-in, sized for a full-width stack. */
        social: {
            root: string;
            label: string;
            spinner: string;
        };
    };
    size: {
        xs: {
            root: string;
            label: string;
        };
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
        xl: {
            root: string;
            label: string;
        };
        icon: {
            root: string;
        };
    };
    fullWidth: {
        true: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    label: string;
    spinner: string;
}>>;
type ButtonVariantProps = VariantProps<typeof buttonVariants>;
/** How a button looks. */
export type ButtonVariant = NonNullable<ButtonVariantProps['variant']>;
/** How big a button is. `icon` is a square. */
export type ButtonSize = NonNullable<ButtonVariantProps['size']>;
export interface ButtonGroupContextValue {
    /** Fills in for a button that did not choose one. */
    variant?: ButtonVariant;
    /** Fills in for a button that did not choose one. */
    size?: ButtonSize;
    /** The buttons are joined into one shape, so each drops its own. */
    attached: boolean;
    /** Segments share the row equally. */
    fullWidth: boolean;
}
/** Announces to every button below it that it is part of one control. */
export declare function ButtonGroupProvider({ value, children, }: {
    value: ButtonGroupContextValue;
    children: ReactNode;
}): import("react").JSX.Element;
/** The enclosing group, if there is one. `null` for a button standing alone. */
export declare function useButtonGroup(): ButtonGroupContextValue | null;
export interface ButtonProps extends Omit<AnimatedPressableProps, 'children' | 'disabled'>, Omit<ButtonVariantProps, 'disabled'> {
    children?: ReactNode;
    /**
     * Block presses and dim the button to 64% opacity. Screen readers hear it as
     * dimmed.
     *
     * To dim it by a different amount, pass an opacity class while it is
     * disabled: `className={disabled ? 'opacity-50' : undefined}`.
     */
    disabled?: boolean;
    /**
     * Show a spinner and block presses while an action is in flight. Screen
     * readers hear the button as busy until it ends.
     *
     * On Android the button needs a name to stop being read as busy afterwards.
     * Plain-text children give it one. A button whose children include an
     * element needs an `accessibilityLabel`.
     */
    loading?: boolean;
    /**
     * Props for the spinner `loading` shows. Leave it unset and the spinner is
     * drawn in the label's colour, at a size picked from the button's.
     *
     * `color` paints the turning arc and `trackColor` the faint ring under it —
     * any colour React Native accepts. `className` takes theme tokens instead,
     * such as `border-t-success`. On a filled button, set the track as well as
     * the arc: the default track is a tint of the label colour, and beside an
     * arc in another colour it reads as a second spinner.
     *
     * There is no `label`. The button already announces itself as busy while it
     * loads, so a label on the spinner would announce the same wait twice.
     */
    spinnerProps?: Omit<SpinnerProps, 'label'>;
    /** Content rendered before the label (replaced by the spinner while loading). */
    startContent?: ReactNode;
    /** Content rendered after the label. */
    endContent?: ReactNode;
    /** Extra classes for the label when children is a string. */
    labelClassName?: string;
    /**
     * Render the platform's own button instead of this one. Requires the
     * optional `@expo/ui` package; without it this prop does nothing.
     *
     * **Theme tokens do not apply** — the platform draws the button, so
     * `className`, `fullWidth`, `startContent`, `endContent`, `loading` and
     * `spinnerProps` are all ignored. `variant` maps onto the nearest platform style:
     * `primary`/`destructive` → filled, `outline` → outlined, everything else
     * → text; `size` sets the height.
     *
     * A native button **sizes itself to its label**, the way a platform button
     * is supposed to. It does not stretch to fill its container, and `fullWidth`
     * has no effect on it.
     *
     * **Give it a string, not elements, unless `size` is `icon`.** A string
     * becomes the platform's own label. Anything else has to be hosted inside
     * the native tree, and a hosted view only measures where something above it
     * is definite on *both* axes — which is true of an icon button, because it
     * is a square this component sizes, and false of a labelled one, whose width
     * is its text's and known to nobody in advance. Host a label without a width
     * and the two layout systems ask each other the same question until the app
     * dies, in native code, where a `try` here has nothing to catch.
     */
    native?: boolean;
    /**
     * Draw the native button in the platform's Liquid Glass material — the one
     * iOS 26 uses for its own floating controls. Requires `native`, and iOS 26 or
     * later; anywhere else it is ignored and the button keeps its ordinary
     * platform style rather than failing.
     *
     * `primary` and `destructive` take the prominent variant, which keeps the
     * accent tint a filled button is supposed to have; every other variant takes
     * the plain one. An icon button is drawn round rather than in the platform's
     * default capsule.
     */
    glass?: boolean;
    /**
     * A glyph beside the label, named from the platform's own symbol set rather
     * than passed as an element.
     *
     * This is how a labelled native button gets an icon at all. Elements have to
     * be hosted inside the native tree, and a hosted view inside a labelled
     * button has no width anything can resolve — so a name is not a shortcut
     * here, it is the only form that works. The platform draws it, at its own
     * size, in the label's colour.
     *
     * iOS only, and `native` only. Android's toolkit has no equivalent symbol
     * set, so a button there is its label alone; the drawn button takes
     * `startContent` and always did.
     */
    systemImage?: string;
}
export declare const Button: import("react").ForwardRefExoticComponent<ButtonProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map