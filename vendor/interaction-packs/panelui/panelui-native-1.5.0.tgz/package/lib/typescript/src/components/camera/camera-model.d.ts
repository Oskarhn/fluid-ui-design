/**
 * The Camera's arithmetic, kept apart from the component so it can be tested
 * without a device. Every function here is pure; the ones the gestures call on
 * the UI thread are worklets.
 */
/** Which camera the preview reads. */
export type CameraFacing = 'back' | 'front';
/** What the shutter makes. */
export type CameraMode = 'photo' | 'video';
/**
 * The flash setting the control shows. `auto` lets the camera decide for a
 * photo; a video has no auto, so there it reads as off.
 */
export type CameraFlashMode = 'off' | 'auto' | 'on';
/** Seconds the self-timer counts down before a photo. `0` is off. */
export type CameraTimerDelay = 0 | 3 | 10;
/** The timer settings, in the order the control steps through them. */
export declare const CAMERA_TIMERS: readonly CameraTimerDelay[];
/**
 * How much of the zoom range a pinch's `scale - 1` is worth: pinching to twice
 * the distance between the fingers moves half the range.
 */
export declare const PINCH_ZOOM_SENSITIVITY = 0.5;
/** How far one step of the screen reader's adjust moves the zoom. */
export declare const ZOOM_STEP = 0.1;
/**
 * Zoom as expo-camera takes it: a fraction of the device's maximum, on `[0, 1]`.
 * Anything else, `NaN` included, is pulled back onto that range.
 */
export declare function clampZoom(value: number): number;
/**
 * The zoom a pinch reaches from the zoom it started at.
 *
 * Added to rather than multiplied, so a pinch that comes back to where the
 * fingers started comes back to the zoom it started at, instead of compounding.
 */
export declare function zoomFromPinch(startZoom: number, scale: number): number;
/** The zoom a drag along the zoom bar points at, from where it is on the track. */
export declare function zoomFromTrack(x: number, width: number): number;
/** The zoom one adjust step up (`1`) or down (`-1`) from `zoom` lands on. */
export declare function stepZoom(zoom: number, direction: 1 | -1): number;
/**
 * Which of `stops` the zoom is at, or `-1` between them. Close enough counts,
 * since a pinch rarely lands on a value exactly.
 */
export declare function activeStop(zoom: number, stops: readonly {
    value: number;
}[]): number;
/**
 * Milliseconds as a recording clock: `mm:ss`, and `h:mm:ss` past an hour.
 * Leading zeros stay, so the clock does not change width as it runs, and
 * `00:00` is what it reads before recording starts.
 */
export declare function formatDuration(ms: number): string;
/** What the flash setting reads as in a mode: a video has no `auto`. */
export declare function flashIn(mode: CameraMode, flash: CameraFlashMode): CameraFlashMode;
/**
 * The setting the flash control moves to. A photo cycles off, auto, on; a
 * video only has off and on.
 */
export declare function nextFlash(mode: CameraMode, flash: CameraFlashMode): CameraFlashMode;
/**
 * The `flash` expo-camera is given. It drives stills only, so in video it is
 * off and the torch does the lighting instead.
 */
export declare function stillFlash(mode: CameraMode, flash: CameraFlashMode): CameraFlashMode;
/**
 * Whether the torch is lit: in video with the flash on, and only while a clip
 * is being recorded, so it does not glare at the subject while they wait.
 */
export declare function torchFor(mode: CameraMode, flash: CameraFlashMode, recording: boolean): boolean;
/** The timer setting after `timer`, wrapping back to off. */
export declare function nextTimer(timer: CameraTimerDelay): CameraTimerDelay;
/**
 * How far a capped recording has run, on `[0, 1]`. Without a cap there is
 * nothing to fill, so it stays `0`.
 */
export declare function recordingProgress(elapsedMs: number, maxDurationSeconds?: number): number;
//# sourceMappingURL=camera-model.d.ts.map