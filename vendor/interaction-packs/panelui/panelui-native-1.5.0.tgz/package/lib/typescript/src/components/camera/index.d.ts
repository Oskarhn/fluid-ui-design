/**
 * Camera — a full-screen camera assembled from parts: the viewfinder, the
 * shutter, zoom, flash, a self-timer, the recording clock, front and back, and
 * the button into the library.
 *
 * ```tsx
 * <Camera onCapture={keep}>
 *   <Camera.Preview />
 *   <Camera.Header>
 *     <Camera.Flash />
 *     <Camera.Duration />
 *     <Camera.Timer />
 *   </Camera.Header>
 *   <Camera.Footer>
 *     <Camera.Zoom />
 *     <Camera.Modes />
 *     <Camera.Controls>
 *       <Camera.Library source={last} onPress={openLibrary} />
 *       <Camera.Shutter />
 *       <Camera.Flip />
 *     </Camera.Controls>
 *   </Camera.Footer>
 * </Camera>
 * ```
 *
 * ## The result is the app's
 *
 * A photo or a clip is handed to `onCapture` as the file the camera wrote, and
 * nothing else happens to it here. Saving it to the photo library, holding it
 * in memory for a preview, uploading it: each app wants a different one, and a
 * component that picked would be wrong for most of them. The library button is
 * the same — it draws the thumbnail it is given and calls `onPress`.
 *
 * ## Every part reads one state
 *
 * The root owns facing, mode, flash, zoom and the timer, each controlled or
 * not, and every part reads them through context. `useCamera()` hands the same
 * state and actions to anything else, so a part that does not suit can be
 * swapped for a control of the app's own without losing the behaviour behind
 * it. Leave a part out and its feature is simply not offered.
 *
 * ## Built on expo-camera
 *
 * The preview, the capture and the recording are expo-camera's, which runs in
 * Expo Go. It is an optional dependency: without it the preview says so, and
 * `hasCamera` is false.
 *
 * Its zoom is a fraction of the device's maximum, and that maximum is not
 * exposed — on iOS the fraction is an exponent of it, on Android a multiple —
 * so the same zoom is a different magnification on every phone. That is why
 * nothing here labels a zoom "2×" on its own: the stops are the app's to name,
 * and between them a bar shows where in the range the lens is.
 *
 * There is no way to focus on a point either, so a tap on the preview does
 * nothing rather than draw a square over a focus that never moved.
 *
 * ## Over a black viewfinder
 *
 * The viewfinder is black in every theme and the picture on it is whatever
 * the lens sees, so the chrome over it is white on a dark glaze in every theme.
 * An active control is drawn inverted, white with a black glyph, which reads on
 * any picture; recording is the destructive colour.
 *
 * Switching cameras hides the swap under a brief dark cover rather than
 * turning the preview: on Android the preview is a surface that ignores view
 * transforms, and the frame where one session hands over to the other is not
 * something to show.
 */
import { type ReactNode, type RefAttributes } from 'react';
import { type ImageSourcePropType, type PressableProps, type ViewProps } from 'react-native';
import { type CameraFacing, type CameraFlashMode, type CameraMode, type CameraTimerDelay } from './camera-model.js';
export type { CameraFacing, CameraFlashMode, CameraMode, CameraTimerDelay } from './camera-model.js';
/** The picture expo-camera returns. */
interface CapturedPicture {
    uri: string;
    width: number;
    height: number;
    base64?: string;
    exif?: Record<string, unknown>;
}
/**
 * The methods of expo-camera's `CameraView` this component calls, and the ones
 * an app is likeliest to reach for through `CameraHandle.view`.
 */
export interface CameraViewHandle {
    takePictureAsync(options?: object): Promise<CapturedPicture | undefined>;
    recordAsync(options?: object): Promise<{
        uri: string;
    } | undefined>;
    stopRecording(): void;
    pausePreview(): Promise<void>;
    resumePreview(): Promise<void>;
}
/**
 * True when the camera can be shown, because `expo-camera` is installed and its
 * native module is in the build. Expo Go has it.
 */
export declare const hasCamera: boolean;
/** A photo, as the camera wrote it. */
export interface CameraPhoto {
    type: 'photo';
    /** A local file. */
    uri: string;
    width: number;
    height: number;
    /** Present when `pictureOptions.base64` is set. */
    base64?: string;
    /** Present when `pictureOptions.exif` is set. */
    exif?: Record<string, unknown>;
}
/** A clip, as the camera wrote it. */
export interface CameraVideo {
    type: 'video';
    /** A local file. */
    uri: string;
    /** How long it ran, in milliseconds, measured from when recording started. */
    duration: number;
}
export type CameraCapture = CameraPhoto | CameraVideo;
/** Options for each photo, passed to expo-camera's `takePictureAsync`. */
export interface CameraPictureOptions {
    /** JPEG quality, 0–1. Default 1. */
    quality?: number;
    /** Also return the image as base64. */
    base64?: boolean;
    /** Also return its EXIF data. */
    exif?: boolean;
    /** Skip orientation and quality processing, for speed. */
    skipProcessing?: boolean;
    /** Play the shutter sound. Default true; some regions require it. */
    shutterSound?: boolean;
}
/**
 * Props passed straight to expo-camera's `CameraView`, for what the parts do not
 * cover. The parts' own state wins over the same prop here.
 */
export interface CameraViewOptions {
    videoQuality?: '2160p' | '1080p' | '720p' | '480p' | '4:3';
    videoStabilizationMode?: 'off' | 'standard' | 'cinematic' | 'auto';
    /** Android only: the preview's aspect ratio. */
    ratio?: '4:3' | '16:9' | '1:1';
    /** iOS only: which lens, from `getAvailableLensesAsync`. */
    selectedLens?: string;
    pictureSize?: string;
    animateShutter?: boolean;
    [key: string]: unknown;
}
/** One zoom stop: a value in expo-camera's range, and the label the app gives it. */
export interface CameraZoomStop {
    /** 0–1, a fraction of the device's maximum zoom. */
    value: number;
    /** What the chip says, such as `1×` or `2`. */
    label: string;
    /** Read out instead of `Zoom <label>`. */
    accessibilityLabel?: string;
}
/** What `useCamera()` returns: the camera's state, and what can be done with it. */
export interface CameraState {
    facing: CameraFacing;
    mode: CameraMode;
    /** The setting as chosen. In video, `auto` acts as off. */
    flash: CameraFlashMode;
    /** 0–1, a fraction of the device's maximum. */
    zoom: number;
    timer: CameraTimerDelay;
    /** The camera has started and can capture. */
    ready: boolean;
    /** Camera access, or null until it is known. */
    permission: {
        granted: boolean;
        canAskAgain: boolean;
    } | null;
    recording: boolean;
    /** When recording started, as `Date.now()`, or null. */
    recordingSince: number | null;
    /** A photo is being taken. */
    capturing: boolean;
    /** Seconds left on the self-timer, or null when it is not counting. */
    countdown: number | null;
    /** The recording cap, in seconds, when there is one. */
    maxDuration?: number;
    setMode: (mode: CameraMode) => void;
    setFlash: (flash: CameraFlashMode) => void;
    setZoom: (zoom: number) => void;
    setTimer: (timer: CameraTimerDelay) => void;
    /** Swap front and back. Ignored while recording. */
    flip: () => void;
    /** What a press on the shutter does in the current mode. */
    press: () => void;
    takePhoto: () => Promise<CameraPhoto | null>;
    startRecording: () => Promise<void>;
    stopRecording: () => void;
    cancelCountdown: () => void;
    requestPermission: () => void;
}
/** A ref on `Camera`. */
export interface CameraHandle {
    /** Takes a photo now, ignoring the timer, and resolves to it, or null if it failed. */
    takePhoto: () => Promise<CameraPhoto | null>;
    /** Starts recording; resolves once the clip has been handed to `onCapture`. */
    startRecording: () => Promise<void>;
    stopRecording: () => void;
    flip: () => void;
    /** expo-camera's `CameraView`, for anything this component does not wrap. */
    readonly view: CameraViewHandle | null;
}
/**
 * The camera's state and actions, for a control of the app's own inside
 * `<Camera>` — a shutter drawn differently, a timer in a menu.
 */
export declare function useCamera(): CameraState;
export interface CameraProps extends ViewProps {
    /** Classes on the root, which fills its parent and is black. */
    className?: string;
    /** The parts. Put `Camera.Preview` first, so everything after it is drawn over the picture. */
    children?: ReactNode;
    /** Which camera, controlled. */
    facing?: CameraFacing;
    /** Which camera it opens on. */
    defaultFacing?: CameraFacing;
    /** Called when the camera switches between front and back. */
    onFacingChange?: (facing: CameraFacing) => void;
    /** Photo or video, controlled. */
    mode?: CameraMode;
    /** Photo or video to start in. */
    defaultMode?: CameraMode;
    /** Called when the mode changes. */
    onModeChange?: (mode: CameraMode) => void;
    /** The flash setting, controlled. In video, `on` lights the torch while recording. */
    flash?: CameraFlashMode;
    /** The flash setting to start with. */
    defaultFlash?: CameraFlashMode;
    /** Called when the flash setting changes. */
    onFlashChange?: (flash: CameraFlashMode) => void;
    /**
     * Zoom, controlled: 0–1, a fraction of the device's maximum zoom, which is a
     * different magnification on every phone. Reset to 0 when the camera flips.
     */
    zoom?: number;
    /** The zoom to start at. */
    defaultZoom?: number;
    /** Called as the zoom changes, many times during a pinch. */
    onZoomChange?: (zoom: number) => void;
    /** The self-timer, in seconds, controlled. Photos only. */
    timer?: CameraTimerDelay;
    /** The self-timer to start with. */
    defaultTimer?: CameraTimerDelay;
    /** Called when the self-timer setting changes. */
    onTimerChange?: (timer: CameraTimerDelay) => void;
    /**
     * Called with each photo and clip. Nothing is saved: the file is where the
     * camera wrote it, and keeping it, saving it or uploading it is up to you.
     */
    onCapture?: (capture: CameraCapture) => void;
    /**
     * Called when the camera fails to start, a capture fails, or microphone
     * access is refused. Without it, these are logged in development.
     */
    onError?: (error: Error) => void;
    /** Stops a recording after this many seconds, and fills the shutter's ring towards it. */
    maxDuration?: number;
    /** Record without sound, and without asking for the microphone. */
    mute?: boolean;
    /**
     * Save front-camera photos and clips mirrored, the way the preview shows
     * them. Off, they are saved the way other people see you.
     */
    mirror?: boolean;
    /** Options for every photo. */
    pictureOptions?: CameraPictureOptions;
    /** Passed to expo-camera's `CameraView`. */
    cameraProps?: CameraViewOptions;
    /** A tick on the shutter, the flip and each setting change. */
    haptics?: boolean;
    /** Keep the header and footer clear of the notch and the home indicator. */
    safeArea?: boolean;
}
export interface CameraPreviewProps extends ViewProps {
    className?: string;
    /** Drawn over the picture, under the header and footer: a grid, a guide, a frame. */
    children?: ReactNode;
    /** Two fingers zoom. */
    pinchToZoom?: boolean;
    /** A double tap swaps front and back. */
    doubleTapToFlip?: boolean;
    /** Shown while camera access has not been given. */
    permissionTitle?: string;
    permissionDescription?: string;
    /** The button that asks for access. */
    permissionAction?: string;
    /** The button once access has been refused for good, which opens Settings. */
    settingsAction?: string;
    /** Read out for the viewfinder, which a screen reader adjusts to zoom. */
    accessibilityLabel?: string;
}
/**
 * The live picture, filling the camera. Until camera access is given it asks
 * for it in place, and once access is refused for good its button opens
 * Settings, since asking again would do nothing.
 */
declare function CameraPreview({ className, children, pinchToZoom, doubleTapToFlip, permissionTitle, permissionDescription, permissionAction, settingsAction, accessibilityLabel, style, ...props }: CameraPreviewProps): import("react").JSX.Element;
declare namespace CameraPreview {
    var displayName: string;
}
export interface CameraHeaderProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/** The band along the top, over the picture: flash, the clock, the timer. */
declare function CameraHeader({ className, children, style, ...props }: CameraHeaderProps): import("react").JSX.Element;
declare namespace CameraHeader {
    var displayName: string;
}
export interface CameraFooterProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/** The band along the bottom, over the picture: zoom, the modes, the shutter row. */
declare function CameraFooter({ className, children, style, ...props }: CameraFooterProps): import("react").JSX.Element;
declare namespace CameraFooter {
    var displayName: string;
}
export interface CameraControlsProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/**
 * The row the shutter sits in, with what goes either side of it. Library and
 * Flip are the same size, so the shutter lands in the middle.
 */
declare function CameraControls({ className, children, ...props }: CameraControlsProps): import("react").JSX.Element;
declare namespace CameraControls {
    var displayName: string;
}
export interface CameraButtonProps extends Omit<PressableProps, 'children'> {
    className?: string;
    /** Drawn inverted, white with a black glyph, for a setting that is on. */
    active?: boolean;
    /** An icon. It is drawn white, or black when `active`, unless it is given a colour of its own. */
    children: ReactNode;
}
/**
 * A round control over the picture for an action of your own: closing the
 * camera, a grid, a setting. It is drawn like Flash and Timer, so a row of
 * them reads as one set. Give it an `accessibilityLabel`; an icon has nothing
 * to read out.
 */
declare function CameraButton({ className, active, children, ...props }: CameraButtonProps): import("react").JSX.Element;
declare namespace CameraButton {
    var displayName: string;
}
export interface CameraFlashProps extends Omit<PressableProps, 'children' | 'onPress'> {
    className?: string;
    /** What each setting is read out as; `auto`'s is also shown beside the icon. */
    labels?: Partial<Record<CameraFlashMode, string>>;
    accessibilityLabel?: string;
}
/**
 * The flash. For a photo it steps off, auto, on; for a video, off and on, and
 * on lights the torch while recording.
 */
declare function CameraFlashControl({ className, labels, accessibilityLabel, ...props }: CameraFlashProps): import("react").JSX.Element;
declare namespace CameraFlashControl {
    var displayName: string;
}
export interface CameraTimerProps extends Omit<PressableProps, 'children' | 'onPress'> {
    className?: string;
    /** What off is read out as. */
    offLabel?: string;
    accessibilityLabel?: string;
}
/**
 * The self-timer: off, 3 s, 10 s. While it counts, the seconds left fill the
 * preview, and a press on the shutter cancels. Photos only, so it is dimmed in
 * video.
 */
declare function CameraTimerControl({ className, offLabel, accessibilityLabel, ...props }: CameraTimerProps): import("react").JSX.Element;
declare namespace CameraTimerControl {
    var displayName: string;
}
export interface CameraDurationProps extends ViewProps {
    className?: string;
    /** Show it in photo mode too, at `00:00`. By default it appears in video only. */
    always?: boolean;
}
/**
 * The recording clock, `mm:ss`. It reads `00:00` in video before recording,
 * and turns red with a dot while it runs. Hidden in photo mode.
 */
declare function CameraDuration({ className, always, ...props }: CameraDurationProps): import("react").JSX.Element | null;
declare namespace CameraDuration {
    var displayName: string;
}
export interface CameraZoomProps extends ViewProps {
    className?: string;
    /**
     * The chips to show, each a value in expo-camera's 0–1 range with the label
     * you give it. Left out, one `1×` chip that undoes any zoom. The values that
     * match a given magnification differ from phone to phone, so measure them on
     * the devices you target before labelling them as one.
     */
    stops?: CameraZoomStop[];
    /** Show a bar of where the zoom sits in the range, which can be dragged, while zoomed in. */
    bar?: boolean;
}
/**
 * Zoom stops above the shutter, and a bar that shows how far in the zoom is
 * once it is past the first.
 */
declare function CameraZoom({ className, stops, bar, ...props }: CameraZoomProps): import("react").JSX.Element;
declare namespace CameraZoom {
    var displayName: string;
}
export interface CameraModesProps extends ViewProps {
    className?: string;
    /** What each mode is called. */
    labels?: Partial<Record<CameraMode, string>>;
}
/** Video or photo, as a pill with a thumb that slides between them. Locked while recording. */
declare function CameraModes({ className, labels, ...props }: CameraModesProps): import("react").JSX.Element;
declare namespace CameraModes {
    var displayName: string;
}
export interface CameraLibraryProps extends Omit<PressableProps, 'children'> {
    className?: string;
    /** The thumbnail: the last capture, or the newest photo in the library. An icon without one. */
    source?: ImageSourcePropType;
    accessibilityLabel?: string;
}
/** The way into the photos. What it opens is `onPress`'s to decide. */
declare function CameraLibrary({ className, source, accessibilityLabel, ...props }: CameraLibraryProps): import("react").JSX.Element;
declare namespace CameraLibrary {
    var displayName: string;
}
export interface CameraFlipProps extends Omit<PressableProps, 'children' | 'onPress'> {
    className?: string;
    accessibilityLabel?: string;
}
/** Front and back. Not while recording: the clip would cut between two cameras. */
declare function CameraFlip({ className, accessibilityLabel, ...props }: CameraFlipProps): import("react").JSX.Element;
declare namespace CameraFlip {
    var displayName: string;
}
export interface CameraShutterProps extends Omit<PressableProps, 'children' | 'onPress'> {
    className?: string;
    /** In video, holding the shutter records until it is let go. A tap still starts and stops. */
    holdToRecord?: boolean;
    /** Replaces what a press does. The shutter still draws the camera's state. */
    onPress?: () => void;
    /**
     * Read out instead of the label it gives itself, which says what a press
     * will do: take a photo, cancel the timer, record or stop.
     */
    accessibilityLabel?: string;
}
/**
 * The shutter. A tap takes a photo, after the timer if one is set; in video a
 * tap starts and stops, and a hold records for as long as it is held. The disc
 * is white for a photo and red for a video, and squares off while recording. A
 * ring fills towards `maxDuration` when there is one.
 */
declare function CameraShutter({ className, holdToRecord, onPress, accessibilityLabel, ...props }: CameraShutterProps): import("react").JSX.Element;
declare namespace CameraShutter {
    var displayName: string;
}
export declare const Camera: import("react").ForwardRefExoticComponent<CameraProps & RefAttributes<CameraHandle>> & {
    Preview: typeof CameraPreview;
    Header: typeof CameraHeader;
    Footer: typeof CameraFooter;
    Controls: typeof CameraControls;
    Button: typeof CameraButton;
    Flash: typeof CameraFlashControl;
    Timer: typeof CameraTimerControl;
    Duration: typeof CameraDuration;
    Zoom: typeof CameraZoom;
    Modes: typeof CameraModes;
    Library: typeof CameraLibrary;
    Flip: typeof CameraFlip;
    Shutter: typeof CameraShutter;
};
//# sourceMappingURL=index.d.ts.map