/**
 * CandlestickChart — four numbers a period, drawn as one mark.
 *
 * Composed the same way every chart here is: the grid, the candles, the axes
 * and the readout are separate children, so a chart that wants no grid simply
 * does not have one.
 *
 * ```tsx
 * <CandlestickChart data={session} xDataKey="day">
 *   <CandlestickChart.Grid />
 *   <CandlestickChart.Candles />
 *   <CandlestickChart.XAxis />
 *   <CandlestickChart.Tooltip />
 * </CandlestickChart>
 * ```
 *
 * ## One mark, four numbers
 *
 * A row is `{ open, high, low, close }`. The body spans open to close and is
 * filled by direction — rising when the close is at or above the open, falling
 * when it is below — and the wick spans low to high behind it. Colour is
 * therefore the *sign* of the period rather than a series identity, which is
 * why this chart has no series list and no legend: there is only ever one
 * thing plotted, and the two colours are its two states.
 *
 * ## The baseline is not zero, and must not be
 *
 * A bar compares lengths, so its axis has to reach zero or twice as tall stops
 * meaning twice as much. A candle compares nothing to zero. What is being read
 * is the distance between four numbers that sit close together and far from the
 * origin — a share at 180 that moved between 178 and 183 is a chart of that
 * five-point span, and forcing zero onto the axis turns every candle in it into
 * a dash. So the domain is derived from the lowest low and the highest high,
 * with a margin so the extremes are not drawn on the frame.
 *
 * ## Two paths, not two per candle
 *
 * Every rising body is a subpath of one path and every falling body of another,
 * and the wicks likewise — four animated props a frame whether the chart holds
 * twenty candles or two hundred. A candle also cannot be drawn as a rectangle
 * element and animated: the grow-in scales each body about its own middle, and
 * that is a path rebuilt per frame on the UI thread rather than a transform
 * that would take the wick and the neighbours with it.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type ChartAccessibilityProps } from '../../primitives/chart-accessibility.js';
type Layer = 'svg' | 'overlay' | 'header';
export type CandlestickChartStatus = 'loading' | 'ready';
/**
 * One period. `open`, `high`, `low` and `close` are required to be numbers —
 * unlike a line, a candle cannot be drawn from some of them.
 */
export interface CandlestickChartDatum {
    [key: string]: string | number | null | undefined;
}
/**
 * The candle under the finger, for something rendered *inside* the chart. A
 * readout in the card's header is outside this provider — use
 * `onActiveIndexChange` for that.
 */
export declare function useCandlestickChart(): {
    activeIndex: number;
    activePoint: CandlestickChartDatum | null;
    xDataKey: string;
};
export interface CandlestickChartProps extends ViewProps, ChartAccessibilityProps<CandlestickChartDatum> {
    className?: string;
    /** The rows. Each one is a period along the x-axis. */
    data: CandlestickChartDatum[];
    /** Key holding the period label. Used by the axis and the readout. */
    xDataKey?: string;
    /** Key holding the opening price. */
    openDataKey?: string;
    /** Key holding the period's high. */
    highDataKey?: string;
    /** Key holding the period's low. */
    lowDataKey?: string;
    /** Key holding the closing price. */
    closeDataKey?: string;
    /**
     * `loading` leaves the plot empty — the frame, the grid and the header stay,
     * and no candles are drawn. Turning `ready` grows them in left to right.
     *
     * Nothing stands in for the candles while they are missing. A placeholder
     * candle is four made-up prices, and a reader has no way to tell an invented
     * one from a real one until it changes under them.
     */
    status?: CandlestickChartStatus;
    /** Width ÷ height. `1.6` suits a chart this dense better than `2`. */
    aspectRatio?: number;
    /** Milliseconds for the candles to grow in on mount. */
    animationDuration?: number;
    /** Milliseconds for the price axis to settle after the data changes. */
    domainDuration?: number;
    /**
     * Fix the price axis instead of deriving it from the lows and highs. Note
     * that the derived domain deliberately does *not* include zero — see the
     * notes on why a candle's axis is not a bar's.
     */
    yDomain?: [number, number];
    /**
     * Fraction of each period's slice left empty, `0` to `1`. A fraction rather
     * than a pixel gap so the proportions hold at any width.
     */
    candleGap?: number;
    /** Fixed body width in points. Derived from the slice when omitted. */
    candleWidth?: number;
    /** Opacity of the candles that are not under the finger. */
    fadedOpacity?: number;
    /**
     * The candle under the finger as it moves, and `-1`/`null` when it lifts.
     * This is how a readout in the card's header gets its value — that header is
     * outside the chart, so it cannot use `useCandlestickChart`.
     *
     * Fires when the index changes, not per frame.
     */
    onActiveIndexChange?: (index: number, datum: CandlestickChartDatum | null) => void;
    /** Drop the axis padding, for a dense strip with no axis or readout. */
    compact?: boolean;
    children?: ReactNode;
}
/** Imperative handle: re-run the grow-in, for a "replay" control. */
export interface CandlestickChartHandle {
    replay: () => void;
}
export interface CandlestickChartGridProps {
    /** How many lines to draw across the price axis. */
    rows?: number;
    color?: string;
    dashArray?: string;
    opacity?: number;
}
/**
 * Lines across the price axis, so a candle can be read against a number rather
 * than only against the candle beside it.
 */
declare function CandlestickChartGrid({ rows, color, dashArray, opacity, }: CandlestickChartGridProps): import("react").JSX.Element;
declare namespace CandlestickChartGrid {
    var displayName: string;
    var layer: Layer;
}
export interface CandlestickChartCandlesProps {
    /** Colour of a period that closed at or above its open. Green by default. */
    risingColor?: string;
    /** Colour of a period that closed below its open. Red by default. */
    fallingColor?: string;
    /** Corner radius on a body. */
    cornerRadius?: number;
}
/**
 * The candles.
 *
 * Four paths, not four per candle: rising bodies, falling bodies, and the wicks
 * behind each. A chart of two hundred periods is the same four animated props
 * a frame as a chart of twenty, and the split by direction is what lets each
 * half carry its own fill without a fill per mark.
 *
 * The wicks are drawn first so the bodies sit over them, which is what makes a
 * body with a wick behind it read as one mark rather than as a line crossing a
 * rectangle.
 */
declare function CandlestickChartCandles({ risingColor, fallingColor, cornerRadius, }: CandlestickChartCandlesProps): import("react").JSX.Element | null;
declare namespace CandlestickChartCandles {
    var displayName: string;
    var layer: Layer;
}
export interface CandlestickChartXAxisProps {
    /** How many labels to show. Derived from the room available when omitted. */
    ticks?: number;
    /** Format a row's label. Defaults to the value at `xDataKey`. */
    format?: (datum: CandlestickChartDatum, index: number) => string;
    className?: string;
}
/**
 * The period labels, one under each candle it has room for. Real text rather
 * than SVG text, so they follow the theme's font and the platform's text
 * scaling — SVG text does neither.
 */
declare function CandlestickChartXAxis({ ticks, format, className, }: CandlestickChartXAxisProps): import("react").JSX.Element;
declare namespace CandlestickChartXAxis {
    var displayName: string;
    var layer: Layer;
}
export interface CandlestickChartYAxisProps {
    /** How many labels to show along the price axis. */
    ticks?: number;
    /** Format a price for its label. Defaults to a compact number. */
    format?: (value: number) => string;
    className?: string;
}
/** Price labels down the side, aligned to the grid lines. */
declare function CandlestickChartYAxis({ ticks, format, className, }: CandlestickChartYAxisProps): import("react").JSX.Element;
declare namespace CandlestickChartYAxis {
    var displayName: string;
    var layer: Layer;
    var axis: "y";
}
export interface CandlestickChartTooltipProps {
    /** Format one of the four prices. Defaults to a compact number. */
    formatValue?: (value: number, field: 'open' | 'high' | 'low' | 'close') => string;
    /** Format the readout's heading from the row. Defaults to the value at xDataKey. */
    formatX?: (datum: CandlestickChartDatum) => string;
    /** Show the period's change from open to close under the four prices. */
    showChange?: boolean;
    className?: string;
    /**
     * How long a press has to be held before the readout takes the touch, in
     * milliseconds.
     *
     * Until then the touch belongs to whatever else wants it: a quick tap still
     * reaches a button floating over the chart, and a swipe still scrolls the
     * screen the chart sits in. Set `0` to read on contact, only for a chart with
     * nothing over it and no scroll view around it.
     */
    activateAfterLongPress?: number;
}
/**
 * The readout, and the gesture that drives it.
 *
 * There is no crosshair. A candle is already the thing being pointed at, so
 * highlighting it and dimming the rest says the same thing without drawing a
 * line through the chart.
 *
 * The hit area is the whole plot. A readout you have to land on a candle to
 * summon is a readout nobody finds — and candles are thin.
 */
declare function CandlestickChartTooltip({ formatValue, formatX, showChange, className, activateAfterLongPress, }: CandlestickChartTooltipProps): import("react").JSX.Element | null;
declare namespace CandlestickChartTooltip {
    var displayName: string;
    var layer: Layer;
}
export interface CandlestickChartHeaderProps extends ViewProps {
    className?: string;
    /** Small line above the value — what the chart is of. */
    title?: string;
    /** The readout. The largest thing on the card, and the first thing read. */
    value?: string;
    /** One muted line under the value — a period, a comparison, a change. */
    caption?: string;
    /** Name the two colours, for a reader who has not met the convention. */
    legend?: boolean;
    /** What the rising colour is called. */
    risingLabel?: string;
    /** What the falling colour is called. */
    fallingLabel?: string;
    /** Trailing slot — a control, a badge, a range picker. Wins over `legend`. */
    children?: ReactNode;
}
/**
 * The strip above the plot: what the chart is of, what it currently reads, and
 * what the two colours mean.
 *
 * It belongs to the chart rather than to the card around it because it is about
 * the *plot* — the number changes as a finger moves along the candles. The
 * card's header is a caption on the tray the chart sits in; this is the chart
 * introducing itself.
 *
 * The value is not derived here. A readout that follows the finger belongs to
 * whoever owns the data — take it from `onActiveIndexChange` and pass the
 * formatted string down, so one header can show the latest close when nothing
 * is pressed and a period's close when something is.
 */
declare function CandlestickChartHeader({ className, title, value, caption, legend, risingLabel, fallingLabel, children, ...props }: CandlestickChartHeaderProps): import("react").JSX.Element;
declare namespace CandlestickChartHeader {
    var displayName: string;
    var layer: Layer;
}
export interface CandlestickChartLegendProps extends ViewProps {
    className?: string;
    /** What the rising colour is called. */
    risingLabel?: string;
    /** What the falling colour is called. */
    fallingLabel?: string;
}
/** The two colours and what they mean, floated over the plot. */
declare function CandlestickChartLegend({ className, risingLabel, fallingLabel, ...props }: CandlestickChartLegendProps): import("react").JSX.Element;
declare namespace CandlestickChartLegend {
    var displayName: string;
    var layer: Layer;
}
export declare const CandlestickChart: import("react").ForwardRefExoticComponent<CandlestickChartProps & import("react").RefAttributes<CandlestickChartHandle>> & {
    Header: typeof CandlestickChartHeader;
    Grid: typeof CandlestickChartGrid;
    Candles: typeof CandlestickChartCandles;
    XAxis: typeof CandlestickChartXAxis;
    YAxis: typeof CandlestickChartYAxis;
    Tooltip: typeof CandlestickChartTooltip;
    Legend: typeof CandlestickChartLegend;
};
export {};
//# sourceMappingURL=index.d.ts.map