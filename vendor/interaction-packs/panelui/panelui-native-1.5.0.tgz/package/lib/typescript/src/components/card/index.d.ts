import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
declare const footerVariants: import("tailwind-variants").TVReturnType<{
    /**
     * Whether the footer draws a surface of its own.
     *
     * `plain` is part of the card: same background, padding continuing from the
     * content above it. `panel` is a band set into it — a rule across the top,
     * a step darker, and the card's own bottom corners — so the buttons read as
     * the card's actions rather than as the last thing in its body. Use it when
     * the footer is what somebody does with the card, not more of what it says.
     */
    variant: {
        plain: "p-6 pt-0";
        panel: "rounded-b-2xl border-t border-border bg-inset p-6";
    };
}, undefined, "flex-row items-center gap-2", {
    /**
     * Whether the footer draws a surface of its own.
     *
     * `plain` is part of the card: same background, padding continuing from the
     * content above it. `panel` is a band set into it — a rule across the top,
     * a step darker, and the card's own bottom corners — so the buttons read as
     * the card's actions rather than as the last thing in its body. Use it when
     * the footer is what somebody does with the card, not more of what it says.
     */
    variant: {
        plain: "p-6 pt-0";
        panel: "rounded-b-2xl border-t border-border bg-inset p-6";
    };
}, undefined, import("tailwind-variants").TVReturnTypeLike<{
    /**
     * Whether the footer draws a surface of its own.
     *
     * `plain` is part of the card: same background, padding continuing from the
     * content above it. `panel` is a band set into it — a rule across the top,
     * a step darker, and the card's own bottom corners — so the buttons read as
     * the card's actions rather than as the last thing in its body. Use it when
     * the footer is what somebody does with the card, not more of what it says.
     */
    variant: {
        plain: "p-6 pt-0";
        panel: "rounded-b-2xl border-t border-border bg-inset p-6";
    };
}, undefined>>;
export interface CardProps extends ViewProps {
    className?: string;
}
export interface CardFooterProps extends CardProps, VariantProps<typeof footerVariants> {
}
export declare const Card: import("react").ForwardRefExoticComponent<CardProps & import("react").RefAttributes<ViewRef>> & {
    Header: import("react").ForwardRefExoticComponent<CardProps & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Description: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Content: import("react").ForwardRefExoticComponent<CardProps & import("react").RefAttributes<ViewRef>>;
    Footer: import("react").ForwardRefExoticComponent<CardFooterProps & import("react").RefAttributes<ViewRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map