export declare function normalizeCarouselIndex(index: number, count: number, loop: boolean): number;
interface CarouselIndexLifecycleOptions {
    requestedIndex: number;
    count: number;
    countKnown: boolean;
    loop: boolean;
    onCorrection: (index: number) => void;
    onSettledIndex: (index: number) => void;
}
/** Keeps the rendered position inside the current run and reports corrections once. */
export declare function useCarouselIndexLifecycle({ requestedIndex, count, countKnown, loop, onCorrection, onSettledIndex, }: CarouselIndexLifecycleOptions): number;
interface CarouselAutoplayOptions {
    enabled: boolean;
    index: number;
    count: number;
    loop: boolean;
    interval: number;
    onAdvance: (index: number) => void;
}
/** One autoplay request per accepted index; configuration changes re-arm it. */
export declare function useCarouselAutoplay({ enabled, index, count, loop, interval, onAdvance, }: CarouselAutoplayOptions): void;
export {};
//# sourceMappingURL=carousel-lifecycle.d.ts.map