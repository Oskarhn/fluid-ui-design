/**
 * Carousel — a run of slides, one at a time, dragged with a finger.
 *
 * ```tsx
 * <Carousel loop>
 *   <Carousel.Content className="h-56">
 *     {photos.map((photo) => (
 *       <Carousel.Item key={photo.id}>
 *         <Image source={{ uri: photo.uri }} className="h-full w-full" />
 *       </Carousel.Item>
 *     ))}
 *   </Carousel.Content>
 *   <Carousel.Controls />
 * </Carousel>
 * ```
 *
 * ## One shared value, four layouts
 *
 * Everything is driven from a single `progress` — the position in the run, as a
 * fractional index. `2.4` is two-fifths of the way from the third slide to the
 * fourth, and every slide styles itself from its own distance to that number.
 * A pan writes to it, a spring settles it onto a whole number, and the dots
 * read it.
 *
 * That is why the track is a pan gesture rather than a paging `ScrollView`. A
 * scroll view carries its offset natively and would serve `default` well
 * enough, but `coverflow` and `stack` do not lay their slides along a track at
 * all — they hold them in one place and pull them apart with transforms — so
 * there would be nothing for it to scroll. One mechanism all four read beats a
 * native scroller for one of them and something else for the rest.
 *
 * ## What each layout is for
 *
 * - **`default`** — a track. The honest choice for content that is read rather
 *   than admired: a row of cards, a gallery, an onboarding run.
 * - **`interactive`** — the run fans out around the middle slide and tilts away
 *   on both sides, opening wider while a finger is down. For a small set worth
 *   showing off.
 * - **`coverflow`** — the neighbours turn away from you in perspective. Best
 *   with art: covers, posters, photographs.
 * - **`stack`** — a deck. The active card is on top with the next two peeking
 *   out behind it, and dragging takes the top one away. For cards dealt with
 *   one at a time, where the pile is the point.
 *
 * Depth is carried by scale, opacity and z-order rather than by moving slides
 * along z: React Native's transform has `perspective` and `rotateY` but no
 * `translateZ`, so a slide is made to *look* further away rather than put there.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
export type CarouselVariant = 'default' | 'interactive' | 'coverflow' | 'stack';
export type CarouselOrientation = 'horizontal' | 'vertical';
export type CarouselAlign = 'start' | 'center';
/** Position and controls, for a control of your own outside the built-in ones. */
export declare function useCarouselState(): {
    index: number;
    count: number;
    scrollTo: (index: number) => void;
    next: () => void;
    previous: () => void;
};
export interface CarouselProps extends ViewProps {
    className?: string;
    /** How the slides are arranged, and how they move. */
    variant?: CarouselVariant;
    /** Which way the run travels. `stack` is always dealt sideways. */
    orientation?: CarouselOrientation;
    /** Run past the last slide back to the first, and the other way. */
    loop?: boolean;
    /**
     * Where the active slide sits. `center` is what the fanned layouts want;
     * `start` suits a row of cards running off the trailing edge. `coverflow`
     * and `stack` are always centred.
     */
    align?: CarouselAlign;
    /**
     * Length of one slide along the direction of travel, in points. Measured from
     * the carousel's own box when omitted, which is what a full-width slide
     * wants; set it for a run that shows more than one at a time.
     */
    itemSize?: number;
    /** Advance on a timer. Stops at the non-looping end or after the first touch. */
    autoplay?: boolean;
    /** Milliseconds each slide is held when `autoplay` is set. */
    autoplayInterval?: number;
    /**
     * Controlled active slide. Requests move visually only after this value changes;
     * an index invalidated by a child-count change is normalized and reported.
     */
    index?: number;
    /** Starting slide when uncontrolled. */
    defaultIndex?: number;
    onIndexChange?: (index: number) => void;
    /** Let go of the gesture, for a carousel inside something else that drags. */
    scrollEnabled?: boolean;
    children?: ReactNode;
}
/** Imperative handle, for driving the run from outside its own controls. */
export interface CarouselHandle {
    next: () => void;
    previous: () => void;
    scrollTo: (index: number) => void;
}
export interface CarouselContentProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/**
 * The box the slides live in. Give it a height — nothing inside it is in the
 * layout flow, so it has no height of its own to take.
 *
 * It does not move. Every slide places itself from `progress`, which is what
 * lets `default` and `coverflow` be one component with different arithmetic
 * rather than two different trees. The alignment here is the *resting* place
 * every slide is offset from.
 */
declare function CarouselContent({ className, children, ...props }: CarouselContentProps): import("react").JSX.Element;
export interface CarouselItemProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/** One slide. Its transform is whatever the root's `variant` asks for. */
declare function CarouselItem({ className, children, style, ...props }: CarouselItemProps): import("react").JSX.Element;
export interface CarouselCaptionProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/**
 * A slide's label, shown only while that slide is the active one.
 *
 * It lives inside the slide rather than beside the run, so it travels with what
 * it names — a caption that stays put while the picture moves belongs to the
 * carousel rather than to the picture.
 */
declare function CarouselCaption({ className, children, ...props }: CarouselCaptionProps): import("react").JSX.Element;
export interface CarouselDotsProps extends ViewProps {
    className?: string;
    /** Lay the dots down the side instead of across. */
    orientation?: CarouselOrientation;
    /** Jump to a slide by tapping its dot. */
    interactive?: boolean;
}
/**
 * One dot per slide, the active one drawn as a bar.
 *
 * Length rather than colour alone carries the position: a row that differs only
 * in opacity is unreadable at a glance, and invisible to anyone who cannot
 * separate the two greys.
 */
declare function CarouselDots({ className, orientation, interactive, ...props }: CarouselDotsProps): import("react").JSX.Element | null;
export interface CarouselArrowProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface CarouselControlsProps extends ViewProps {
    className?: string;
}
/**
 * The arrows and the dots in one pill.
 *
 * Together rather than scattered, because they answer the same question — where
 * am I in this, and how do I move — and a bar that reads as one object can sit
 * over the content instead of taking a strip of the layout for itself.
 */
declare function CarouselControls({ className, ...props }: CarouselControlsProps): import("react").JSX.Element;
export declare const Carousel: import("react").ForwardRefExoticComponent<CarouselProps & import("react").RefAttributes<CarouselHandle>> & {
    Content: typeof CarouselContent;
    Item: typeof CarouselItem;
    Caption: typeof CarouselCaption;
    Dots: typeof CarouselDots;
    Previous: {
        ({ className, children, ...props }: CarouselArrowProps): import("react").JSX.Element;
        displayName: string;
    };
    Next: {
        ({ className, children, ...props }: CarouselArrowProps): import("react").JSX.Element;
        displayName: string;
    };
    Controls: typeof CarouselControls;
};
export {};
//# sourceMappingURL=index.d.ts.map