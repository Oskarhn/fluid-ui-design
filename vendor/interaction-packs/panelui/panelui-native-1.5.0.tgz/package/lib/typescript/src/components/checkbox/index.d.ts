import { type ReactNode } from 'react';
import { type PressableProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
declare const checkboxVariants: import("tailwind-variants").TVReturnType<{
    size: {
        xs: {
            row: string;
            box: string;
            fill: string;
            label: string;
            description: string;
        };
        sm: {
            row: string;
            box: string;
            fill: string;
            label: string;
            description: string;
        };
        md: {};
        lg: {
            row: string;
            box: string;
            label: string;
        };
        xl: {
            row: string;
            box: string;
            fill: string;
            label: string;
            description: string;
        };
    };
    variant: {
        default: {};
        /**
         * The whole surface is the target — for pickable options where the
         * checkbox is a confirmation rather than the affordance itself.
         */
        card: {
            row: string;
            label: string;
        };
    };
    checked: {
        true: {};
    };
    disabled: {
        true: {
            row: string;
        };
    };
}, {
    row: string;
    box: string;
    fill: string;
    content: string;
    label: string;
    description: string;
}, undefined, {
    size: {
        xs: {
            row: string;
            box: string;
            fill: string;
            label: string;
            description: string;
        };
        sm: {
            row: string;
            box: string;
            fill: string;
            label: string;
            description: string;
        };
        md: {};
        lg: {
            row: string;
            box: string;
            label: string;
        };
        xl: {
            row: string;
            box: string;
            fill: string;
            label: string;
            description: string;
        };
    };
    variant: {
        default: {};
        /**
         * The whole surface is the target — for pickable options where the
         * checkbox is a confirmation rather than the affordance itself.
         */
        card: {
            row: string;
            label: string;
        };
    };
    checked: {
        true: {};
    };
    disabled: {
        true: {
            row: string;
        };
    };
}, {
    row: string;
    box: string;
    fill: string;
    content: string;
    label: string;
    description: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        xs: {
            row: string;
            box: string;
            fill: string;
            label: string;
            description: string;
        };
        sm: {
            row: string;
            box: string;
            fill: string;
            label: string;
            description: string;
        };
        md: {};
        lg: {
            row: string;
            box: string;
            label: string;
        };
        xl: {
            row: string;
            box: string;
            fill: string;
            label: string;
            description: string;
        };
    };
    variant: {
        default: {};
        /**
         * The whole surface is the target — for pickable options where the
         * checkbox is a confirmation rather than the affordance itself.
         */
        card: {
            row: string;
            label: string;
        };
    };
    checked: {
        true: {};
    };
    disabled: {
        true: {
            row: string;
        };
    };
}, {
    row: string;
    box: string;
    fill: string;
    content: string;
    label: string;
    description: string;
}>>;
/** How big a checkbox is. */
export type CheckboxSize = NonNullable<VariantProps<typeof checkboxVariants>['size']>;
export interface CheckboxProps extends VariantProps<typeof checkboxVariants>, Omit<PressableProps, 'children' | 'disabled' | 'onPress' | 'style' | 'accessibilityRole' | 'accessibilityState'> {
    /**
     * Styles the pressable row — layout, border, fill. It does not reach the
     * label: text colour is not inherited from a view in React Native, so use
     * `labelClassName` for that.
     */
    className?: string;
    checked: boolean;
    onCheckedChange?: (checked: boolean) => void;
    /**
     * A third, in-between state for a box that governs a group of others — some
     * on, some off. It fills like a checked box but shows a dash rather than a
     * tick, and announces itself as `mixed` to a screen reader. Pressing it
     * resolves the ambiguity by turning the whole group on, so the press reports
     * `true`. `indeterminate` overrides `checked` for what is drawn.
     */
    indeterminate?: boolean;
    disabled?: boolean;
    /**
     * Optional label rendered next to the box; pressing it also toggles.
     *
     * A string is the usual case. Pass text nodes instead to put a link inside
     * the sentence — `<>I agree to the <Text onPress={open}>Terms</Text></>` —
     * and the link's own press wins over the toggle. A screen reader cannot
     * read a node as the checkbox's name, so pass `accessibilityLabel` with it.
     */
    label?: ReactNode;
    /** Classes for the label text, merged over the defaults — e.g. `text-black`. */
    labelClassName?: string;
    /**
     * Classes for the view holding the label and description, merged over
     * `flex-1 gap-0.5`. The default makes the text fill the row; pass
     * `flex-none` to size it to the text when the checkbox shares a line with
     * other content, such as a "Forgot password" link.
     */
    contentClassName?: string;
    /** Secondary line under the label, for extra context. */
    description?: string;
    /** Classes for the description text, merged over the defaults. */
    descriptionClassName?: string;
}
export declare const Checkbox: import("react").ForwardRefExoticComponent<CheckboxProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map