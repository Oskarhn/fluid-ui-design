/**
 * Chip — a compact, interactive token.
 *
 * Where Badge only shows and ToggleButton owns a stateful toolbar, Chip is the
 * thing in between: a small pill you can *press*, mark as *selected*, or
 * *remove*. It is the filter in a filter bar, the tag on a photo, the removable
 * recipient in a "To:" field — small, dense, and touchable.
 *
 * The close button is its own hit target nested inside the pill, so tapping the
 * ✕ removes the chip without also firing the chip's own `onPress`. That split
 * is the whole reason a removable chip needs a component and not just a styled
 * Badge.
 *
 * ```tsx
 * <Chip>Design</Chip>
 *
 * <Chip variant="info" onClose={() => remove('design')}>Design</Chip>
 *
 * <Chip selected={on} onPress={() => setOn(!on)}>
 *   <CheckIcon size={14} />
 *   <Chip.Label>Available</Chip.Label>
 * </Chip>
 * ```
 */
import { type ReactNode } from 'react';
import { type VariantProps } from 'tailwind-variants';
import { type AnimatedPressableProps } from '../../primitives/animated-pressable.js';
import type { ViewRef } from '../../primitives/refs.js';
declare const chipVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        /** The resting tag — a quiet neutral fill. */
        default: {
            root: string;
            label: string;
        };
        /** The accent fill, for the one chip that leads. */
        primary: {
            root: string;
            label: string;
        };
        /** Just an outline — the lightest a chip gets while still being a shape. */
        outline: {
            root: string;
            label: string;
        };
        success: {
            root: string;
            label: string;
        };
        warning: {
            root: string;
            label: string;
        };
        info: {
            root: string;
            label: string;
        };
        destructive: {
            root: string;
            label: string;
        };
    };
    size: {
        xs: {
            root: string;
            label: string;
        };
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
        xl: {
            root: string;
            label: string;
        };
    };
    /**
     * The filter "on" state — a loud accent surface that wins over the resting
     * variant, so any chip can be a filter without picking a second colour.
     */
    selected: {
        true: {
            root: string;
            label: string;
        };
    };
    /** Trims the trailing padding so the close target hugs the right edge. */
    closable: {
        true: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    label: string;
    close: string;
}, undefined, {
    variant: {
        /** The resting tag — a quiet neutral fill. */
        default: {
            root: string;
            label: string;
        };
        /** The accent fill, for the one chip that leads. */
        primary: {
            root: string;
            label: string;
        };
        /** Just an outline — the lightest a chip gets while still being a shape. */
        outline: {
            root: string;
            label: string;
        };
        success: {
            root: string;
            label: string;
        };
        warning: {
            root: string;
            label: string;
        };
        info: {
            root: string;
            label: string;
        };
        destructive: {
            root: string;
            label: string;
        };
    };
    size: {
        xs: {
            root: string;
            label: string;
        };
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
        xl: {
            root: string;
            label: string;
        };
    };
    /**
     * The filter "on" state — a loud accent surface that wins over the resting
     * variant, so any chip can be a filter without picking a second colour.
     */
    selected: {
        true: {
            root: string;
            label: string;
        };
    };
    /** Trims the trailing padding so the close target hugs the right edge. */
    closable: {
        true: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    label: string;
    close: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        /** The resting tag — a quiet neutral fill. */
        default: {
            root: string;
            label: string;
        };
        /** The accent fill, for the one chip that leads. */
        primary: {
            root: string;
            label: string;
        };
        /** Just an outline — the lightest a chip gets while still being a shape. */
        outline: {
            root: string;
            label: string;
        };
        success: {
            root: string;
            label: string;
        };
        warning: {
            root: string;
            label: string;
        };
        info: {
            root: string;
            label: string;
        };
        destructive: {
            root: string;
            label: string;
        };
    };
    size: {
        xs: {
            root: string;
            label: string;
        };
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
        xl: {
            root: string;
            label: string;
        };
    };
    /**
     * The filter "on" state — a loud accent surface that wins over the resting
     * variant, so any chip can be a filter without picking a second colour.
     */
    selected: {
        true: {
            root: string;
            label: string;
        };
    };
    /** Trims the trailing padding so the close target hugs the right edge. */
    closable: {
        true: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    label: string;
    close: string;
}>>;
type ChipVariantProps = VariantProps<typeof chipVariants>;
export type ChipVariant = NonNullable<ChipVariantProps['variant']>;
export type ChipSize = NonNullable<ChipVariantProps['size']>;
interface ChipStateValue {
    selected: boolean;
    disabled: boolean;
}
/**
 * The chip's own state, for anything rendered inside it — an icon that swaps
 * when the chip is selected, a count that only shows when it is on.
 */
export declare function useChip(): ChipStateValue;
export interface ChipProps extends Omit<AnimatedPressableProps, 'children' | 'disabled'>, Omit<ChipVariantProps, 'selected' | 'disabled' | 'closable'> {
    children?: ReactNode;
    className?: string;
    /** Extra classes for the label when `children` is a string. */
    labelClassName?: string;
    /**
     * The filter "on" state. Setting it (even to `false`) makes the chip a
     * toggle, announced as such — pair it with `onPress` to flip it.
     */
    selected?: boolean;
    disabled?: boolean;
    /** A leading icon or avatar, before the label. */
    start?: ReactNode;
    /**
     * Shows a trailing ✕ and calls this when it is pressed. The ✕ is its own hit
     * target, so removing a chip never also fires its `onPress`.
     */
    onClose?: () => void;
    /** Accessibility label for the ✕. Defaults to "Remove". */
    closeLabel?: string;
    /**
     * A tick under the finger when the chip is pressed or removed. Off by
     * default — needs the optional `expo-haptics`, and is silent without it.
     */
    haptics?: boolean;
}
export interface ChipLabelProps {
    className?: string;
    children: ReactNode;
}
/**
 * The label, when the chip holds more than a string — an icon beside text. It
 * reads the selected state itself, so composing the two does not mean threading
 * the colour through by hand.
 */
declare function ChipLabel({ className, children }: ChipLabelProps): import("react").JSX.Element;
declare namespace ChipLabel {
    var displayName: string;
}
export declare const Chip: import("react").ForwardRefExoticComponent<ChipProps & import("react").RefAttributes<ViewRef>> & {
    Label: typeof ChipLabel;
};
export {};
//# sourceMappingURL=index.d.ts.map