import { type ViewProps } from 'react-native';
export interface CircularTextProps extends Omit<ViewProps, 'children'> {
    /**
     * The text to set around the circle. A string, not elements: each character
     * is placed and turned on its own, so there is nothing for markup inside it
     * to apply to.
     */
    children: string;
    /**
     * Points from the centre of the ring to the outside of the text.
     *
     * It is also half the component's width and height — the ring is a square
     * that measures `radius * 2` on both axes, and the characters hang inside
     * its edge. Nothing is laid out around it, so give the space it needs.
     */
    radius?: number;
    /**
     * Milliseconds for one full turn. Slow by default: it is decoration, and a
     * ring that turns at the speed of a spinner reads as something loading.
     */
    spinDuration?: number;
    /** Turn anticlockwise. */
    reverse?: boolean;
    /**
     * Hold the ring where it is.
     *
     * It stops in place rather than returning to the top, and resumes from
     * there, so a ring paused mid-word is still on that word when it starts
     * again.
     */
    paused?: boolean;
    /**
     * Degrees of the circle the text is spread across. The whole way round by
     * default.
     *
     * A full turn has no last gap, since the end of the string is adjacent to
     * its start. Anything less is an arc with two ends, and the text reaches
     * both of them.
     */
    spread?: number;
    /** Degrees clockwise from the top that the first character sits at. */
    startAngle?: number;
    /** Classes for the ring's own box. */
    className?: string;
    /** Classes for the characters — size, weight, colour, tracking. */
    textClassName?: string;
}
/**
 * Text set around a circle, turning.
 *
 * For a badge, a seal, a mark around a logo: decoration whose job is to be a
 * shape first and a sentence second. The characters are placed one at a time
 * and each is turned to sit square on the curve, so the ring closes and the
 * text at the bottom is upside down — which is what makes it read as a
 * circle rather than as a sentence bent into one.
 *
 * The centre is left empty and nothing is laid out inside it. Put a logo
 * there by stacking the two, rather than by passing it as a child.
 *
 * The turn runs entirely on the UI thread, and under the platform's
 * reduce-motion setting the ring is drawn once and held still. Not a slower
 * turn — none. The shape carries the whole meaning; the rotation is the part
 * that setting exists to remove.
 */
export declare function CircularText({ children, radius, spinDuration, reverse, paused, spread, startAngle, className, textClassName, style, ...props }: CircularTextProps): import("react").JSX.Element;
export declare namespace CircularText {
    var displayName: string;
}
//# sourceMappingURL=index.d.ts.map