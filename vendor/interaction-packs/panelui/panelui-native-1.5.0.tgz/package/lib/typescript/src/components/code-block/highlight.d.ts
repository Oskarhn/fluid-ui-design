/**
 * A small syntax highlighter, sized for a phone.
 *
 * The web answer to this problem is a real tokenizer with a grammar per
 * language, which is megabytes of WASM and a worker. That is the wrong shape
 * here twice over: a chat renders short fragments rather than files, and the
 * fragments arrive a token at a time, so whatever runs has to run again on
 * every frame of a stream. This trades exactness for a single pass of regex
 * that costs nothing and never blocks.
 *
 * What it therefore does *not* do: nested languages, template-literal
 * interpolation, or anything requiring a parser to know it. What it does do is
 * make a keyword look like a keyword, which is the whole of the value in a
 * twelve-line snippet.
 *
 * Anything it does not recognise is returned as one plain token per line, so
 * an unknown language renders as clean monospace rather than as a guess.
 */
/** The kinds a token can be. Each maps to one theme colour. */
export type TokenKind = 'plain' | 'keyword' | 'string' | 'number' | 'comment' | 'function' | 'property' | 'punctuation' | 'inserted' | 'deleted';
export interface Token {
    text: string;
    kind: TokenKind;
}
/** The languages that get more than plain monospace. */
export type CodeLanguage = 'ts' | 'tsx' | 'js' | 'jsx' | 'json' | 'bash' | 'python' | 'css' | 'html' | 'sql' | 'markdown' | 'diff' | 'text';
/** Resolves a caller's language string. Unknown spellings become `text`. */
export declare function resolveLanguage(language: string | undefined): CodeLanguage;
/**
 * Splits code into lines of tokens.
 *
 * Line by line, so a stream that has just gained a character only makes the
 * work grow with the code and never with time. The cost of that choice is that
 * a block comment spanning several lines is only coloured on its first — an
 * acceptable trade for a snippet, and the reason this is not sold as a
 * highlighter for a file.
 */
export declare function highlight(code: string, language: string | undefined): Token[][];
//# sourceMappingURL=highlight.d.ts.map