/**
 * CodeBlock — a fenced snippet, syntax-coloured and scrolled sideways.
 *
 * Code does not wrap. Wrapping a line of code puts the continuation under the
 * indentation and the two stop meaning different things, so the body scrolls
 * horizontally instead — which on a phone is the only honest way to show a
 * ninety-column line.
 *
 * ```tsx
 * <CodeBlock code={code} language="tsx">
 *   <CodeBlock.Header>
 *     <CodeBlock.Filename>calendar.tsx</CodeBlock.Filename>
 *     <CodeBlock.CopyButton />
 *   </CodeBlock.Header>
 * </CodeBlock>
 * ```
 *
 * ## Colouring
 *
 * The highlighter is a single pass of regex, shipped in the component, over the
 * languages a chat actually streams. There is no grammar and no worker, because
 * the alternative costs megabytes and has to run again on every frame of a
 * stream. It gets keywords, strings, comments and numbers right in a twelve-line
 * snippet and does not pretend to more; an unrecognised language renders as
 * clean monospace rather than as a guess. Colours come from the theme's
 * `--color-code-*` tokens, so a snippet follows light and dark like everything
 * else.
 *
 * ## Where the props come from
 *
 * With the AI SDK, `code` and `language` are what you pull out of a fenced
 * block in a text part, or the fields of a tool call that wrote a file.
 */
import { type ReactNode } from 'react';
import { type TextProps, type ViewProps } from 'react-native';
export interface CodeBlockProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** The snippet. */
    code: string;
    /**
     * What it is written in. `ts`, `tsx`, `js`, `jsx`, `json`, `bash`, `python`,
     * `css`, `html`, `sql`, `markdown` and `diff` are coloured, along with the
     * usual spellings of each; anything else renders as plain monospace.
     */
    language?: string;
    /** Number the lines in a gutter down the leading edge. */
    showLineNumbers?: boolean;
    /** A header, and anything else that goes above the code. */
    children?: ReactNode;
}
declare function CodeBlockRoot({ className, code, language, showLineNumbers, children, ...props }: CodeBlockProps): import("react").JSX.Element;
declare namespace CodeBlockRoot {
    var displayName: string;
}
export interface CodeBlockHeaderProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/** The bar above the code: what the file is, and what can be done with it. */
declare function CodeBlockHeader({ className, children, ...props }: CodeBlockHeaderProps): import("react").JSX.Element;
declare namespace CodeBlockHeader {
    var displayName: string;
}
export interface CodeBlockFilenameProps extends TextProps {
    className?: string;
    children?: ReactNode;
}
declare function CodeBlockFilename({ className, children, ...props }: CodeBlockFilenameProps): import("react").JSX.Element;
declare namespace CodeBlockFilename {
    var displayName: string;
}
export interface CodeBlockLanguageProps extends TextProps {
    className?: string;
    children?: ReactNode;
}
/** The language, for a block with no filename to name it by. */
declare function CodeBlockLanguage({ className, children, ...props }: CodeBlockLanguageProps): import("react").JSX.Element;
declare namespace CodeBlockLanguage {
    var displayName: string;
}
export interface CodeBlockActionsProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
declare function CodeBlockActions({ className, children, ...props }: CodeBlockActionsProps): import("react").JSX.Element;
declare namespace CodeBlockActions {
    var displayName: string;
}
export interface CodeBlockCopyButtonProps {
    className?: string;
    /** How long the tick stays up before turning back into the copy glyph. */
    timeout?: number;
    onCopy?: () => void;
}
/**
 * Copies the block's code.
 *
 * The tick is the whole feedback: there is no toast, because a snippet in a
 * transcript is copied often and a notification for each one is noise.
 */
declare function CodeBlockCopyButton({ className, timeout, onCopy }: CodeBlockCopyButtonProps): import("react").JSX.Element;
declare namespace CodeBlockCopyButton {
    var displayName: string;
}
export { resolveLanguage, type CodeLanguage, type Token, type TokenKind } from './highlight.js';
export declare const CodeBlock: typeof CodeBlockRoot & {
    Header: typeof CodeBlockHeader;
    Filename: typeof CodeBlockFilename;
    Language: typeof CodeBlockLanguage;
    Actions: typeof CodeBlockActions;
    CopyButton: typeof CodeBlockCopyButton;
};
//# sourceMappingURL=index.d.ts.map