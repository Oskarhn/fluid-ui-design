/**
 * Collapsible — one section of content that a header shows and hides.
 *
 * ```tsx
 * <Collapsible variant="surface">
 *   <Collapsible.Trigger>
 *     Delivery options
 *     <Collapsible.Indicator />
 *   </Collapsible.Trigger>
 *   <Collapsible.Content>
 *     <Text>Anything, of any height.</Text>
 *   </Collapsible.Content>
 * </Collapsible>
 * ```
 *
 * ## Why this and not a one-item Accordion
 *
 * The two look the same and differ in what happens to the body when it closes.
 * An accordion unmounts it, which is right when a closed section should cost
 * nothing and there is nothing inside worth keeping.
 *
 * This one keeps the body mounted and animates its height, so what is inside
 * survives being closed — a part-filled form still has what was typed into it,
 * a list is still scrolled to where it was, a video is still part-way through.
 * That is the case this component exists for; reach for `Accordion` when
 * sections are mutually exclusive or the body is expensive and rarely opened.
 *
 * ## The body is mounted whether or not it is open
 *
 * A height cannot be animated from `auto`, so the content has to be measured
 * before it can be travelled to, and measuring it means rendering it. There is
 * no lazy version of that: a body that has never been opened has still been
 * rendered once. For a body heavy enough that this matters, an `Accordion` with
 * a single item unmounts it instead.
 *
 * ## Reduced motion
 *
 * With the operating system set to reduce motion the panel snaps between its
 * two states and the chevron turns without travelling. The disclosure still
 * happens — it is the movement that is dropped, not the change.
 */
import { type ReactNode } from 'react';
import { type PressableProps, type ViewProps } from 'react-native';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
export type CollapsibleVariant = 'default' | 'surface' | 'ghost';
export interface CollapsibleProps extends ViewProps {
    className?: string;
    variant?: CollapsibleVariant;
    /** Whether the body is showing, controlled. */
    open?: boolean;
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** Stops the trigger opening or closing it, and marks it disabled to a screen reader. */
    isDisabled?: boolean;
    children?: ReactNode;
}
export interface CollapsibleTriggerProps extends Omit<PressableProps, 'children'> {
    className?: string;
    children?: ReactNode;
}
export interface CollapsibleIndicatorProps extends ViewProps {
    className?: string;
    /** Replaces the default chevron. */
    children?: ReactNode;
}
export interface CollapsibleContentProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export declare const Collapsible: import("react").ForwardRefExoticComponent<CollapsibleProps & import("react").RefAttributes<ViewRef>> & {
    Trigger: import("react").ForwardRefExoticComponent<CollapsibleTriggerProps & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Indicator: import("react").ForwardRefExoticComponent<CollapsibleIndicatorProps & import("react").RefAttributes<ViewRef>>;
    Content: import("react").ForwardRefExoticComponent<CollapsibleContentProps & import("react").RefAttributes<ViewRef>>;
};
//# sourceMappingURL=index.d.ts.map