/**
 * ColorPicker — a colour chosen by dragging, not by typing.
 *
 * The controls are the colour model made visible: a square where saturation
 * runs across and brightness runs up, under a hue picked on its own scale.
 * That is why the component stores hue, saturation, value and alpha rather
 * than the string it hands back — a fully black colour is `#000` whatever hue
 * and saturation produced it, so a picker that stored the output would lose
 * the thumb the moment you dragged into a corner and could not put it back.
 *
 * Nothing about a drag crosses to JavaScript. The four channels are shared
 * values; the hue behind the square, both thumb fills and the preview swatch
 * are `backgroundColor`s computed from them on the UI thread, and the
 * translucency ramp on the alpha track is a gradient used as a mask over a
 * solid fill rather than a gradient whose colours have to be re-declared from
 * React on every frame. The picked colour bridges back on change and again on
 * release, the same as any other input here.
 *
 * ```tsx
 * <ColorPicker defaultValue="#22c55e" onValueCommit={setBrand}>
 *   <ColorPicker.Area />
 *   <ColorPicker.Hue />
 *   <ColorPicker.Preview showValue />
 * </ColorPicker>
 * ```
 *
 * Composition is the API: a picker is whichever of the parts you put in it, so
 * a control with no alpha is one that has no `ColorPicker.Alpha`, not one with
 * a prop turned off.
 *
 * ## Folding it away
 *
 * A picker is a page's worth of controls in service of one value, and that
 * value is read far more often than it is changed — so `presentation` puts the
 * controls behind the row that reads it out:
 *
 * ```tsx
 * <ColorPicker value={accent} onValueChange={setAccent} presentation="popover">
 *   <ColorPicker.Trigger>
 *     <ColorPicker.Field label="Accent" />
 *   </ColorPicker.Trigger>
 *   <ColorPicker.Content>
 *     <ColorPicker.Area />
 *     <ColorPicker.Hue />
 *   </ColorPicker.Content>
 * </ColorPicker>
 * ```
 *
 * `Content` re-provides the picker's context around what it holds, because the
 * panel is portalled above the rest of the screen and is therefore no longer
 * below the picker in the tree by the time the parts inside it go looking.
 *
 * Works controlled (`value` + `onValueChange`) or uncontrolled (`defaultValue`).
 */
import { type ReactElement, type ReactNode } from 'react';
import { type VariantProps } from 'tailwind-variants';
import { type ColorFormat } from '../../utils/color.js';
import { type PopoverContentProps } from '../popover/index.js';
import type { ViewRef } from '../../primitives/refs.js';
declare const colorPickerVariants: import("tailwind-variants").TVReturnType<{
    size: {
        sm: {};
        md: {};
        lg: {};
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    area: string;
    wheel: string;
    thumb: string;
    thumbFill: string;
    track: string;
    swatches: string;
    swatch: string;
    swatchRing: string;
    preview: string;
    previewSwatch: string;
    previewValue: string;
    field: string;
    fieldLabel: string;
    fieldValue: string;
    fieldSwatch: string;
    channel: string;
    channelValue: string;
    channelLabel: string;
}, undefined, {
    size: {
        sm: {};
        md: {};
        lg: {};
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    area: string;
    wheel: string;
    thumb: string;
    thumbFill: string;
    track: string;
    swatches: string;
    swatch: string;
    swatchRing: string;
    preview: string;
    previewSwatch: string;
    previewValue: string;
    field: string;
    fieldLabel: string;
    fieldValue: string;
    fieldSwatch: string;
    channel: string;
    channelValue: string;
    channelLabel: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        sm: {};
        md: {};
        lg: {};
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    area: string;
    wheel: string;
    thumb: string;
    thumbFill: string;
    track: string;
    swatches: string;
    swatch: string;
    swatchRing: string;
    preview: string;
    previewSwatch: string;
    previewValue: string;
    field: string;
    fieldLabel: string;
    fieldValue: string;
    fieldSwatch: string;
    channel: string;
    channelValue: string;
    channelLabel: string;
}>>;
type ColorPickerVariantProps = VariantProps<typeof colorPickerVariants>;
export type ColorPickerSize = NonNullable<ColorPickerVariantProps['size']>;
/** How the controls get onto the screen. */
export type ColorPickerPresentation = 'inline' | 'popover' | 'bottom-sheet';
export interface ColorPickerProps extends Omit<ColorPickerVariantProps, 'disabled'> {
    className?: string;
    /** Controlled colour. Leave unset and pass `defaultValue` to run uncontrolled. */
    value?: string;
    /** Starting colour when uncontrolled. */
    defaultValue?: string;
    /**
     * Fires on every frame of a drag — cheap updates only. The string is written
     * in `format`.
     */
    onValueChange?: (color: string) => void;
    /** Fires once when a drag ends. The place for expensive side effects. */
    onValueCommit?: (color: string) => void;
    /**
     * How the colour is written on the way out. `hex` gains an `#rrggbbaa` alpha
     * pair, and the other two switch to their `a` forms, only when the colour is
     * actually translucent.
     */
    format?: ColorFormat;
    disabled?: boolean;
    /**
     * A tick when a drag ends and when a preset is picked. Off by default — needs
     * the optional `expo-haptics`, and is silent without it. There is no tick
     * during a drag: a colour has no steps to cross, so a tick could only be a
     * buzz proportional to speed.
     */
    haptics?: boolean;
    /**
     * How the controls get onto the screen.
     *
     * `inline` stacks them where they are written, and is the default. The other
     * two put them behind a `ColorPicker.Trigger` and draw them in a
     * `ColorPicker.Content` — which is the arrangement a colour usually wants,
     * since a picker is a page's worth of controls in service of one value that
     * is looked at far more often than it is changed.
     */
    presentation?: ColorPickerPresentation;
    /** Controlled open state of the panel. Ignored by `inline`. */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** The parts, in the order they should stack. */
    children: ReactNode;
}
export interface ColorPickerTriggerProps {
    /** One element, cloned with an `onPress` that opens the panel. */
    children: ReactElement<{
        onPress?: (...args: unknown[]) => void;
    }>;
}
/**
 * What you press to open the picker. `ColorPicker.Field` is the obvious child —
 * it already reads out the colour it would let you change — but anything that
 * takes an `onPress` will do.
 */
declare function ColorPickerTrigger({ children }: ColorPickerTriggerProps): import("react").JSX.Element;
declare namespace ColorPickerTrigger {
    var displayName: string;
}
export interface ColorPickerContentProps extends PopoverContentProps {
}
/**
 * The panel the controls are drawn in.
 *
 * It re-provides the picker's context around its children, and has to: the
 * panel is rendered through a portal, above everything else on the screen, so
 * by the time the parts inside it look for the picker they are no longer
 * anywhere below it in the tree. Without this the first `ColorPicker.Area`
 * inside a popover would throw.
 *
 * Defaults to the trigger's width, floored, so a panel opened from a labelled
 * strip lines up under it rather than announcing itself as a different object.
 */
declare function ColorPickerContent({ className, width, minWidth, children, ...props }: ColorPickerContentProps): import("react").JSX.Element;
declare namespace ColorPickerContent {
    var displayName: string;
}
export interface ColorPickerAreaProps {
    className?: string;
    /** Height of the square in points. Defaults to the picker's size. */
    height?: number;
    /** Extra classes for the draggable thumb. */
    thumbClassName?: string;
}
export interface ColorPickerHueProps {
    className?: string;
    /** Extra classes for the draggable thumb. */
    thumbClassName?: string;
}
export interface ColorPickerAlphaProps {
    className?: string;
    /** Extra classes for the draggable thumb. */
    thumbClassName?: string;
}
export interface ColorPickerPreviewProps {
    className?: string;
    /**
     * Print the colour beside the swatch, in the picker's `format`. The string
     * is built on the UI thread and only crosses to JavaScript when it differs
     * from the last one, so a drag that is not changing the rounded value costs
     * nothing.
     */
    showValue?: boolean;
    /** Extra classes for the swatch. */
    swatchClassName?: string;
    /** Extra classes for the printed value. */
    valueClassName?: string;
    /** Anything to put after the value — a copy button, a label. */
    children?: ReactNode;
}
export interface ColorPickerSwatchesProps {
    className?: string;
    /** The presets, in any format `ColorPicker` can read. */
    colors: string[];
    /** Diameter of one swatch in points. Defaults to the picker's size. */
    swatchSize?: number;
    /** Extra classes for one swatch. */
    swatchClassName?: string;
}
export interface ColorPickerFieldProps {
    className?: string;
    /** What the colour is for — "Accent", "Background", a layer name. */
    label?: string;
    /**
     * Print the current colour beside the swatch, in the picker's `format`.
     * On by default: the strip exists to say what the colour *is*, and a swatch
     * alone cannot be read out, copied down or typed into a design tool.
     */
    showValue?: boolean;
    /** Extra classes for the swatch. */
    swatchClassName?: string;
    /**
     * Makes the strip pressable, and a button to a screen reader.
     *
     * Mostly you do not pass this yourself: `ColorPicker.Trigger` clones the
     * strip with one, which is what turns the row into the thing that opens the
     * picker.
     */
    onPress?: (...args: unknown[]) => void;
    /** Anything to put after the swatch — a copy button, a reset. */
    children?: ReactNode;
}
/** Which channel a readout is reading. */
export type ColorPickerChannel = 'hue' | 'saturation' | 'brightness' | 'alpha';
export interface ColorPickerChannelProps {
    className?: string;
    /** Which channel to read. */
    channel: ColorPickerChannel;
    /** Overrides the channel's own name. */
    label?: string;
    /**
     * Writes the number yourself. Receives degrees for `hue` and a percentage
     * for the other three, both already rounded.
     */
    format?: (value: number) => string;
}
export interface ColorPickerBrightnessProps {
    className?: string;
    /** Extra classes for the draggable thumb. */
    thumbClassName?: string;
}
export interface ColorPickerWheelProps {
    className?: string;
    /** Diameter in points. Defaults to the picker's size. */
    size?: number;
    /** Extra classes for the draggable thumb. */
    thumbClassName?: string;
}
export declare const ColorPicker: import("react").ForwardRefExoticComponent<ColorPickerProps & import("react").RefAttributes<ViewRef>> & {
    Trigger: typeof ColorPickerTrigger;
    Content: typeof ColorPickerContent;
    Field: import("react").ForwardRefExoticComponent<ColorPickerFieldProps & import("react").RefAttributes<ViewRef>>;
    Area: import("react").ForwardRefExoticComponent<ColorPickerAreaProps & import("react").RefAttributes<ViewRef>>;
    Wheel: import("react").ForwardRefExoticComponent<ColorPickerWheelProps & import("react").RefAttributes<ViewRef>>;
    Channel: import("react").ForwardRefExoticComponent<ColorPickerChannelProps & import("react").RefAttributes<ViewRef>>;
    Hue: import("react").ForwardRefExoticComponent<ColorPickerHueProps & import("react").RefAttributes<ViewRef>>;
    Brightness: import("react").ForwardRefExoticComponent<ColorPickerBrightnessProps & import("react").RefAttributes<ViewRef>>;
    Alpha: import("react").ForwardRefExoticComponent<ColorPickerAlphaProps & import("react").RefAttributes<ViewRef>>;
    Preview: import("react").ForwardRefExoticComponent<ColorPickerPreviewProps & import("react").RefAttributes<ViewRef>>;
    Swatches: import("react").ForwardRefExoticComponent<ColorPickerSwatchesProps & import("react").RefAttributes<ViewRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map