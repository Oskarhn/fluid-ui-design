export type ContextMenuInvocation = 'menu' | 'press';
export interface ContextMenuKey {
    key: string;
    shiftKey?: boolean;
    altKey?: boolean;
    ctrlKey?: boolean;
    metaKey?: boolean;
    repeat?: boolean;
}
/** The cross-platform subset ContextMenu consumes from a key-down event. */
export interface ContextMenuKeyDownEvent {
    nativeEvent: ContextMenuKey;
    preventDefault: () => void;
    isDefaultPrevented: () => boolean;
}
/** Resolve a screen-reader/switch action to the same paths touch users have. */
export declare function contextMenuAccessibilityInvocation(actionName: string, hasPrimaryAction: boolean, disabled: boolean): ContextMenuInvocation | undefined;
/** Resolve web/hardware keys without stealing modified shortcuts or repeats. */
export declare function contextMenuKeyInvocation(event: ContextMenuKey, hasPrimaryAction: boolean, disabled: boolean): ContextMenuInvocation | undefined;
//# sourceMappingURL=context-menu-invocation.d.ts.map