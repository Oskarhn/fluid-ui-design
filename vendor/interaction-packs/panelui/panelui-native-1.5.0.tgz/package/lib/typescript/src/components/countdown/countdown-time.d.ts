/**
 * Time arithmetic for `Countdown`, kept apart from the views so it can be
 * tested without a clock.
 *
 * Whole seconds are rounded **up**. A countdown that floors shows 0:00 for the
 * last second before it ends, so it reads as finished while it is not — and
 * an "ends at 12:00" sale still taking orders under a zero is the bug people
 * report. Rounding up shows 0:01 until the very end and reaches 0:00 at the
 * moment the target passes.
 */
export type CountdownUnit = 'days' | 'hours' | 'minutes' | 'seconds';
export declare const COUNTDOWN_UNITS: readonly CountdownUnit[];
export interface CountdownPart {
    unit: CountdownUnit;
    value: number;
}
/** Whole seconds left until `target`, rounded up, never below zero. */
export declare function secondsLeft(target: number, now: number): number;
/**
 * Milliseconds until the displayed second next changes.
 *
 * The tick is scheduled for that moment rather than every 1000ms from mount,
 * so the display changes when the second actually turns over instead of
 * drifting by however late the first timer fired.
 */
export declare function msUntilNextTick(target: number, now: number): number;
/**
 * Splits a number of seconds across the given units, largest first.
 *
 * The largest unit absorbs everything above it, so with `['hours',
 * 'minutes', 'seconds']` two days reads as 48 hours rather than losing the
 * days. Units are always returned in largest-to-smallest order whatever order
 * they were passed in.
 */
export declare function splitSeconds(total: number, units?: readonly CountdownUnit[]): CountdownPart[];
/**
 * Drops leading units that are zero, keeping at least `keep` of them.
 *
 * A launch three hours away has no use for a "00 days" box, but a countdown
 * should not shrink to a lone seconds field in its last minute either, so the
 * smallest `keep` units always stay.
 */
export declare function trimLeading(parts: CountdownPart[], keep?: number): CountdownPart[];
/**
 * What a screen reader hears. Coarser than what is on screen.
 *
 * The label changes only when the minute does, until the last minute, when it
 * counts seconds. A label that changed every second would be re-read every
 * second by anything polling it, and a reader does not need the seconds of a
 * launch two days away.
 */
export declare function describeSeconds(total: number): string;
//# sourceMappingURL=countdown-time.d.ts.map