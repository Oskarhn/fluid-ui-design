import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type CountdownUnit } from './countdown-time.js';
import type { ViewRef } from '../../primitives/refs.js';
export type { CountdownUnit } from './countdown-time.js';
declare const countdownVariants: import("tailwind-variants").TVReturnType<{
    /**
     * `segmented` puts each unit in its own box with its name under it — a
     * launch page, a hero, anything the countdown is the point of.
     * `inline` is a line of text, `2d 14:03:22`, for a banner, a button
     * caption or a row.
     */
    variant: {
        segmented: {
            root: string;
            segment: string;
        };
        inline: {
            root: string;
            segment: string;
        };
    };
    size: {
        sm: {
            digit: string;
            label: string;
            separator: string;
            suffix: string;
        };
        md: {
            digit: string;
            label: string;
            separator: string;
            suffix: string;
        };
        lg: {
            digit: string;
            label: string;
            separator: string;
            suffix: string;
        };
    };
}, {
    root: string;
    segment: string;
    digits: string;
    digit: string;
    label: string;
    separator: string;
    suffix: string;
}, undefined, {
    /**
     * `segmented` puts each unit in its own box with its name under it — a
     * launch page, a hero, anything the countdown is the point of.
     * `inline` is a line of text, `2d 14:03:22`, for a banner, a button
     * caption or a row.
     */
    variant: {
        segmented: {
            root: string;
            segment: string;
        };
        inline: {
            root: string;
            segment: string;
        };
    };
    size: {
        sm: {
            digit: string;
            label: string;
            separator: string;
            suffix: string;
        };
        md: {
            digit: string;
            label: string;
            separator: string;
            suffix: string;
        };
        lg: {
            digit: string;
            label: string;
            separator: string;
            suffix: string;
        };
    };
}, {
    root: string;
    segment: string;
    digits: string;
    digit: string;
    label: string;
    separator: string;
    suffix: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    /**
     * `segmented` puts each unit in its own box with its name under it — a
     * launch page, a hero, anything the countdown is the point of.
     * `inline` is a line of text, `2d 14:03:22`, for a banner, a button
     * caption or a row.
     */
    variant: {
        segmented: {
            root: string;
            segment: string;
        };
        inline: {
            root: string;
            segment: string;
        };
    };
    size: {
        sm: {
            digit: string;
            label: string;
            separator: string;
            suffix: string;
        };
        md: {
            digit: string;
            label: string;
            separator: string;
            suffix: string;
        };
        lg: {
            digit: string;
            label: string;
            separator: string;
            suffix: string;
        };
    };
}, {
    root: string;
    segment: string;
    digits: string;
    digit: string;
    label: string;
    separator: string;
    suffix: string;
}>>;
type CountdownVariantProps = VariantProps<typeof countdownVariants>;
export interface CountdownProps extends Omit<ViewProps, 'children'>, CountdownVariantProps {
    className?: string;
    /** The moment to count down to, as a `Date` or epoch milliseconds. */
    to: Date | number;
    /**
     * Which units to show, largest to smallest. The largest one absorbs
     * everything above it — `['hours', 'minutes', 'seconds']` shows two days as
     * 48 hours. Defaults to all four.
     */
    units?: CountdownUnit[];
    /**
     * Drop leading units while they are zero, so a launch three hours away has
     * no "00 days" box. The smallest two always stay.
     */
    trim?: boolean;
    /** Names under each box in `segmented`. Pass any subset to translate them. */
    labels?: Partial<Record<CountdownUnit, string>>;
    /**
     * Turn the digits to the destructive colour once this many seconds or fewer
     * are left — the last five minutes of a sale, the last ten seconds of a bid.
     */
    urgentBelow?: number;
    /** Called once when the time is up, including on mount if it already is. */
    onComplete?: () => void;
    /** Called with the whole seconds left each time the display changes. */
    onTick?: (secondsLeft: number) => void;
}
export declare const Countdown: import("react").ForwardRefExoticComponent<CountdownProps & import("react").RefAttributes<ViewRef>>;
//# sourceMappingURL=index.d.ts.map