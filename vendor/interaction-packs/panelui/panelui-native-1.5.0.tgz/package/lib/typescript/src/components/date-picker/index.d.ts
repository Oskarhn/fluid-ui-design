/**
 * DatePicker — a calendar behind a button.
 *
 * ```tsx
 * const [day, setDay] = useState<Date>();
 *
 * <DatePicker selected={day} onSelect={setDay} placeholder="Pick a date" />
 * ```
 *
 * It is the `Calendar` in a `Popover` with a trigger that reads back what was
 * chosen, and it is a separate component from the calendar for the same reason
 * `Select` is separate from a list: the hard parts are the ones around the
 * grid — what a closed field says, when the panel closes, and what a range
 * shows while only half of it has been picked.
 *
 * ## It closes when the selection is finished, not when it changes
 *
 * A single date is done in one tap, so the panel closes on it. A range needs
 * two, so it stays open until the second — closing on the first would put
 * someone back where they started with half a range on screen. Multiple never
 * closes on its own; only the caller knows when a set is complete.
 *
 * ## An anchored panel, not a sheet
 *
 * A month grid is a fixed size that fits beside its trigger on any phone, and
 * a sheet is the right container for a list of unknown length rather than for
 * a shape that is always the same. Pass `presentation="bottom-sheet"` where the
 * screen is busy — a form with the keyboard up is the usual case.
 */
import { type ReactElement, type ReactNode } from 'react';
import { type CalendarSystem } from '../../utils/date.js';
import { type CalendarCaptionLayout, type CalendarDisabled, type CalendarMode, type CalendarSelection } from '../calendar/index.js';
import { type PopoverPresentation } from '../popover/index.js';
export type DatePickerMode = CalendarMode;
export interface DatePickerProps<Mode extends DatePickerMode = 'single'> {
    /** One day, several, or a span with two ends. */
    mode?: Mode;
    /** Controlled selection. Its shape follows `mode`. */
    selected?: CalendarSelection[Mode];
    /** Starting selection when uncontrolled. */
    defaultSelected?: CalendarSelection[Mode];
    onSelect?: (selected: CalendarSelection[Mode]) => void;
    /** Controlled open state of the panel. */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** What the trigger reads when nothing has been chosen. */
    placeholder?: string;
    /** Override how the chosen value is written on the trigger. */
    format?: (selected: CalendarSelection[Mode]) => string;
    /** Anchored panel, or a sheet from the bottom of the screen. */
    presentation?: PopoverPresentation;
    /** Stop the trigger opening it. */
    disabled?: boolean;
    /** Days that cannot be picked: a list, a span, or a rule. */
    disabledDates?: CalendarDisabled;
    /** Earliest selectable day. */
    minDate?: Date;
    /** Latest selectable day. */
    maxDate?: Date;
    /** Earliest month the `dropdown` caption offers. Defaults to `minDate`. */
    startMonth?: Date;
    /** Latest month the `dropdown` caption offers. Defaults to `maxDate`. */
    endMonth?: Date;
    /** Months side by side inside the panel. */
    numberOfMonths?: number;
    /** `dropdown` swaps the month caption for month and year pickers. */
    captionLayout?: CalendarCaptionLayout;
    /** `0` is Sunday. */
    weekStartsOn?: number;
    /** Let a tap on a neighbouring month's day select it. Off by default. */
    selectOutsideDays?: boolean;
    /** BCP 47 tag for the month and weekday names, and for the trigger's text. */
    locale?: string;
    /**
     * Which calendar the months and day numbers are counted in. Forwarded to the
     * grid, and used for the trigger's own text so the two always agree.
     */
    calendar?: CalendarSystem;
    className?: string;
    /**
     * A trigger of your own. Given one, it is cloned with an `onPress` that opens
     * the panel — so a field row or an icon button can stand in for the default
     * button without this component knowing what either looks like.
     */
    children?: ReactElement<{
        onPress?: () => void;
    }> | ReactNode;
}
declare function DatePickerRoot<Mode extends DatePickerMode = 'single'>({ mode, selected, defaultSelected, onSelect, open: openProp, onOpenChange, placeholder, format, presentation, disabled, disabledDates, minDate, maxDate, startMonth, endMonth, numberOfMonths, captionLayout, weekStartsOn, selectOutsideDays, locale, calendar, className, children, }: DatePickerProps<Mode>): import("react").JSX.Element;
declare namespace DatePickerRoot {
    var displayName: string;
}
export declare const DatePicker: typeof DatePickerRoot & {
    Trigger: ({ children }: import("../popover/index.js").PopoverTriggerProps) => import("react").JSX.Element;
};
export {};
//# sourceMappingURL=index.d.ts.map