/**
 * DateTimePicker — a day and a time of day, picked in one panel.
 *
 * ```tsx
 * const [when, setWhen] = useState<Date>();
 *
 * <DateTimePicker value={when} onValueChange={setWhen} />
 * ```
 *
 * ## Why it is one component and not two side by side
 *
 * A date field beside a time field is two decisions the reader has to make
 * separately and then hold together — and the two halves can disagree, which is
 * how a booking ends up on the right day at a time that has already passed. Here
 * the calendar and the scale are the same panel over one `Date`, so what is on
 * screen is the answer rather than two thirds of it.
 *
 * The layout follows from that: the calendar is the coarse choice and takes the
 * room, the time sits under it behind a hairline, and one Done finishes both.
 * The panel is a fixed width, which is what lets the two halves line up — a
 * month grid and a time scale that measured themselves independently would be
 * two boxes of slightly different widths stacked on each other.
 *
 * ## It does not close on the date
 *
 * `DatePicker` closes as soon as a single day is tapped, because at that point
 * there is nothing left to say. Here there is: the day is half the value, and
 * closing on it would hide the other half at the moment it became relevant. So
 * the panel stays until Done, in every presentation including the popover — the
 * one place `DatePicker` has no Done button at all.
 *
 * ## The time face
 *
 * `ruler` by default rather than the wheel. Under a month grid the panel is
 * already tall, and the wheel is five rows of it; the ruler is one readout over
 * a scale, reads at arm's length, and is the one face that fits under a calendar
 * without the whole thing needing to scroll. The other two are a prop away.
 *
 * ## Picking the time before the day
 *
 * Allowed, and it means today. There has to be *some* day for a time to be a
 * `Date` at all, and the day the reader is looking at is the only defensible
 * guess — the alternative is refusing to emit a value until both halves have
 * been touched, which is a form that silently does nothing when you use it in
 * the order it did not expect.
 */
import { type ReactElement, type ReactNode } from 'react';
import { type CalendarSystem } from '../../utils/date.js';
import { type HourCycle, type TimeValue } from '../../utils/time.js';
import { type CalendarCaptionLayout, type CalendarDisabled } from '../calendar/index.js';
import { type TimePickerLayout } from '../time-picker/index.js';
/** Where the panel is shown. `inline` renders it bare, for a Frame or a form. */
export type DateTimePickerPresentation = 'popover' | 'bottom-sheet' | 'dialog' | 'inline';
export interface DateTimePickerProps {
    /** Controlled value. One `Date` carrying both halves. */
    value?: Date;
    /** Starting value when uncontrolled. */
    defaultValue?: Date;
    /**
     * Fires on every change to either half, not on Done. Done closes the panel;
     * it does not decide anything the caller has not already been told.
     */
    onValueChange?: (value: Date) => void;
    /** Which face the time is picked on. `ruler` is the one that fits here. */
    layout?: TimePickerLayout;
    /** Anchored panel, a sheet, a dialog, or the panel with nothing around it. */
    presentation?: DateTimePickerPresentation;
    /** Controlled open state of the panel. */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** `12` shows a meridiem, `24` does not. The value is 24-hour either way. */
    hourCycle?: HourCycle;
    /** Minutes between one selectable time and the next. */
    minuteStep?: number;
    /** Earliest selectable time of day, inclusive. */
    minTime?: TimeValue;
    /** Latest selectable time of day, inclusive. */
    maxTime?: TimeValue;
    /** What the trigger reads when nothing has been chosen. */
    placeholder?: string;
    /** Override how the chosen value is written on the trigger. */
    format?: (value: Date) => string;
    /** Stop the trigger opening it, and the panel from being used. */
    disabled?: boolean;
    /** Days that cannot be picked: a list, a span, or a rule. */
    disabledDates?: CalendarDisabled;
    /** Earliest selectable day. */
    minDate?: Date;
    /** Latest selectable day. */
    maxDate?: Date;
    /** `dropdown` swaps the month caption for month and year pickers. */
    captionLayout?: CalendarCaptionLayout;
    /** `0` is Sunday. */
    weekStartsOn?: number;
    /** BCP 47 tag for the month names, the time and the trigger's own text. */
    locale?: string;
    /** Which calendar the months and day numbers are counted in. */
    calendar?: CalendarSystem;
    /** Label on the button that closes the panel. */
    doneLabel?: string;
    /**
     * What the time half of the panel is called, above its face. The date half
     * names itself with the month it is showing; the time half has nothing that
     * would say what it is otherwise.
     */
    timeLabel?: string;
    className?: string;
    /**
     * A trigger of your own. Given one, it is cloned with an `onPress` that opens
     * the panel — so a field row or an icon button can stand in for the default
     * button without this component knowing what either looks like.
     *
     * Ignored by `presentation="inline"`, which has no trigger.
     */
    children?: ReactElement<{
        onPress?: () => void;
    }> | ReactNode;
}
declare function DateTimePickerRoot({ value: valueProp, defaultValue, onValueChange, layout, presentation, open: openProp, onOpenChange, hourCycle, minuteStep, minTime, maxTime, placeholder, format, disabled, disabledDates, minDate, maxDate, captionLayout, weekStartsOn, locale, calendar, doneLabel, timeLabel, className, children, }: DateTimePickerProps): import("react").JSX.Element;
declare namespace DateTimePickerRoot {
    var displayName: string;
}
export declare const DateTimePicker: typeof DateTimePickerRoot & {
    Trigger: ({ children }: import("../popover/index.js").PopoverTriggerProps) => import("react").JSX.Element;
};
export {};
//# sourceMappingURL=index.d.ts.map