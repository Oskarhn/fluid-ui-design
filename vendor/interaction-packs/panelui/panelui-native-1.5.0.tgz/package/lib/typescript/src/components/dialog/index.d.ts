import { type ReactElement, type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef } from '../../primitives/refs.js';
export interface DialogProps {
    children: ReactNode;
    /** Controlled open state. */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** Initial state when uncontrolled. */
    defaultOpen?: boolean;
}
declare function DialogRoot({ children, open, onOpenChange, defaultOpen }: DialogProps): import("react").JSX.Element;
interface DialogTriggerProps {
    children: ReactElement<{
        onPress?: (...args: unknown[]) => void;
    }>;
}
/** Wraps its child and opens the dialog on press. */
declare function DialogTrigger({ children }: DialogTriggerProps): ReactElement<{
    onPress?: (...args: unknown[]) => void;
}, string | import("react").JSXElementConstructor<any>>;
export interface DialogContentProps extends ViewProps {
    className?: string;
    /** Tap on the backdrop closes the dialog. Default true. */
    dismissible?: boolean;
    /**
     * Frost the screen behind the dialog instead of dimming it. Uses `expo-blur`
     * when installed and falls back to the dim when it is not, so it is safe to
     * pass either way.
     *
     * Someone who has Reduce Transparency switched on gets an opaque
     * backdrop instead, which is the whole point of the setting.
     */
    blur?: boolean;
    children?: ReactNode;
}
declare function DialogContent({ className, dismissible, blur, children, ...props }: DialogContentProps): import("react").JSX.Element | null;
declare const dialogFooterVariants: import("tailwind-variants").TVReturnType<{
    /**
     * Whether the footer draws a surface of its own.
     *
     * `plain` is part of the dialog: same background, sitting under the content
     * with a gap above it. `panel` is a band set into it — a rule across the
     * top, a step darker, and the dialog's own bottom corners — which separates
     * what the dialog says from what you can do about it. Worth it on a dialog
     * with a form in it, where the buttons are otherwise one more row of it.
     */
    variant: {
        plain: "mt-4";
        panel: "mt-5 rounded-b-2xl border-t border-border bg-inset";
    };
}, undefined, "flex-row items-center justify-end gap-2", {
    /**
     * Whether the footer draws a surface of its own.
     *
     * `plain` is part of the dialog: same background, sitting under the content
     * with a gap above it. `panel` is a band set into it — a rule across the
     * top, a step darker, and the dialog's own bottom corners — which separates
     * what the dialog says from what you can do about it. Worth it on a dialog
     * with a form in it, where the buttons are otherwise one more row of it.
     */
    variant: {
        plain: "mt-4";
        panel: "mt-5 rounded-b-2xl border-t border-border bg-inset";
    };
}, undefined, import("tailwind-variants").TVReturnTypeLike<{
    /**
     * Whether the footer draws a surface of its own.
     *
     * `plain` is part of the dialog: same background, sitting under the content
     * with a gap above it. `panel` is a band set into it — a rule across the
     * top, a step darker, and the dialog's own bottom corners — which separates
     * what the dialog says from what you can do about it. Worth it on a dialog
     * with a form in it, where the buttons are otherwise one more row of it.
     */
    variant: {
        plain: "mt-4";
        panel: "mt-5 rounded-b-2xl border-t border-border bg-inset";
    };
}, undefined>>;
export interface DialogFooterProps extends ViewProps, VariantProps<typeof dialogFooterVariants> {
    className?: string;
}
declare function DialogFooter({ className, variant, style, ...props }: DialogFooterProps): import("react").JSX.Element;
interface DialogCloseProps {
    children: ReactElement<{
        onPress?: (...args: unknown[]) => void;
    }>;
}
/** Wraps its child and closes the dialog on press. */
declare function DialogClose({ children }: DialogCloseProps): ReactElement<{
    onPress?: (...args: unknown[]) => void;
}, string | import("react").JSXElementConstructor<any>>;
export declare const Dialog: typeof DialogRoot & {
    Trigger: typeof DialogTrigger;
    Content: typeof DialogContent;
    Title: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Description: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Footer: typeof DialogFooter;
    Close: typeof DialogClose;
};
export {};
//# sourceMappingURL=index.d.ts.map