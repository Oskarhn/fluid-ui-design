/**
 * EmptyState — the placeholder shown when a list or view has no content.
 *
 * Centred Header / Media / Title / Description / Content, with an `icon` media
 * variant that stacks two rotated ghost cards behind the icon. On the web that
 * is a pair of CSS pseudo-elements; React Native has none, so it is two
 * absolutely positioned siblings with static rotate transforms.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
type EmptyStateSize = 'sm' | 'default' | 'lg';
declare const emptyStateVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        default: {
            root: string;
        };
        card: {
            root: string;
        };
    };
    size: {
        sm: {
            root: string;
            title: string;
            description: string;
        };
        default: {
            root: string;
            title: string;
            description: string;
        };
        lg: {
            root: string;
            title: string;
            description: string;
        };
    };
}, {
    root: string;
    header: string;
    title: string;
    description: string;
    content: string;
}, undefined, {
    variant: {
        default: {
            root: string;
        };
        card: {
            root: string;
        };
    };
    size: {
        sm: {
            root: string;
            title: string;
            description: string;
        };
        default: {
            root: string;
            title: string;
            description: string;
        };
        lg: {
            root: string;
            title: string;
            description: string;
        };
    };
}, {
    root: string;
    header: string;
    title: string;
    description: string;
    content: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        default: {
            root: string;
        };
        card: {
            root: string;
        };
    };
    size: {
        sm: {
            root: string;
            title: string;
            description: string;
        };
        default: {
            root: string;
            title: string;
            description: string;
        };
        lg: {
            root: string;
            title: string;
            description: string;
        };
    };
}, {
    root: string;
    header: string;
    title: string;
    description: string;
    content: string;
}>>;
declare const mediaVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        default: {
            card: string;
            ghost: string;
        };
        icon: {
            card: string;
        };
    };
    size: {
        sm: {
            card: string;
            ghost: string;
        };
        default: {
            card: string;
            ghost: string;
        };
        lg: {
            card: string;
            ghost: string;
        };
    };
}, {
    wrapper: string;
    card: string;
    ghost: string;
}, undefined, {
    variant: {
        default: {
            card: string;
            ghost: string;
        };
        icon: {
            card: string;
        };
    };
    size: {
        sm: {
            card: string;
            ghost: string;
        };
        default: {
            card: string;
            ghost: string;
        };
        lg: {
            card: string;
            ghost: string;
        };
    };
}, {
    wrapper: string;
    card: string;
    ghost: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        default: {
            card: string;
            ghost: string;
        };
        icon: {
            card: string;
        };
    };
    size: {
        sm: {
            card: string;
            ghost: string;
        };
        default: {
            card: string;
            ghost: string;
        };
        lg: {
            card: string;
            ghost: string;
        };
    };
}, {
    wrapper: string;
    card: string;
    ghost: string;
}>>;
export interface EmptyStateProps extends ViewProps, VariantProps<typeof emptyStateVariants> {
    className?: string;
    /**
     * `default` fills its parent — a whole screen, or a flex slot. `card` is a
     * self-contained bordered block for an empty state that sits inside content
     * rather than owning the screen.
     */
    variant?: 'default' | 'card';
    /** Scales the padding, media, title and description together. */
    size?: EmptyStateSize;
    children?: ReactNode;
}
export interface EmptyStateMediaProps extends ViewProps, VariantProps<typeof mediaVariants> {
    className?: string;
    children?: ReactNode;
}
export declare const EmptyState: import("react").ForwardRefExoticComponent<EmptyStateProps & import("react").RefAttributes<ViewRef>> & {
    Header: import("react").ForwardRefExoticComponent<EmptyStateProps & import("react").RefAttributes<ViewRef>>;
    Media: import("react").ForwardRefExoticComponent<EmptyStateMediaProps & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Description: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Content: import("react").ForwardRefExoticComponent<ViewProps & {
        className?: string;
    } & import("react").RefAttributes<ViewRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map