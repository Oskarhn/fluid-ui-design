/**
 * Feedback — a dialog whose body is something to write in, and whose
 * actions sit in a band around it.
 *
 * ```tsx
 * <Feedback open={open} onOpenChange={setOpen}>
 *   <Feedback.Content>
 *     <Feedback.Panel>
 *       <Feedback.Title>What should we fix first?</Feedback.Title>
 *       <Feedback.Close />
 *       <Feedback.Field value={text} onChangeText={setText} />
 *     </Feedback.Panel>
 *     <Feedback.Footer>
 *       <Feedback.Cancel />
 *       <Feedback.Submit onPress={send} />
 *     </Feedback.Footer>
 *   </Feedback.Content>
 * </Feedback>
 * ```
 *
 * ## Why the panel is a panel and not the dialog
 *
 * A dialog that asks for a sentence has two jobs on screen at once: hold what
 * is being written, and offer the two things to do with it. `Dialog` puts both
 * on one surface, which is right when the body is a line of prose — nothing
 * about it says "this is where you type".
 *
 * Here the writing surface is a well set into the dialog, and the buttons sit
 * in the band around it. The recess is the whole affordance: it says the field
 * is the page and everything else is the frame around it, before a word has
 * been read. It is also why the field has no border of its own — an outline
 * inside a well is two edges saying the same thing.
 *
 * ## The actions are equal, and one of them is not
 *
 * Cancel and Submit take the same width, because they are the same size of
 * decision — this is a sentence somebody wrote, not a deletion. What separates
 * them is weight: Submit is filled in the foreground colour and Cancel is a
 * tint of it, so the difference is legible at a glance without either being
 * hidden.
 *
 * ## Nothing is submitted empty
 *
 * `Submit` disables itself while the field is empty. A dialog that accepts an
 * empty answer produces empty feedback, and the person who sent it believes
 * they said something.
 *
 * Disabled, it drops the fill instead of dimming it. A tinted accent pill
 * still reads as the thing to press, whatever its opacity.
 */
import { type ReactElement, type ReactNode } from 'react';
import { type TextInputProps, type ViewProps } from 'react-native';
import { type TextProps } from '../../primitives/text.js';
import type { TextInputRef, TextRef, ViewRef } from '../../primitives/refs.js';
export interface FeedbackProps {
    children: ReactNode;
    /** Controlled open state. */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** Initial state when uncontrolled. */
    defaultOpen?: boolean;
    /** The message, when the caller holds it. Leave unset to let the field keep it. */
    value?: string;
    /** Starting message for an uncontrolled field. Ignored once `value` is passed. */
    defaultValue?: string;
    onValueChange?: (value: string) => void;
}
declare function FeedbackRoot({ children, open, onOpenChange, defaultOpen, value, defaultValue, onValueChange, }: FeedbackProps): import("react").JSX.Element;
declare namespace FeedbackRoot {
    var displayName: string;
}
interface FeedbackTriggerProps {
    children: ReactElement<{
        onPress?: (...args: unknown[]) => void;
    }>;
}
/** Wraps its child and opens the dialog on press. */
declare function FeedbackTrigger({ children }: FeedbackTriggerProps): import("react").JSX.Element;
declare namespace FeedbackTrigger {
    var displayName: string;
}
export interface FeedbackContentProps extends ViewProps {
    className?: string;
    /** Whether tapping outside or pressing back closes it. */
    dismissible?: boolean;
    /** Frost the screen behind instead of dimming it. Needs `expo-blur`. */
    blur?: boolean;
    children?: ReactNode;
}
/** The shell: the recessed band, and everything laid in it. */
declare function FeedbackContent({ className, dismissible, blur, children, ...props }: FeedbackContentProps): import("react").JSX.Element | null;
declare namespace FeedbackContent {
    var displayName: string;
}
export interface FeedbackPanelProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface FeedbackCloseProps extends ViewProps {
    className?: string;
    /** How the ✕ announces itself. */
    label?: string;
    /** Runs instead of closing. Call `onOpenChange` yourself if you pass this. */
    onPress?: () => void;
}
/** The ✕ in the panel's corner. */
declare function FeedbackClose({ className, label, onPress, ...props }: FeedbackCloseProps): import("react").JSX.Element;
declare namespace FeedbackClose {
    var displayName: string;
}
export interface FeedbackFieldProps extends Omit<TextInputProps, 'value' | 'onChangeText'> {
    className?: string;
    /** The message. Leave unset to let the dialog hold it. */
    value?: string;
    onChangeText?: (value: string) => void;
    /** Room to write in before the field starts growing. */
    minHeight?: number;
}
export interface FeedbackFooterProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface FeedbackActionProps extends ViewProps {
    className?: string;
    labelClassName?: string;
    disabled?: boolean;
    onPress?: () => void;
    children?: ReactNode;
}
/** Discards and closes. Give it `onPress` to do something else first. */
declare function FeedbackCancel({ children, onPress, ...props }: FeedbackActionProps): import("react").JSX.Element;
declare namespace FeedbackCancel {
    var displayName: string;
}
export interface FeedbackSubmitProps extends FeedbackActionProps {
    /**
     * Hand the message to the caller. The dialog does not close itself here —
     * sending usually has to finish first, and a dialog that closed on the press
     * would take its own error message with it.
     */
    onSubmit?: (value: string) => void;
}
/** Sends. Inert while the field is empty. */
declare function FeedbackSubmit({ children, disabled, onPress, onSubmit, ...props }: FeedbackSubmitProps): import("react").JSX.Element;
declare namespace FeedbackSubmit {
    var displayName: string;
}
export declare const Feedback: typeof FeedbackRoot & {
    Trigger: typeof FeedbackTrigger;
    Content: typeof FeedbackContent;
    Panel: import("react").ForwardRefExoticComponent<FeedbackPanelProps & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Close: typeof FeedbackClose;
    Field: import("react").ForwardRefExoticComponent<FeedbackFieldProps & import("react").RefAttributes<TextInputRef>>;
    Footer: import("react").ForwardRefExoticComponent<FeedbackFooterProps & import("react").RefAttributes<ViewRef>>;
    Cancel: typeof FeedbackCancel;
    Submit: typeof FeedbackSubmit;
};
export {};
//# sourceMappingURL=index.d.ts.map