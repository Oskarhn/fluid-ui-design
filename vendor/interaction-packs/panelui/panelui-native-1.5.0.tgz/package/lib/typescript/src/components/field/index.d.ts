/**
 * Field — the layout and validation-state kit a form control composes into.
 *
 * PanelUI's own controls (`Input`, `Checkbox`, `Switch`, `RadioGroup`) already
 * carry their own label, description and error slot, so the common case needs
 * no wrapper at all — pass those props straight through. `Field` exists for
 * what doesn't fit that shape: a horizontal row pairing a control with a
 * label off to the side (a `Switch` in a settings list), several controls
 * grouped under one legend, or a rule breaking a long form into sections.
 *
 * `invalid` / `disabled` / `required` set on the root flow to `Field.Label`
 * and `Field.Description` through context, so a multi-field row states its
 * validity once instead of repeating the prop at every leaf.
 *
 * ```tsx
 * <Field orientation="horizontal">
 *   <Field.Content>
 *     <Field.Title>Marketing emails</Field.Title>
 *     <Field.Description>Product updates, at most weekly.</Field.Description>
 *   </Field.Content>
 *   <Switch
 *     value={subscribed}
 *     onValueChange={setSubscribed}
 *     accessibilityLabel="Marketing emails"
 *     accessibilityHint="Product updates, at most weekly."
 *   />
 * </Field>
 * ```
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type TextProps } from '../../primitives/text.js';
import { type LabelProps } from '../label/index.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
/** Android can announce the label, help and error text rendered beside a control. */
export declare function useFieldLabelledBy(): string[] | undefined;
export interface FieldProps extends ViewProps {
    className?: string;
    /** `horizontal` puts a label beside the control instead of above it. */
    orientation?: 'vertical' | 'horizontal';
    /** Marks every `Field.Label`/`Field.Description` below as invalid. */
    invalid?: boolean;
    disabled?: boolean;
    /** Marks every `Field.Label` below as required, same as `Label`'s own prop. */
    required?: boolean;
    children?: ReactNode;
}
export interface FieldContentProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface FieldLabelProps extends LabelProps {
}
export interface FieldDescriptionProps extends TextProps {
    className?: string;
}
export interface FieldErrorProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /**
     * Error messages to render, deduplicated by message. A single entry renders
     * as plain text; more than one renders as a bulleted list, since RN has no
     * `<ul>`. Prefer this over `children` when the messages come from a form's
     * validation state, which is naturally an array.
     */
    errors?: Array<string | {
        message?: string;
    } | null | undefined>;
    children?: ReactNode;
}
export interface FieldSetProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface FieldLegendProps extends TextProps {
    className?: string;
    /** `legend` reads as a section heading; `label` sits closer to a field label. */
    variant?: 'legend' | 'label';
}
export interface FieldGroupProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface FieldSeparatorProps extends ViewProps {
    className?: string;
    /** Centered text, e.g. "Or" — omit for a plain rule. */
    children?: ReactNode;
}
export interface FieldTitleProps extends TextProps {
    className?: string;
}
export declare const Field: import("react").ForwardRefExoticComponent<FieldProps & import("react").RefAttributes<ViewRef>> & {
    Content: import("react").ForwardRefExoticComponent<FieldContentProps & import("react").RefAttributes<ViewRef>>;
    Label: import("react").ForwardRefExoticComponent<FieldLabelProps & import("react").RefAttributes<ViewRef>>;
    Description: import("react").ForwardRefExoticComponent<FieldDescriptionProps & import("react").RefAttributes<TextRef>>;
    Error: import("react").ForwardRefExoticComponent<FieldErrorProps & import("react").RefAttributes<ViewRef>>;
    Set: import("react").ForwardRefExoticComponent<FieldSetProps & import("react").RefAttributes<ViewRef>>;
    Legend: import("react").ForwardRefExoticComponent<FieldLegendProps & import("react").RefAttributes<TextRef>>;
    Group: import("react").ForwardRefExoticComponent<FieldGroupProps & import("react").RefAttributes<ViewRef>>;
    Separator: import("react").ForwardRefExoticComponent<FieldSeparatorProps & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<FieldTitleProps & import("react").RefAttributes<TextRef>>;
};
//# sourceMappingURL=index.d.ts.map