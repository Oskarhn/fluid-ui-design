/**
 * The parts of FileUpload that are arithmetic rather than drawing: what a file
 * is, whether it is allowed, how its size reads, and which queued upload runs
 * next. Kept apart from the component so they can be tested without a renderer.
 */
/** Where a file comes from. */
export type FileUploadSource = 'camera' | 'library' | 'files';
/**
 * Where a file is in its life. `idle` has been picked and nothing is sending it;
 * `queued` is waiting for a free upload slot; `canceled` was stopped by the user
 * and can be retried.
 */
export type FileUploadStatus = 'idle' | 'queued' | 'uploading' | 'processing' | 'done' | 'error' | 'canceled';
/** What a file is, for choosing a thumbnail or an icon. */
export type FileUploadKind = 'image' | 'video' | 'document';
/** One picked file and the state of its upload. */
export interface FileUploadFile {
    /** Stable key for the file while it is in the list. */
    id: string;
    /** Local URI the picker returned, or the resized copy of it. */
    uri: string;
    /** File name with its extension. */
    name: string;
    /** Size in bytes, when the picker reports it. */
    size?: number;
    /** MIME type, when the picker reports it. */
    mimeType?: string;
    /** Pixel width, for images and videos. */
    width?: number;
    /** Pixel height, for images and videos. */
    height?: number;
    kind: FileUploadKind;
    status: FileUploadStatus;
    /** Upload progress 0–1, while uploading. */
    progress?: number;
    /** Why the last upload failed. */
    error?: string;
    /** Whatever the upload handler resolved with — a remote URL, a record id. */
    response?: unknown;
}
/** A file that was picked and turned away, and why. */
export interface FileUploadRejection {
    file: Pick<FileUploadFile, 'name' | 'size' | 'mimeType' | 'uri'>;
    reason: 'type' | 'size' | 'count' | 'custom';
    /** A sentence that can be shown as it is. */
    message: string;
}
/** The rules a picked file has to pass. */
export interface FileUploadRules {
    accept?: readonly string[];
    maxSize?: number;
    minSize?: number;
    maxFiles?: number;
    validate?: (file: FileUploadFile) => string | null | undefined;
}
/** Statuses that hold an upload slot. */
export declare function isActive(status: FileUploadStatus): boolean;
/** The extension of a file name, lower-cased and without the dot. */
export declare function extensionOf(name: string): string;
/** The MIME type a file reports, or the one its extension implies. */
export declare function mimeOf(file: {
    name: string;
    mimeType?: string;
}): string | undefined;
/** Image, video or anything else. */
export declare function kindOf(file: {
    name: string;
    mimeType?: string;
}): FileUploadKind;
/**
 * Whether a file matches one of the `accept` patterns: an exact MIME type
 * (`application/pdf`), a family (`image/*`) or an extension (`.pdf`). No
 * patterns accepts everything.
 */
export declare function matchesAccept(file: {
    name: string;
    mimeType?: string;
}, accept: readonly string[] | undefined): boolean;
/**
 * The `type` list for the system document picker. Extensions are turned into
 * MIME types, since that is all the picker understands; an extension it has no
 * type for widens the list to everything, and the validator catches the rest.
 */
export declare function pickerTypes(accept: readonly string[] | undefined): string[];
/**
 * Which of images and videos the photo library should offer, from `accept`.
 * Empty when `accept` allows neither, which means the library has nothing to
 * give and the source is left out of the chooser.
 */
export declare function libraryMediaTypes(accept: readonly string[] | undefined): Array<'images' | 'videos'>;
/**
 * A byte count as people read it: `820 KB`, `2.4 MB`, `10 MB`. One decimal
 * below ten units, none above, never four digits, and binary multiples, so
 * `10 * 1024 * 1024` reads as the round `10 MB` it was written as.
 */
export declare function formatFileSize(bytes: number): string;
/** "PDF, JPG or PNG", from the accept list. Empty when anything goes. */
export declare function describeAccept(accept: readonly string[] | undefined): string;
/** "PDF or images · up to 10 MB" — what a dropzone says under its title. */
export declare function describeRules({ accept, maxSize, maxFiles }: FileUploadRules): string;
/**
 * Split picked files into those that pass the rules and those that do not.
 *
 * Checks run in the order a person would explain them — type, then size, then
 * the app's own rule — and the count comes last, so a file that would have
 * been turned away anyway does not use up one of the remaining slots.
 */
export declare function partitionFiles(candidates: readonly FileUploadFile[], current: number, rules: FileUploadRules): {
    accepted: FileUploadFile[];
    rejected: FileUploadRejection[];
};
/**
 * The queued files that may start now, in list order, given how many slots
 * `concurrency` allows and how many are already busy.
 */
export declare function nextToStart(files: readonly FileUploadFile[], concurrency: number): string[];
/** Scale a width and height down to fit inside a box, never up. */
export declare function fitWithin(size: {
    width: number;
    height: number;
}, box: {
    maxWidth?: number;
    maxHeight?: number;
}): {
    width: number;
    height: number;
} | null;
/**
 * Shorten a file name from the middle, keeping its start and its extension:
 * `service-hist…2025.pdf`. A name cut at the end loses the part that says what
 * kind of file it is.
 */
export declare function truncateMiddle(name: string, max: number): string;
/** A key unique within the app's lifetime. */
export declare function createFileId(): string;
//# sourceMappingURL=file-upload-core.d.ts.map