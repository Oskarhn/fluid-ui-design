/**
 * FileUpload — pick files and photos, check them, and run their uploads.
 *
 * ```tsx
 * <FileUpload
 *   value={files}
 *   onValueChange={setFiles}
 *   sources={['camera', 'library', 'files']}
 *   accept={['image/*', 'application/pdf']}
 *   multiple
 *   maxFiles={5}
 *   maxSize={10 * 1024 * 1024}
 *   upload={(file, { signal, onProgress }) => send(file, { signal, onProgress })}
 * >
 *   <FileUpload.Dropzone />
 *   <FileUpload.List />
 * </FileUpload>
 * ```
 *
 * ## One component for the whole trip
 *
 * Choosing a document, choosing or taking a photo, and sending either of them
 * somewhere are one flow from the user's side: they add things, watch them go,
 * and fix the ones that failed. So the root owns all of it — the list of files,
 * the rules they have to pass, and the upload queue — and the parts are only
 * different ways of drawing that list. `Dropzone` and `Trigger` add to it,
 * `List` draws it as rows, `Grid` draws it as photo tiles, and `useFileUpload()`
 * hands the same state to anything drawn by hand.
 *
 * ## The upload belongs to the app
 *
 * The component never makes a request. `upload` is the app's function: it
 * receives one file, an `AbortSignal` and an `onProgress` callback, and
 * resolves when the server has the file. That keeps the storage provider, the
 * auth headers and the retry policy where they already live, and leaves the
 * component with the part every app repeats — running at most `concurrency`
 * at once, showing progress, and wiring cancel, retry and remove to the right
 * file. The status of every file lives in `value`, so a form can read whether
 * everything has finished without asking the component.
 *
 * ## Native modules are optional
 *
 * Each source reaches its Expo module only when it is used: `files` through
 * `expo-document-picker`, `camera` and `library` through `expo-image-picker`,
 * and resizing through `expo-image-manipulator`. An app that only takes
 * documents never installs the camera module. A source whose module is
 * missing reports an error with the install command rather than crashing.
 */
import { type ReactElement, type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type AnimatedPressableProps } from '../../primitives/animated-pressable.js';
import { describeRules, formatFileSize, type FileUploadFile, type FileUploadKind, type FileUploadRejection, type FileUploadSource, type FileUploadStatus } from './file-upload-core.js';
import type { ViewRef } from '../../primitives/refs.js';
export { describeRules as describeFileUploadRules, formatFileSize, type FileUploadFile, type FileUploadKind, type FileUploadRejection, type FileUploadSource, type FileUploadStatus, };
/** True when the module a source needs is installed. */
export declare function hasFileUploadSource(source: FileUploadSource): boolean;
/** What the upload handler is given besides the file. */
export interface FileUploadHandlerContext {
    /** Aborted when the user cancels or removes the file. Pass it to `fetch`. */
    signal: AbortSignal;
    /** Report how far the upload is, 0–1. Calls are batched to one per frame. */
    onProgress: (progress: number) => void;
    /** Mark the bytes as sent and the server as still working on them. */
    setProcessing: () => void;
}
/**
 * Sends one file. Resolve when the server has it — the value is kept as the
 * file's `response` — and throw to mark it failed; the error's message is shown
 * on the row.
 */
export type FileUploadHandler = (file: FileUploadFile, context: FileUploadHandlerContext) => Promise<unknown>;
/** How photos are prepared before they are added. */
export interface FileUploadImageOptions {
    /** Scale photos wider than this down to it. Needs `expo-image-manipulator`. */
    maxWidth?: number;
    /** Scale photos taller than this down to it. Needs `expo-image-manipulator`. */
    maxHeight?: number;
    /** JPEG quality 0–1, for the picker and for a resized copy. Default 0.9. */
    quality?: number;
    /**
     * Open the system's crop editor after a photo is chosen or taken, at this
     * aspect ratio. Applies to a single photo only — the editor cannot run over
     * a multiple selection. iOS crops to a square whatever the ratio.
     */
    crop?: {
        aspect: [number, number];
    };
}
export interface FileUploadProps {
    /** The files, controlled. */
    value?: FileUploadFile[];
    /** The files to start with, uncontrolled. */
    defaultValue?: FileUploadFile[];
    /** Called with the new list whenever a file is added, changes state or is removed. */
    onValueChange?: (files: FileUploadFile[]) => void;
    /**
     * Where files can come from, in the order the chooser lists them. One source
     * opens its picker straight away; more than one opens a sheet to choose from.
     * Default `['library', 'files']`.
     */
    sources?: FileUploadSource[];
    /**
     * Allowed types: MIME types (`application/pdf`), families (`image/*`) or
     * extensions (`.pdf`). Everything when left out.
     */
    accept?: string[];
    /**
     * Let the list hold more than one file. Without it the list holds one, and
     * picking again replaces it — the shape of a profile photo or a single
     * attachment field.
     */
    multiple?: boolean;
    /**
     * How many files the list can hold, with `multiple`. Pickers are limited to
     * what is left, and the add controls disable once it is reached.
     */
    maxFiles?: number;
    /**
     * Largest allowed file, in bytes. Checked against the size the picker
     * reports, after any resize; a file whose size is unknown passes.
     */
    maxSize?: number;
    /** Smallest allowed file, in bytes. */
    minSize?: number;
    /** An app-specific rule. Return a message to turn the file away. */
    validate?: (file: FileUploadFile) => string | null | undefined;
    /** Called with the files that were picked and turned away, and why. */
    onReject?: (rejections: FileUploadRejection[]) => void;
    /** Called when a picker cannot open — a missing module or a refused permission. */
    onError?: (error: Error) => void;
    /** Resize, compress or crop photos before they are added. */
    image?: FileUploadImageOptions;
    /** Sends one file. Without it files are only picked, and stay `idle`. */
    upload?: FileUploadHandler;
    /** How many uploads run at once. Default 2. */
    concurrency?: number;
    /**
     * Queue files for upload as soon as they are added. Default true. Turn it off
     * to send them later with `useFileUpload().upload()`.
     */
    autoUpload?: boolean;
    /** Called once per file when its upload resolves. */
    onUploadComplete?: (file: FileUploadFile) => void;
    /** Labels for the sources in the chooser. */
    sourceLabels?: Partial<Record<FileUploadSource, string>>;
    /** Nothing can be added, removed or retried. */
    disabled?: boolean;
    /** Draw the dropzone in its error state, for a form that failed validation. */
    invalid?: boolean;
    children?: ReactNode;
}
interface FileUploadContextValue {
    files: FileUploadFile[];
    sources: FileUploadSource[];
    sourceLabels: Record<FileUploadSource, string>;
    accept?: string[];
    maxFiles?: number;
    maxSize?: number;
    multiple: boolean;
    disabled: boolean;
    invalid: boolean;
    canAddMore: boolean;
    hasUpload: boolean;
    rejections: FileUploadRejection[];
    pick: (source: FileUploadSource) => Promise<void>;
    remove: (id: string) => void;
    cancel: (id: string) => void;
    retry: (id: string) => void;
    upload: (id?: string) => void;
    clear: () => void;
}
/**
 * The state and actions of the nearest `FileUpload`, for drawing a part of it
 * by hand — a single avatar slot, a counter, a submit button that waits for
 * every upload.
 */
export declare function useFileUpload(): FileUploadContextValue;
declare function FileUploadRoot({ value: valueProp, defaultValue, onValueChange, sources: sourcesProp, accept, multiple, maxFiles: maxFilesProp, maxSize, minSize, validate, onReject, onError, image, upload: uploadHandler, concurrency, autoUpload, onUploadComplete, sourceLabels, disabled, invalid, children, }: FileUploadProps): import("react").JSX.Element;
declare namespace FileUploadRoot {
    var displayName: string;
}
export interface FileUploadTriggerProps {
    /** One pressable — a Button, an icon button, an avatar. */
    children: ReactElement;
}
/**
 * Turns any pressable into the way files are added. With several sources it
 * opens a sheet listing them; with one it opens that picker directly.
 */
declare function FileUploadTrigger({ children }: FileUploadTriggerProps): import("react").JSX.Element;
declare namespace FileUploadTrigger {
    var displayName: string;
}
export interface FileUploadDropzoneProps extends Omit<AnimatedPressableProps, 'children'> {
    className?: string;
    /** Headline. Default "Choose files", or "Choose a file" for a single file. */
    title?: ReactNode;
    /** The line under it. Written from `accept`, `maxSize` and `maxFiles` when left out. */
    description?: ReactNode;
    /** Replaces the upload glyph in the badge. */
    icon?: ReactNode;
    /** Draw the inside yourself. The press still opens the sources. */
    children?: ReactNode;
}
/** "PDF · 2.4 MB", "1.1 of 2.4 MB · 46%", "Waiting", "Upload failed". */
export declare function describeFileStatus(file: FileUploadFile): string;
export interface FileUploadItemProps {
    file: FileUploadFile;
    className?: string;
    /** Row density. */
    size?: 'default' | 'sm';
    /**
     * Longest name shown before it is shortened from the middle, keeping the
     * extension. Default 36.
     */
    nameLength?: number;
}
/**
 * One file as an Attachment row: a thumbnail or type icon, the name, a status
 * line, and the action that fits the state — cancel while it is moving, retry
 * when it failed or was stopped, remove otherwise.
 */
declare function FileUploadItem({ file, className, size, nameLength }: FileUploadItemProps): import("react").JSX.Element;
declare namespace FileUploadItem {
    var displayName: string;
}
export interface FileUploadListProps extends ViewProps {
    className?: string;
    /** Lay the files out as one scrolling strip of fixed-width rows, for a message composer. */
    horizontal?: boolean;
    /** Row density. */
    size?: 'default' | 'sm';
    /** Draw a row yourself. `FileUpload.Item` is the default. */
    renderItem?: (file: FileUploadFile) => ReactNode;
    /** Shown when the list is empty. Nothing by default. */
    empty?: ReactNode;
}
export interface FileUploadGridProps extends ViewProps {
    className?: string;
    /** Tiles per row. Default 3. Ignored when `horizontal`. */
    columns?: number;
    /** Lay the tiles out as one scrolling strip. */
    horizontal?: boolean;
    /** Tile size in points, for a horizontal strip. Default 88. */
    tileSize?: number;
    /** Space between tiles, in points. Default 8. */
    gap?: number;
    /** Corner radius of a tile, in points. Default 12. */
    radius?: number;
    /** Mark the first photo as the cover. */
    cover?: boolean;
    /** Draw empty slots for the rest of `maxFiles`, so the limit can be seen. */
    placeholders?: boolean;
    /** Label of the add tile. Default "Add photo" or "Add photos". */
    addLabel?: string;
    /** Leave the add tile out — for a grid with its own Trigger elsewhere. */
    hideAdd?: boolean;
}
export declare const FileUpload: typeof FileUploadRoot & {
    Trigger: typeof FileUploadTrigger;
    Dropzone: import("react").ForwardRefExoticComponent<FileUploadDropzoneProps & import("react").RefAttributes<ViewRef>>;
    List: import("react").ForwardRefExoticComponent<FileUploadListProps & import("react").RefAttributes<ViewRef>>;
    Item: typeof FileUploadItem;
    Grid: import("react").ForwardRefExoticComponent<FileUploadGridProps & import("react").RefAttributes<ViewRef>>;
};
//# sourceMappingURL=index.d.ts.map