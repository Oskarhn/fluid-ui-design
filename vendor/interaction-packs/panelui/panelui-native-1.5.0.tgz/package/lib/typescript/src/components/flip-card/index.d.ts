/**
 * FlipCard — two faces of one card, and a turn between them.
 *
 * ```tsx
 * <FlipCard>
 *   <FlipCard.Front className="items-center justify-center rounded-2xl bg-card p-6">
 *     <Text>Tap me</Text>
 *   </FlipCard.Front>
 *   <FlipCard.Back className="items-center justify-center rounded-2xl bg-primary p-6">
 *     <Text className="text-primary-foreground">The other side</Text>
 *   </FlipCard.Back>
 * </FlipCard>
 * ```
 *
 * For content that is genuinely two-sided — a bank card and its security code,
 * a term and its definition, a photograph and what it is of. Not for
 * progressive disclosure: the back replaces the front rather than extending
 * it, so anything the reader needs to compare across the turn belongs in
 * [Collapsible](../collapsible) or a second card instead.
 *
 * ## One box, and both faces in it
 *
 * The back is laid over the front, so there is one box and the two faces fill
 * it. State the height on the root and both faces take it; leave it off and
 * the front's own content decides, with the back given whatever that came to.
 *
 * A back with more in it than the front overflows rather than growing the
 * card, and the fix is a height on the root rather than more padding on the
 * back — a card whose height changed halfway through the turn would be a card
 * that moved everything under it.
 *
 * ## Both faces are hidden the same way twice
 *
 * `backfaceVisibility` is the mechanism, and it is not reliable on every
 * Android surface — so the face that has turned away is also faded out and
 * dropped behind, on the same shared value, at the halfway point. Two
 * mechanisms for one job, because the failure of the first is a card that
 * shows both faces mirrored through each other and nothing in the tree that
 * says why.
 *
 * ## Under reduce motion
 *
 * The faces swap with no turn at all. Not a shorter turn — none. The rotation
 * is the part that moves, and moving is the part the setting is about; which
 * face is showing is the information, and it is kept.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type SharedValue } from 'react-native-reanimated';
import type { ViewRef } from '../../primitives/refs.js';
/** Which axis the card turns about. */
export type FlipCardDirection = 'horizontal' | 'vertical';
/** Which way round it turns. */
export type FlipCardRotation = 'normal' | 'reverse';
/** What flips the card. */
export type FlipCardTrigger = 'press' | 'drag' | 'none';
/**
 * The card's state, for a face that needs to know which way round it is.
 *
 * `progress` runs 0 → 1 across the turn and is a shared value, so a face can
 * drive its own animation off the same turn rather than starting a second one
 * beside it.
 */
export declare function useFlipCard(): {
    flipped: boolean;
    direction: FlipCardDirection;
    rotation: FlipCardRotation;
    progress: SharedValue<number>;
    flip: () => void;
};
export interface FlipCardProps extends Omit<ViewProps, 'children'> {
    /** `FlipCard.Front` and `FlipCard.Back`, in either order. */
    children?: ReactNode;
    /**
     * Which axis the card turns about. `horizontal` turns it left to right about
     * its vertical axis; `vertical` turns it top over bottom.
     */
    direction?: FlipCardDirection;
    /**
     * Which way round the turn goes. `reverse` sends it the other way, for a
     * pair of cards that should not turn identically.
     */
    rotation?: FlipCardRotation;
    /**
     * Which face is showing, when the caller holds it. Leave unset to let the
     * card keep its own, and pair with `trigger="none"` for a card flipped only
     * from outside.
     */
    flipped?: boolean;
    /** Which face an uncontrolled card starts on. */
    defaultFlipped?: boolean;
    /** Fires whenever the card settles on the other face, however it got there. */
    onFlippedChange?: (flipped: boolean) => void;
    /**
     * What turns the card. `press` is a tap anywhere on it; `drag` turns it with
     * the finger and springs to whichever face is nearer on release; `none`
     * leaves it to `flipped`.
     */
    trigger?: FlipCardTrigger;
    /**
     * How deep the turn looks, in points. Smaller is more dramatic — the near
     * edge swings further out — and below about 400 a full card starts to read
     * as a door rather than a card.
     */
    perspective?: number;
    /** Classes for the card's own box. The front's size is the card's size. */
    className?: string;
}
export interface FlipCardFaceProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export declare const FlipCard: import("react").ForwardRefExoticComponent<FlipCardProps & import("react").RefAttributes<ViewRef>> & {
    Front: import("react").ForwardRefExoticComponent<FlipCardFaceProps & import("react").RefAttributes<ViewRef>>;
    Back: import("react").ForwardRefExoticComponent<FlipCardFaceProps & import("react").RefAttributes<ViewRef>>;
};
//# sourceMappingURL=index.d.ts.map