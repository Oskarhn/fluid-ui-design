import type { FlowConnection, FlowNodePosition } from './index.js';
import type { FlowRect } from './flow-paths.js';
export declare const FLOW_MOVE_ACTIONS: readonly [{
    readonly name: "flow-move-up";
    readonly label: "Move up";
    readonly dx: 0;
    readonly dy: -1;
}, {
    readonly name: "flow-move-right";
    readonly label: "Move right";
    readonly dx: 1;
    readonly dy: 0;
}, {
    readonly name: "flow-move-down";
    readonly label: "Move down";
    readonly dx: 0;
    readonly dy: 1;
}, {
    readonly name: "flow-move-left";
    readonly label: "Move left";
    readonly dx: -1;
    readonly dy: 0;
}];
export declare const FLOW_DELETE_ACTION: {
    readonly name: "flow-delete";
    readonly label: "Delete node";
};
export interface FlowAccessibilityNode {
    id: string;
    label: string;
}
export interface FlowAccessibilityHandle {
    key: string;
    node: string;
    id: string;
    label: string;
    type: 'source' | 'target' | 'both';
}
export interface FlowConnectionAction {
    name: string;
    label: string;
    connection: FlowConnection;
}
/** Opaque, collision-free name for the native accessibility action map. */
export declare function flowConnectionActionName(source: {
    node: string;
    handle?: string;
}, target: {
    node: string;
    handle?: string;
}): string;
/** Keep pointer and assistive-technology movement inside the same group bounds. */
export declare function clampNodePosition(rect: FlowRect, bounds: FlowRect | undefined, position: FlowNodePosition): FlowNodePosition;
export declare function moveNodePosition(rect: FlowRect, bounds: FlowRect | undefined, actionName: string, step: number): FlowNodePosition | undefined;
/** Build connection choices from the same registered nodes and handles used by drag hit-testing. */
export declare function getFlowConnectionActions(sourceNode: string, nodes: FlowAccessibilityNode[], handles: FlowAccessibilityHandle[]): FlowConnectionAction[];
//# sourceMappingURL=flow-accessibility.d.ts.map