export interface FlowEndpoint {
    node: string;
    handle?: string;
}
export type FlowEndpointReference = string | FlowEndpoint;
/** Opaque identity for a registered handle. Node and handle text remain untouched. */
export declare function encodeFlowHandleKey(node: string, handle: string): string;
export declare function decodeFlowHandleKey(token: string): FlowEndpoint | undefined;
/** Opaque identity for an edge registration or accessibility connection action. */
export declare function encodeFlowEdgeKey(from: FlowEndpointReference, to: FlowEndpointReference): string;
export declare function decodeFlowEdgeKey(token: string): {
    from: FlowEndpointReference;
    to: FlowEndpointReference;
} | undefined;
/**
 * Resolve a public endpoint without splitting its identifiers. Exact node ids
 * win; legacy `node.handle` text is accepted only when it names one registered
 * handle. Structured endpoints cover the otherwise ambiguous case.
 */
export declare function resolveFlowEndpoint(reference: FlowEndpointReference, nodes: readonly string[], handles: readonly {
    node: string;
    id: string;
}[]): FlowEndpoint;
//# sourceMappingURL=flow-identifiers.d.ts.map