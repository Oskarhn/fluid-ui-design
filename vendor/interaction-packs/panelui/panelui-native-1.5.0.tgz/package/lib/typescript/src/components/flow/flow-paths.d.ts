/**
 * Edge geometry for Flow.
 *
 * Every function here is a worklet, because all of it runs against node
 * positions held in a shared value: an edge recomputes its `d` string on the UI
 * thread as a node is dragged, and a worklet may only call another worklet.
 * They take and return plain numbers for the same reason — crossing the bridge
 * per frame is exactly what this design exists to avoid.
 *
 * Kept out of `index.tsx` so the component file stays about components. Named
 * `flow-paths` rather than `paths` because the registry copies a component's
 * whole directory into one flat `ui/` folder, where `paths.ts` would be a land
 * grab on a very common name.
 */
/** Which face of a node an edge leaves from or arrives at. */
export type FlowSide = 'top' | 'right' | 'bottom' | 'left';
/** A node's box in graph coordinates. */
export interface FlowRect {
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface FlowPoint {
    x: number;
    y: number;
}
/** The outward unit normal of a face — which way an edge sets off. */
export declare function sideNormal(side: FlowSide): FlowPoint;
/**
 * Where on a face an edge attaches. `offset` runs 0–1 along the face, so two
 * handles on the same side can sit apart without either knowing about the other.
 */
export declare function anchorOf(rect: FlowRect, side: FlowSide, offset: number): FlowPoint;
/**
 * Pushes an anchor out along its own face's normal.
 *
 * For an end attached to something that draws its own border: landing exactly
 * on the border puts the line under the stroke, where it reads as stopping
 * short rather than as arriving.
 */
export declare function standOff(point: FlowPoint, side: FlowSide, by: number): FlowPoint;
/**
 * The faces two nodes should use when nobody has said. Whichever axis they are
 * further apart on wins, so nodes side by side connect left-to-right and nodes
 * stacked connect top-to-bottom — and the edge changes its mind as they are
 * dragged past each other, which is what makes a hand-arranged graph stay
 * readable without anyone re-specifying anything.
 */
export declare function autoSides(from: FlowRect, to: FlowRect): {
    from: FlowSide;
    to: FlowSide;
};
/** A line, for a graph where the routing is not the point. */
export declare function straightPath(from: FlowPoint, to: FlowPoint): string;
/** A cubic curve leaving and arriving perpendicular to each face. */
export declare function bezierPath(from: FlowPoint, fromSide: FlowSide, to: FlowPoint, toSide: FlowSide, curvature: number): string;
/**
 * An orthogonal route with rounded corners — the one that reads as wiring.
 *
 * Both ends first step `gap` points straight out along their own face, so the
 * edge leaves the node square-on instead of grazing its corner. From there the
 * two are joined by a single dog-leg, split across the axis they are further
 * apart on.
 *
 * `radius` of 0 gives hard corners, which is the stepped variant.
 */
export declare function smoothStepPath(from: FlowPoint, fromSide: FlowSide, to: FlowPoint, toSide: FlowSide, radius: number, gap: number): string;
/**
 * The `d` string for an edge between two anchors, in whichever shape was asked
 * for. One entry point, so an edge's animated props are a single call.
 */
export declare function edgePath(variant: 'bezier' | 'smoothstep' | 'step' | 'straight', from: FlowPoint, fromSide: FlowSide, to: FlowPoint, toSide: FlowSide, curvature: number, radius: number, gap: number): string;
/** Length of an edge's bounding diagonal — enough to size a dash cycle by. */
export declare function edgeSpan(from: FlowPoint, to: FlowPoint): number;
/**
 * The arrowhead at an edge's target, as its own closed path.
 *
 * SVG has `marker-end` for exactly this, and it is the obvious way to do it.
 * It is not used, because a path carrying a marker reference stops picking up
 * new geometry on re-render — the arrow-bearing edges freeze where they were
 * first drawn while arrow-less ones follow their nodes. Drawing the triangle
 * as an ordinary path costs nine numbers and behaves.
 *
 * `dirX`/`dirY` is the unit direction of travel *into* the target.
 */
export declare function arrowHeadPath(tip: FlowPoint, dirX: number, dirY: number, size: number): string;
/**
 * Which way an edge is travelling as it arrives. Every routing but `straight`
 * comes in perpendicular to the target's face, so the face decides it; a
 * straight line comes in along itself.
 */
export declare function arrivalDirection(variant: 'bezier' | 'smoothstep' | 'step' | 'straight', from: FlowPoint, to: FlowPoint, toSide: FlowSide): {
    x: number;
    y: number;
};
//# sourceMappingURL=flow-paths.d.ts.map