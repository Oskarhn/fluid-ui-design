/** Attach bound helpers to the existing runtime components; no state is cloned. */
export declare function bindFormRuntime<Root, Field, UseForm, UseField>(root: Root, field: Field, useForm: UseForm, useField: UseField): Root & {
    Field: Field;
    useForm: UseForm;
    useField: UseField;
};
//# sourceMappingURL=typed-form.d.ts.map