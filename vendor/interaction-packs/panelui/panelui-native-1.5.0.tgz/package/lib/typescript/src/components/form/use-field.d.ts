import type { FormApi, Validator } from './use-form.js';
export interface FormFieldRenderProps<V> {
    value: V;
    /** Only set once the field has been touched (blurred, or the form submitted). */
    error?: string;
    touched: boolean;
    onChange: (value: V) => void;
    onBlur: () => void;
}
export interface UseFieldOptions<T extends Record<string, any>, K extends keyof T> {
    validate?: Validator<T, K>;
    /** Runs on blur, and always on submit. `'change'` also validates on every edit. */
    validateOn?: 'blur' | 'change';
}
export declare function useField<T extends Record<string, any>, K extends keyof T>(form: FormApi<T>, name: K, { validate, validateOn }?: UseFieldOptions<T, K>): FormFieldRenderProps<T[K]>;
//# sourceMappingURL=use-field.d.ts.map