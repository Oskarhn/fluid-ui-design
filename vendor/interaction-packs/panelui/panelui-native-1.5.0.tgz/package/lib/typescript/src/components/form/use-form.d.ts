export type FieldErrors<T> = Partial<Record<keyof T, string>>;
export type FieldTouched<T> = Partial<Record<keyof T, boolean>>;
export type Validator<T extends Record<string, any>, K extends keyof T> = (value: T[K], values: T) => string | undefined | Promise<string | undefined>;
export interface FieldState<V> {
    value: V;
    error?: string;
    touched: boolean;
}
export interface UseFormOptions<T extends Record<string, any>> {
    defaultValues: T;
    /** Whole-form validation, e.g. a rule that compares two fields. Runs on submit. */
    validate?: (values: T) => FieldErrors<T> | Promise<FieldErrors<T>>;
    onSubmit: (values: T) => void | Promise<void>;
}
export interface FormApi<T extends Record<string, any>> {
    values: T;
    errors: FieldErrors<T>;
    touched: FieldTouched<T>;
    isSubmitting: boolean;
    /** No field currently carries a validation error. Fields validate on blur and
     * submit, so this does not guarantee an untouched field would pass. */
    isValid: boolean;
    /** `values` differs from `defaultValues`, compared as JSON. */
    isDirty: boolean;
    setFieldValue: <K extends keyof T>(name: K, value: T[K]) => void;
    setFieldTouched: <K extends keyof T>(name: K, touched?: boolean) => void;
    setFieldError: <K extends keyof T>(name: K, error: string | undefined) => void;
    /** Read the latest value, including a change made before React renders again. */
    getValue: <K extends keyof T>(name: K) => T[K];
    /** Read a field from this render so a component naturally follows its changes. */
    watch: <K extends keyof T>(name: K) => T[K];
    getFieldState: <K extends keyof T>(name: K) => FieldState<T[K]>;
    /** Used by `useField`/`Form.Field` to attach a field's validation rule. */
    registerValidator: <K extends keyof T>(name: K, validator?: Validator<T, K>) => void;
    /** Runs `name`'s registered validator (if any) and records the result. */
    validateField: <K extends keyof T>(name: K) => Promise<boolean>;
    handleSubmit: () => Promise<void>;
    reset: (values?: T) => void;
}
export declare function useForm<T extends Record<string, any>>({ defaultValues, validate, onSubmit, }: UseFormOptions<T>): FormApi<T>;
//# sourceMappingURL=use-form.d.ts.map