/**
 * The arithmetic behind the image viewer, kept apart from the component.
 *
 * Every function here runs on the UI thread inside a gesture or an animated
 * style, so each is a worklet. None of them touches React Native, which is what
 * lets the contract tests run them in Node.
 */
export interface Size {
    width: number;
    height: number;
}
export interface Rect extends Size {
    x: number;
    y: number;
}
/** How much a rubber-banded overshoot gives. Lower is stiffer. */
export declare const RUBBER_BAND = 0.55;
export declare function clamp(value: number, min: number, max: number): number;
export declare function lerp(from: number, to: number, t: number): number;
export declare function lerpRect(from: Rect, to: Rect, t: number): Rect;
/**
 * The largest rect with the image's proportions that fits inside the box,
 * centred in it. An image with no known size fills the box.
 */
export declare function fitContain(image: Size, box: Size): Rect;
/** `fitContain` inside a rect that does not start at the origin. */
export declare function fitWithin(image: Size, box: Rect): Rect;
/**
 * The smallest size with the image's proportions that covers the frame.
 *
 * A thumbnail crops its picture to its box; the viewer shows the whole of it.
 * Drawing the image at this size inside a frame that grows from one to the
 * other is what makes the crop open out instead of the picture jumping.
 */
export declare function coverSize(image: Size, frame: Size): Size;
/**
 * How far past its limit a value is allowed to travel, given how far it was
 * pushed. The resistance grows with the push and never quite reaches `dimension`.
 */
export declare function rubberBand(overshoot: number, dimension: number, coefficient?: number): number;
/** Clamps to `[min, max]`, letting the value stretch past either end with resistance. */
export declare function rubberBandClamp(value: number, min: number, max: number, dimension: number, coefficient?: number): number;
/**
 * How far a zoomed image may be moved along one axis before its edge comes away
 * from the screen's. Zero while the scaled image is smaller than the screen,
 * which keeps it centred on that axis.
 */
export declare function panBound(fitted: number, scale: number, viewport: number): number;
/**
 * The translation that keeps a point under the fingers while the scale changes.
 *
 * `offset` is where that point sat relative to the image's centre when the
 * pinch began, at `fromScale`; `focal` is the fingers' position now, relative
 * to the screen's centre. The result is measured from the screen's centre too.
 */
export declare function focalTranslation(focal: number, offset: number, fromScale: number, toScale: number): number;
/**
 * The page a released pager settles on. Where it would have coasted to decides
 * it rather than where it was let go, so a short flick still turns the page —
 * but never by more than one, which is what a flick means.
 */
export declare function snapPage(offset: number, velocity: number, current: number, count: number, pageWidth: number): number;
/** What a one-finger drag on a picture at its fitted size is for. */
export type DragIntent = 'undecided' | 'page' | 'dismiss';
/**
 * Sideways across a gallery turns the page; anything else drags the picture
 * away. A drag that has not moved yet is `undecided`: some gesture-handler
 * versions report the activating event with no translation at all, and
 * comparing zero with zero would take every swipe as a dismiss.
 */
export declare function dragIntent(translationX: number, translationY: number, count: number): DragIntent;
/** How far a drag has to travel, counting where it was flung, to close the viewer. */
export declare const DISMISS_DISTANCE = 110;
/**
 * Whether a released drag closes the viewer.
 *
 * Measured on where the image was heading rather than where it was dropped, so
 * a quick flick closes it from a short distance and a slow drag that is let go
 * of carefully does not. A throw back towards the centre cancels.
 */
export declare function shouldDismiss(translation: number, velocity: number): boolean;
/**
 * How much of the backdrop is left while the image is dragged away from the
 * centre. It is mostly gone by the time the drag would close the viewer, so the
 * page coming back into focus is the warning that letting go will close it.
 */
export declare function dragFade(distance: number, viewport: number): number;
/** How small the image gets while it is dragged. Never below 0.8 of its size. */
export declare function dragScale(distance: number, viewport: number): number;
/** Whether a point lands on a rect that has been scaled about its centre and moved. */
export declare function hitsRect(px: number, py: number, rect: Rect, scale: number, tx: number, ty: number): boolean;
//# sourceMappingURL=image-viewer-geometry.d.ts.map