/**
 * InputGroup — an Input with leading and/or trailing decorators.
 *
 * Prefix and Suffix are absolutely positioned and their measured widths become
 * padding on the Input, so text never runs underneath a decorator regardless
 * of how wide that decorator turns out to be.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type InputProps } from '../input/index.js';
import type { TextInputRef, ViewRef } from '../../primitives/refs.js';
export interface InputGroupProps extends ViewProps {
    className?: string;
    /** Disables the input and dims both decorators. */
    isDisabled?: boolean;
    children?: ReactNode;
}
export interface InputGroupDecoratorProps extends ViewProps {
    className?: string;
    /**
     * Marks the decorator as presentation-only: touches fall through to the
     * Input and screen readers skip it. Leave it off when the decorator holds
     * something interactive, such as a show-password toggle.
     */
    isDecorative?: boolean;
    children?: ReactNode;
}
export type InputGroupInputProps = InputProps;
export declare const InputGroup: import("react").ForwardRefExoticComponent<InputGroupProps & import("react").RefAttributes<ViewRef>> & {
    Prefix: import("react").ForwardRefExoticComponent<InputGroupDecoratorProps & import("react").RefAttributes<ViewRef>>;
    Input: import("react").ForwardRefExoticComponent<InputProps & import("react").RefAttributes<TextInputRef>>;
    Suffix: import("react").ForwardRefExoticComponent<InputGroupDecoratorProps & import("react").RefAttributes<ViewRef>>;
};
//# sourceMappingURL=index.d.ts.map