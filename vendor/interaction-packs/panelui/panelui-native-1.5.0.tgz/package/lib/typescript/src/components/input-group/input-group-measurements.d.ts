export type InputGroupDecoratorSide = 'prefix' | 'suffix';
export type InputGroupDecoratorOwner = symbol;
export interface InputGroupMeasurements {
    prefixWidth: number;
    suffixWidth: number;
    measureDecorator: (side: InputGroupDecoratorSide, owner: InputGroupDecoratorOwner, width: number) => void;
    removeDecorator: (side: InputGroupDecoratorSide, owner: InputGroupDecoratorOwner) => void;
}
type MeasureDecorator = InputGroupMeasurements['measureDecorator'];
type RemoveDecorator = InputGroupMeasurements['removeDecorator'];
/** Keeps measured padding tied to the decorators that are still mounted. */
export declare function useInputGroupMeasurements(): InputGroupMeasurements;
/** Gives one mounted decorator an owner token and unregisters only that owner. */
export declare function useInputGroupDecoratorMeasurement(side: InputGroupDecoratorSide, measureDecorator: MeasureDecorator | undefined, removeDecorator: RemoveDecorator | undefined): (nextWidth: number) => void;
export {};
//# sourceMappingURL=input-group-measurements.d.ts.map