export declare function inputContentPadding(width: number, present: boolean): number | undefined;
//# sourceMappingURL=input-content-padding.d.ts.map