/**
 * Item — a row of content: media on one side, a title and description in the
 * middle, actions on the other side.
 *
 * It is the shape almost every list in an app already has — a settings row, a
 * file in a picker, a member in a team list, a tool call in a transcript — so
 * it exists as one composable primitive rather than being rebuilt per screen
 * with slightly different padding each time.
 *
 * ```tsx
 * <Item variant="outline">
 *   <Item.Media variant="icon"><ReceiptIcon /></Item.Media>
 *   <Item.Content>
 *     <Item.Title>Invoice.pdf</Item.Title>
 *     <Item.Description>2.4 MB · Updated yesterday</Item.Description>
 *   </Item.Content>
 *   <Item.Actions><Button size="sm">Open</Button></Item.Actions>
 * </Item>
 * ```
 *
 * Two axes, and they are independent. `orientation` on the item decides
 * whether its own parts sit side by side or stack into a card; `orientation`
 * on `Item.Group` decides whether the items themselves run down the screen or
 * across it. A carousel wants both set to the non-default: a horizontal group
 * of vertical items.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type AnimatedPressableProps } from '../../primitives/animated-pressable.js';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
type ItemSize = 'default' | 'sm' | 'xs';
type ItemOrientation = 'horizontal' | 'vertical';
declare const itemVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        default: {};
        outline: {
            root: string;
        };
        muted: {
            root: string;
        };
    };
    size: {
        default: {
            root: string;
            title: string;
            description: string;
        };
        sm: {
            root: string;
            title: string;
            description: string;
        };
        xs: {
            root: string;
            title: string;
            description: string;
        };
    };
    orientation: {
        /** Media, text and actions side by side — the list-row shape. */
        horizontal: {
            root: string;
        };
        /** Stacked into a card — the shape a horizontal carousel wants. */
        vertical: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    title: string;
    description: string;
}, undefined, {
    variant: {
        default: {};
        outline: {
            root: string;
        };
        muted: {
            root: string;
        };
    };
    size: {
        default: {
            root: string;
            title: string;
            description: string;
        };
        sm: {
            root: string;
            title: string;
            description: string;
        };
        xs: {
            root: string;
            title: string;
            description: string;
        };
    };
    orientation: {
        /** Media, text and actions side by side — the list-row shape. */
        horizontal: {
            root: string;
        };
        /** Stacked into a card — the shape a horizontal carousel wants. */
        vertical: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    title: string;
    description: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        default: {};
        outline: {
            root: string;
        };
        muted: {
            root: string;
        };
    };
    size: {
        default: {
            root: string;
            title: string;
            description: string;
        };
        sm: {
            root: string;
            title: string;
            description: string;
        };
        xs: {
            root: string;
            title: string;
            description: string;
        };
    };
    orientation: {
        /** Media, text and actions side by side — the list-row shape. */
        horizontal: {
            root: string;
        };
        /** Stacked into a card — the shape a horizontal carousel wants. */
        vertical: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    title: string;
    description: string;
}>>;
declare const mediaVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        /** No box — for an Avatar or anything that styles itself. */
        default: "";
        /** Rounded square tile sized for an icon. */
        icon: "rounded-lg border border-border bg-muted";
        /** Clipped frame for an image or thumbnail. */
        image: "overflow-hidden rounded-lg bg-muted";
    };
    size: {
        default: "";
        sm: "";
        xs: "";
    };
}, undefined, "shrink-0 items-center justify-center", {
    variant: {
        /** No box — for an Avatar or anything that styles itself. */
        default: "";
        /** Rounded square tile sized for an icon. */
        icon: "rounded-lg border border-border bg-muted";
        /** Clipped frame for an image or thumbnail. */
        image: "overflow-hidden rounded-lg bg-muted";
    };
    size: {
        default: "";
        sm: "";
        xs: "";
    };
}, undefined, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        /** No box — for an Avatar or anything that styles itself. */
        default: "";
        /** Rounded square tile sized for an icon. */
        icon: "rounded-lg border border-border bg-muted";
        /** Clipped frame for an image or thumbnail. */
        image: "overflow-hidden rounded-lg bg-muted";
    };
    size: {
        default: "";
        sm: "";
        xs: "";
    };
}, undefined>>;
export interface ItemProps extends Omit<AnimatedPressableProps, 'children' | 'disabled'>, Omit<VariantProps<typeof itemVariants>, 'disabled'> {
    className?: string;
    disabled?: boolean;
    /**
     * Row density. `Item.Media`, `Item.Title` and `Item.Description` follow it,
     * so it only needs setting here.
     */
    size?: ItemSize;
    /**
     * `horizontal` is the list row: media, text and actions side by side.
     * `vertical` stacks them into a card, which is what a horizontal carousel
     * wants — and it is also what `Item.Header` and `Item.Footer` need, since
     * both are full-width strips.
     */
    orientation?: ItemOrientation;
    children?: ReactNode;
}
export interface ItemGroupProps extends ViewProps {
    className?: string;
    /**
     * `vertical` stacks the items — the settings-list shape. `horizontal` runs
     * them across instead, for a carousel; pair it with a scrollable and
     * `orientation="vertical"` on each item so every entry reads as a card.
     */
    orientation?: ItemOrientation;
    children?: ReactNode;
}
export interface ItemSeparatorProps extends ViewProps {
    className?: string;
    /** Match the group's axis: a horizontal group needs vertical hairlines. */
    orientation?: ItemOrientation;
}
export interface ItemMediaProps extends ViewProps, VariantProps<typeof mediaVariants> {
    className?: string;
    children?: ReactNode;
}
export interface ItemContentProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface ItemTitleProps extends TextProps {
    className?: string;
}
export interface ItemDescriptionProps extends TextProps {
    className?: string;
}
export interface ItemActionsProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface ItemHeaderProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface ItemFooterProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export declare const Item: import("react").ForwardRefExoticComponent<ItemProps & import("react").RefAttributes<ViewRef>> & {
    Group: import("react").ForwardRefExoticComponent<ItemGroupProps & import("react").RefAttributes<ViewRef>>;
    Separator: import("react").ForwardRefExoticComponent<ItemSeparatorProps & import("react").RefAttributes<ViewRef>>;
    Media: import("react").ForwardRefExoticComponent<ItemMediaProps & import("react").RefAttributes<ViewRef>>;
    Content: import("react").ForwardRefExoticComponent<ItemContentProps & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<ItemTitleProps & import("react").RefAttributes<TextRef>>;
    Description: import("react").ForwardRefExoticComponent<ItemDescriptionProps & import("react").RefAttributes<TextRef>>;
    Actions: import("react").ForwardRefExoticComponent<ItemActionsProps & import("react").RefAttributes<ViewRef>>;
    Header: import("react").ForwardRefExoticComponent<ItemHeaderProps & import("react").RefAttributes<ViewRef>>;
    Footer: import("react").ForwardRefExoticComponent<ItemFooterProps & import("react").RefAttributes<ViewRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map