/**
 * Label — text that names a form field.
 *
 * A string child is wrapped in `Label.Text` automatically, so the common case
 * stays one line; pass the parts explicitly when the label needs more than
 * text. `isRequired`, `isInvalid` and `isDisabled` are visual *and* semantic —
 * they recolour and they set the accessibility state, so the two cannot drift
 * apart.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
export interface LabelProps extends ViewProps {
    className?: string;
    /** Appends an asterisk marking the field as required. */
    isRequired?: boolean;
    /** Recolours the label to signal a validation error. */
    isInvalid?: boolean;
    isDisabled?: boolean;
    children?: ReactNode;
}
export interface LabelTextProps extends TextProps {
    className?: string;
    /** Classes for the required asterisk. */
    asteriskClassName?: string;
}
export declare const Label: import("react").ForwardRefExoticComponent<LabelProps & import("react").RefAttributes<ViewRef>> & {
    Text: import("react").ForwardRefExoticComponent<LabelTextProps & import("react").RefAttributes<TextRef>>;
};
//# sourceMappingURL=index.d.ts.map