import { type ImageSourcePropType, type ViewProps } from 'react-native';
import type { ViewRef } from '../../primitives/refs.js';
export { rankEntries } from './leaderboard-rank.js';
export type { Ranked as LeaderboardRanked } from './leaderboard-rank.js';
export interface LeaderboardEntry {
    /** Stable identity, used for keys and `highlightId`. */
    id: string;
    /** Shown on the row and read out first after the rank. */
    name: string;
    /** What the board is ranked by. */
    value: number;
    /** Image for the avatar. A string is taken as a URI. Initials stand in without one. */
    avatar?: ImageSourcePropType | string;
    /** A second line under the name — a team, a level, a city. */
    subtitle?: string;
    /**
     * Places moved since the last period. Positive is up the board, negative
     * is down, 0 is unchanged. Leave it out to show no movement column.
     */
    change?: number;
}
export type LeaderboardPodium = 'bars' | 'cards' | 'none';
export interface LeaderboardProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** The entries, in any order. Places are worked out from `value`. */
    data: readonly LeaderboardEntry[];
    /**
     * How the top three are drawn. `bars` stands them on a podium whose bars
     * are scaled to their values; `cards` gives each a card, with first raised
     * between the other two; `none` puts everyone in the list.
     */
    podium?: LeaderboardPodium;
    /**
     * `desc` ranks the highest value first. `asc` ranks the lowest first, for a
     * time or a golf score.
     */
    order?: 'desc' | 'asc';
    /**
     * What the podium bar heights follow. `value` draws each against the
     * leader's value; `rank` steps them by place. Always `rank` when `order` is
     * `asc`, where the winning value is the smallest.
     */
    podiumScale?: 'value' | 'rank';
    /** Height of the tallest podium bar, in points. */
    podiumHeight?: number;
    /** Show at most this many entries, podium included. */
    limit?: number;
    /**
     * The entry to mark — usually the person looking at the board. Their row is
     * tinted, and if `limit` cuts them off it is pinned at the bottom with their
     * real place.
     */
    highlightId?: string;
    /** Turns a value into its label. Defaults to grouped digits: 12,480. */
    formatValue?: (value: number) => string;
    /** Word read after the value by a screen reader, e.g. "points". */
    unit?: string;
    /** Makes every row and podium place pressable. */
    onPressEntry?: (entry: LeaderboardEntry, rank: number) => void;
    /** Shown when `data` has nothing to rank. */
    emptyText?: string;
}
export declare const Leaderboard: import("react").ForwardRefExoticComponent<LeaderboardProps & import("react").RefAttributes<ViewRef>>;
//# sourceMappingURL=index.d.ts.map