export interface LiveLineAccessiblePoint {
    time: number;
    value: number;
}
export interface LiveLineAccessibilityInput {
    name?: string;
    status: 'loading' | 'ready';
    latest: LiveLineAccessiblePoint | null;
    activePoint: LiveLineAccessiblePoint | null;
    momentum: 'up' | 'down' | 'flat';
    windowSeconds: number;
    paused: boolean;
    now: number;
    valueOverride?: string;
    formatLatest: (value: number) => string;
    formatActive: (value: number) => string;
}
/** One bounded snapshot for a stream, rather than one node per arriving point. */
export declare function liveLineAccessibility({ name, status, latest, activePoint, momentum, windowSeconds, paused, now, valueOverride, formatLatest, formatActive, }: LiveLineAccessibilityInput): {
    label: string;
};
//# sourceMappingURL=live-line-accessibility.d.ts.map