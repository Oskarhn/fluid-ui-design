import type { AppStateStatus } from 'react-native';
export interface LiveLineReading {
    time: number;
    value: number;
}
export declare const DEFAULT_LIVE_LINE_WINDOW = 30;
export declare const DEFAULT_LIVE_LINE_MAX_POINTS = 500;
export declare function normalizeLiveLineWindow(seconds: number): number;
export declare function normalizeLiveLineMaxPoints(maxPoints: number): number;
/**
 * Builds the one ordered, finite buffer every renderer and interaction reads.
 * For duplicate timestamps the last input wins, matching a corrected reading
 * arriving with the same identity as the one it replaces.
 */
export declare function normalizeLiveLinePoints<T extends LiveLineReading>(data: readonly T[], maxPoints: number): T[];
export declare function liveLineClockRuns(options: {
    paused: boolean;
    loading: boolean;
    reducedMotion: boolean;
    appState: AppStateStatus;
}): boolean;
export declare function reconcileLiveLineActivePoint<T extends LiveLineReading>(active: T | null, points: readonly T[]): T | null;
//# sourceMappingURL=live-line-lifecycle.d.ts.map