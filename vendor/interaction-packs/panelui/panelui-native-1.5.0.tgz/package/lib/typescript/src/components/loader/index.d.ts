import { type ViewProps } from 'react-native';
export type LoaderVariant = 'pulse-dots' | 'bounce-dots' | 'pulsating-dots' | 'liquid-dots' | 'bar-cascade' | 'bouncing-bars' | 'symmetric-wave' | 'morph-ring' | 'wave-physics';
export type LoaderSize = 'sm' | 'md' | 'lg';
export interface LoaderProps extends Omit<ViewProps, 'children'> {
    /**
     * Which animation to draw. They are interchangeable — pick one for the
     * character it gives the screen and keep it.
     */
    variant?: LoaderVariant;
    /** Overall scale. The geometry of every variant is multiplied by it. */
    size?: LoaderSize;
    /**
     * Ink. Takes a theme token by name — `"--color-primary"` — as readily as a
     * literal, and the token is usually what you want: a literal cannot follow
     * the theme into dark mode.
     *
     * With neither, the loader draws in the readable foreground of the surface
     * it is on, so one inside a filled button is legible without being told.
     */
    color?: string;
    /** Multiplier on the tempo. `1` is the designed speed; `2` is twice as fast. */
    speed?: number;
    /**
     * What a screen reader announces. Defaults to "Loading". Say what is
     * loading when the loader is the only thing on the screen.
     */
    label?: string;
    className?: string;
}
/**
 * A loading animation.
 *
 * Nine of them, chosen with `variant`. They all take the same colour, the same
 * `speed`, and the same treatment under reduced motion, so swapping one for
 * another is a one-word change.
 */
export declare const Loader: import("react").MemoExoticComponent<({ variant, size, color, speed, label, className, ...props }: LoaderProps) => import("react").JSX.Element>;
//# sourceMappingURL=index.d.ts.map