/**
 * The basemap, drawn from theme tokens.
 *
 * A hosted map style ships its colours baked in, which gives you exactly two
 * maps: a light one and a dark one. PanelUI has six themes, and a map that
 * stays grey while the rest of the screen turns green is the one element on
 * the page that visibly does not belong to it.
 *
 * So the style is assembled here instead. Tiles still come from the vector
 * source — that is the part worth paying someone for — but every colour in
 * the style is a token the caller's theme already resolved, which means a new
 * theme gets a matching basemap without anyone drawing one.
 *
 * The layer list is deliberately short. A full street style runs to ninety-odd
 * layers separating tunnel casings from bridge casings at eleven zoom stops;
 * almost none of that survives being recoloured down to five greys, and every
 * layer is another thing to keep in step with the tokens. What is here is the
 * set that still reads as a map at any zoom: ground, water, green space,
 * buildings, roads, boundaries, and the labels that make them findable.
 */
import type { StyleSpecification } from './maplibre.js';
/** Resolved theme colours the style is built from. */
export interface BasemapTokens {
    /** Ground — everything that is not something else. */
    background: string;
    /** Water bodies and rivers. */
    water: string;
    /** Parks, forest, and other green space. */
    land: string;
    /** Building footprints. */
    building: string;
    /** Roads, boundaries and other lines. */
    line: string;
    /** Label text. */
    label: string;
    /** Halo behind label text, so it stays legible over any fill. */
    labelHalo: string;
}
/**
 * Vector tiles and the glyphs to label them with.
 *
 * Swappable because the tiles are the one part of the style that is somebody
 * else's to license. The defaults follow the OpenMapTiles schema, so any
 * source using it can be dropped in without touching the layers below.
 */
export interface BasemapSource {
    /** TileJSON URL for the vector source. */
    url: string;
    /** Glyph endpoint, `{fontstack}` and `{range}` templated. */
    glyphs: string;
    /** Font stack for labels. Needs to exist at the glyph endpoint. */
    fonts: string[];
    /** Shown in the attribution control. Check your provider's terms. */
    attribution?: string;
}
/**
 * CARTO's street tiles.
 *
 * Free for non-commercial use; commercial use needs a licence from them. Pass
 * your own `BasemapSource` to use a different provider — the layers below only
 * assume the OpenMapTiles schema, which most vector providers serve.
 */
export declare const CARTO_SOURCE: BasemapSource;
/**
 * Builds a complete MapLibre style from resolved theme colours.
 *
 * `blank` drops the tile source and every layer that reads from it, leaving
 * just the ground colour — a canvas for data that supplies its own geography,
 * such as a choropleth or an arc diagram, where street detail underneath is
 * noise rather than context.
 */
export declare function buildBasemapStyle(tokens: BasemapTokens, options?: {
    blank?: boolean;
    source?: BasemapSource;
}): StyleSpecification;
//# sourceMappingURL=basemap.d.ts.map