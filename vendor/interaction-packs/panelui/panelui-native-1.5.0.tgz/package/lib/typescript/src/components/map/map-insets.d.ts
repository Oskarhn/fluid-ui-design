/**
 * Where things sit once something else is drawn over the map.
 *
 * A map that fills the screen usually has chrome on top of it: a card of
 * figures along the top, a summary along the bottom, the status bar, a
 * floating tab bar. The controls belong in a corner, and a corner is exactly
 * where that chrome goes, so left alone they end up underneath it.
 *
 * Everything drawn over the map therefore says how far in from its edge it
 * reaches, and the controls take the largest claim on their corner and sit
 * past it. This file is that arithmetic and nothing else, kept apart from the
 * views so it can be checked without a device.
 */
export type MapCorner = 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
/** A band across the whole of one edge, or a single corner. */
export type MapOverlayPosition = 'top' | 'bottom' | MapCorner;
/** A distance from each edge of the map, in points. */
export interface MapInsets {
    top: number;
    right: number;
    bottom: number;
    left: number;
}
/** One number for every side, or only the sides that need one. */
export type MapInsetsInput = number | Partial<MapInsets>;
/** What one overlay takes: where it is, and how far in from that edge it reaches. */
export interface MapReservation {
    position: MapOverlayPosition;
    /** Points from the map's top or bottom edge to the overlay's far side. */
    extent: number;
}
/** The style offsets that pin a view: one vertical side and, for a corner, one horizontal. */
export type MapOffsets = Partial<MapInsets>;
/** Expands the `inset` shorthand to four sides. */
export declare function toMapInsets(inset: MapInsetsInput | undefined): MapInsets;
/** Two sets of insets, side by side. */
export declare function addMapInsets(a: MapInsets, b: MapInsets): MapInsets;
/** The corners a position covers. A band covers both corners of its edge. */
export declare function cornersOf(position: MapOverlayPosition): MapCorner[];
/** The furthest any overlay reaches into a corner. 0 when nothing is there. */
export declare function reservedAt(corner: MapCorner, reservations: Iterable<MapReservation>): number;
/**
 * Where an overlay is pinned, and how far it reaches once it has a height.
 *
 * A band is pinned on three sides so it spans the map between its insets. A
 * corner is pinned on two and is as wide as what is inside it.
 */
export declare function overlayOffsets(position: MapOverlayPosition, inset: MapInsets): MapOffsets;
/**
 * The reservation an overlay makes once it has been measured.
 *
 * Nothing until it has a height. An overlay that is empty, or has not been
 * laid out yet, would otherwise claim its inset alone and nudge the controls
 * by a gap for a frame before moving them to where they belong.
 */
export declare function overlayReservation(position: MapOverlayPosition, inset: MapInsets, height: number): MapReservation | null;
/**
 * The distance a part keeps from each edge of the map.
 *
 * `inset` means the same thing on `Map.Controls` and `Map.Overlay`: how far
 * from the edge, with the standard gap on any side it leaves out. The safe
 * area is added on top, because a card 12 points from the edge of the screen
 * and a card 12 points below the status bar are both "12 points in" to the
 * person looking at them.
 */
export declare function resolveMapInsets(inset: MapInsetsInput | undefined, gap: number, safeArea: MapInsets): MapInsets;
/**
 * Where a control stack in `corner` goes.
 *
 * `inset` is the stack's own distance from the map's edges. `reserved` is what
 * an overlay has taken from the same edge, and the stack sits one `gap` past
 * it. The two are not added: an overlay that already clears the status bar has
 * cleared it for the controls too, so whichever reaches further decides.
 */
export declare function controlsOffsets(corner: MapCorner, { gap, inset, reserved }: {
    gap: number;
    inset: MapInsets;
    reserved: number;
}): MapOffsets;
//# sourceMappingURL=map-insets.d.ts.map