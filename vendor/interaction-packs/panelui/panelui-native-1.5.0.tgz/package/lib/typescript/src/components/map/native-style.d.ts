import type { StyleSpecification } from './maplibre.js';
/**
 * The style with everything native cannot parse translated or removed.
 *
 * Returns the same object when there is nothing to change, and never mutates
 * the one it is given — a caller passing a style constant would otherwise
 * find it rewritten under them.
 */
export declare function adaptStyleForNative(style: StyleSpecification): StyleSpecification;
/**
 * Fetches a hosted style and adapts it. Resolves `null` when the style could
 * not be fetched or read, so the caller can leave the URL to the renderer —
 * which has its own cache and request headers, and reports its own errors.
 */
export declare function loadStyleForNative(url: string): Promise<StyleSpecification | null>;
/**
 * `mapStyle`, ready for the native renderer.
 *
 * `undefined` when no style was given, and `null` while a hosted style is
 * still being fetched. Anything that is not an http(s) URL or a style document
 * — an `asset://` path, a provider scheme — is passed through untouched,
 * because only the renderer knows how to load it.
 */
export declare function useNativeStyle(style: string | StyleSpecification | undefined): string | StyleSpecification | null | undefined;
//# sourceMappingURL=native-style.d.ts.map