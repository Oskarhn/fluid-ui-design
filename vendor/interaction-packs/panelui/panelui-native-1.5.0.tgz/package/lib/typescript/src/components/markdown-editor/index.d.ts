/**
 * MarkdownEditor — a field for writing markdown, and a way to see it rendered.
 *
 * ```tsx
 * const [draft, setDraft] = useState('');
 *
 * <MarkdownEditor value={draft} onValueChange={setDraft} rows={12} />
 * ```
 *
 * ## Writing and reading are two modes, not two panes
 *
 * Side by side is how this is done on a desktop, and it does not survive the
 * trip to a phone: two columns of a phone's width are two columns too narrow to
 * read, and the keyboard covers the bottom half of the screen exactly when the
 * writer is using it. So there is one pane and a switch — write, or read what
 * you wrote. The toolbar carries the switch, because the toolbar is the one
 * thing on screen in both modes.
 *
 * ## The toolbar edits the selection
 *
 * Every button here is a function of the text and where the caret is in it, and
 * the answer that matters is not which characters get inserted but where the
 * caret lands afterwards. Bolding a selected phrase leaves it selected, so it
 * can be italicised next; bolding nothing puts the caret between the new
 * markers, where the writing is about to go; and pressing the same button again
 * takes the markers off. Those rules live in `markdown-transforms.ts` as pure
 * functions over `(text, selection)`, away from anything to do with a field.
 *
 * ## Why it renders through Response
 *
 * The preview is `Response`, the same reader that renders a model's answer, so
 * markdown means the same thing everywhere in the library and there is one
 * parser to be right rather than two to keep in step. It renders through
 * `Typography`, `CodeBlock` and `Table`, which is to say through the app's own
 * type and colours — a preview that looked like a document viewer would be
 * showing the writer something they are not going to ship.
 *
 * Nothing here reaches for a platform markdown renderer. `Text` in SwiftUI can
 * parse markdown and Jetpack Compose's cannot, so a platform-backed editor
 * would render on one of the two and be a plain string on the other.
 *
 * Works controlled (`value` + `onValueChange`) or uncontrolled (`defaultValue`).
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type TextareaProps } from '../textarea/index.js';
import { type EditorSelection } from './markdown-transforms.js';
import type { TextInputRef, ViewRef } from '../../primitives/refs.js';
export type { EditorSelection, EditResult } from './markdown-transforms.js';
/** Which pane the editor is showing. */
export type MarkdownEditorMode = 'write' | 'preview';
/** A formatting action the toolbar can offer. */
export type MarkdownEditorAction = 'bold' | 'italic' | 'heading' | 'quote' | 'code' | 'bulletList' | 'orderedList' | 'link' | 'image';
export type MarkdownEditorToolbarVariant = 'bar' | 'pill';
/**
 * What a `ref` on the editor gives you.
 *
 * The same transforms the toolbar runs, so a caller drawing their own controls
 * — a keyboard accessory, a context menu, a single Bold button somewhere else
 * on the screen — does not have to reimplement any of them. Every one applies
 * to the live selection and leaves the caret where the toolbar would.
 */
export interface MarkdownEditorHandle {
    /** The container, for measuring and for anything a `View` ref is good for. */
    readonly view: ViewRef | null;
    /** Runs one of the toolbar's actions against the current selection. */
    apply: (action: MarkdownEditorAction) => void;
    /** Which actions are already in effect where the caret is. */
    getActive: () => MarkdownEditorAction[];
    /** Where the caret is, or what is selected. */
    getSelection: () => EditorSelection;
    /** Moves the caret, or selects a range. */
    setSelection: (selection: EditorSelection) => void;
    /** Puts the caret in the field. Switches to the writing pane if it is not up. */
    focus: () => void;
    blur: () => void;
    /** Switches pane. */
    setMode: (mode: MarkdownEditorMode) => void;
}
export interface MarkdownEditorProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** Controlled text. Leave unset and pass `defaultValue` to run uncontrolled. */
    value?: string;
    /** Starting text when uncontrolled. */
    defaultValue?: string;
    onValueChange?: (value: string) => void;
    /** Controlled pane. */
    mode?: MarkdownEditorMode;
    /** Starting pane when uncontrolled. */
    defaultMode?: MarkdownEditorMode;
    onModeChange?: (mode: MarkdownEditorMode) => void;
    /**
     * Stop the field being edited and the formatting actions being pressed. The
     * switch between the panes stays live: a draft nobody may edit is still a
     * draft somebody may want to read rendered.
     */
    disabled?: boolean;
    /**
     * The parts, in the order they should stack. Left out, the editor draws its
     * toolbar, its field and its preview in that order — which is the whole
     * component, and the reason it usually needs no children.
     */
    children?: ReactNode;
    /** Forwarded to the field when the editor draws its own. */
    placeholder?: string;
    /** Height of the field, in lines. Forwarded to the field the editor draws. */
    rows?: number;
    /**
     * Lift the editor above the keyboard. Forwarded to the field the editor
     * draws, and off by default because it changes which component renders the
     * container — so it cannot be toggled at runtime without remounting the
     * field and dropping focus.
     */
    avoidKeyboard?: boolean;
    /**
     * Continue a list when Return is pressed inside one, and end it when Return
     * is pressed on an item with nothing in it. On by default: a list that stops
     * numbering itself after the first item is a list the writer finishes by
     * hand.
     */
    continueLists?: boolean;
}
export interface MarkdownEditorToolbarProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /**
     * How the toolbar is drawn. `bar` is the full-width row, with room on it for
     * a word count or a submit. `pill` is the floating capsule: icon-only,
     * grouped by hairlines, with the pane switch as a round button beside it.
     */
    variant?: MarkdownEditorToolbarVariant;
    /**
     * Which formatting actions to offer, in the order given. The capsule groups
     * whatever it is given by family — what the words look like, what is being
     * put into the document, what shape the block is — and draws a hairline
     * where the family changes.
     */
    actions?: MarkdownEditorAction[];
    /**
     * Show the write/preview switch. On by default — a preview nobody can reach
     * is a pane that does not exist.
     */
    showModeSwitch?: boolean;
    /**
     * Anything else to put on the row: a word count, a save state, a submit.
     * The capsule has no room for these, so a toolbar with children wants `bar`.
     */
    children?: ReactNode;
}
export interface MarkdownEditorInputProps extends Omit<TextareaProps, 'value' | 'onChangeText' | 'defaultValue'> {
    className?: string;
}
export interface MarkdownEditorPreviewProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** What to show when there is nothing written yet. */
    emptyText?: string;
}
export declare const MarkdownEditor: import("react").ForwardRefExoticComponent<MarkdownEditorProps & import("react").RefAttributes<MarkdownEditorHandle>> & {
    Toolbar: import("react").ForwardRefExoticComponent<MarkdownEditorToolbarProps & import("react").RefAttributes<ViewRef>>;
    Input: import("react").ForwardRefExoticComponent<MarkdownEditorInputProps & import("react").RefAttributes<TextInputRef>>;
    Preview: import("react").ForwardRefExoticComponent<MarkdownEditorPreviewProps & import("react").RefAttributes<ViewRef>>;
};
//# sourceMappingURL=index.d.ts.map