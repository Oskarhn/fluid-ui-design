/**
 * The edits a formatting toolbar makes, as functions of the text and where the
 * caret is in it.
 *
 * Pure, and deliberately so. Every one of these takes `(text, selection)` and
 * returns the text that should replace it together with where the selection
 * should end up — no component, no ref, no input. What makes a formatting
 * toolbar feel broken is never the characters it inserts; it is where the caret
 * lands afterwards, and that is a property of these functions rather than of
 * the field they are wired to.
 *
 * Three rules they all keep:
 *
 * - **Applying twice undoes it.** A toolbar button that only ever adds is a
 *   button you can press once, and every press after that damages the text.
 * - **A selection stays selected.** Bolding three words and then italicising
 *   the same three has to be two presses, not a press and a re-selection.
 * - **With nothing selected, the caret lands where the writing goes** — between
 *   the new markers rather than after them.
 */
export interface EditorSelection {
    start: number;
    end: number;
}
export interface EditResult {
    text: string;
    selection: EditorSelection;
}
/**
 * Wraps the selection in `marker`, or unwraps it if it is already wrapped.
 *
 * "Already wrapped" is checked both ways round: the markers may be inside the
 * selection (the writer selected `**bold**`) or immediately outside it (they
 * selected `bold` in the middle of `**bold**`). Both are the same intent, and a
 * toolbar that only recognised one of them would add a second pair of asterisks
 * to text that already had them.
 */
export declare function toggleWrap(text: string, selection: EditorSelection, marker: string): EditResult;
/**
 * Puts `prefix` on the front of every line the selection touches, or takes it
 * off if every one of them already has it.
 *
 * Every one, not any one: a mixed block is a block the writer is trying to make
 * uniform, so the useful answer there is to add rather than to remove.
 */
export declare function toggleLinePrefix(text: string, selection: EditorSelection, prefix: string): EditResult;
/**
 * Numbers the lines the selection touches, or unnumbers them.
 *
 * Counted from one within the block rather than continuing whatever came above
 * it: the numbers a writer types are not the numbers that get rendered — every
 * markdown reader renumbers an ordered list from its first item — so the useful
 * thing is for the source to read the way the output will.
 */
export declare function toggleOrderedList(text: string, selection: EditorSelection): EditResult;
/** Placeholder left where a link's target goes. */
export declare const LINK_PLACEHOLDER = "url";
/**
 * Turns the selection into a link, and selects the part that still needs
 * filling in.
 *
 * Which part that is depends on what was selected. With text selected, the
 * label is written and the target is not, so the placeholder target is left
 * selected and typing replaces it. With nothing selected there is neither, and
 * the label comes first because it is the half the writer is thinking about.
 */
export declare function insertLink(text: string, selection: EditorSelection): EditResult;
export declare function toggleFence(text: string, selection: EditorSelection): EditResult;
/** Placeholder left where an image's description goes. */
export declare const IMAGE_PLACEHOLDER = "description";
/**
 * Inserts an image, and selects the part that still needs filling in.
 *
 * The description first, not the URL. An image with no alt text is the failure
 * that actually happens, and the writer is far more likely to have the URL on
 * the clipboard than the sentence describing what is in it — so the sentence is
 * what the caret is left on.
 */
export declare function insertImage(text: string, selection: EditorSelection): EditResult;
/**
 * What Return should do inside a list.
 *
 * Returns `null` when the caret is not on a list line, which is the signal to
 * let the newline happen normally. Otherwise it either starts the next item or,
 * on an item with nothing in it, ends the list — because a writer pressing
 * Return on an empty bullet is telling you they have run out of items, and the
 * alternative is a trail of empty bullets they have to delete by hand.
 */
export declare function continueList(text: string, selection: EditorSelection): EditResult | null;
/**
 * Whether an inline marker is already around the caret or the selection.
 *
 * Both arrangements count, for the same reason `toggleWrap` accepts both: the
 * writer may have selected `**bold**` or selected `bold` inside it, and with
 * nothing selected at all the caret may simply be sitting between the markers.
 */
export declare function hasWrap(text: string, selection: EditorSelection, marker: string): boolean;
/** Whether every line the selection touches already starts with `prefix`. */
export declare function hasLinePrefix(text: string, selection: EditorSelection, prefix: string): boolean;
/** Whether every line the selection touches is already numbered. */
export declare function hasOrderedList(text: string, selection: EditorSelection): boolean;
/** Whether the selection is inside a fence. */
export declare function hasFence(text: string, selection: EditorSelection): boolean;
//# sourceMappingURL=markdown-transforms.d.ts.map