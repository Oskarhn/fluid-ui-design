/**
 * Marker — an inline note in a conversation.
 *
 * Transcripts are not only messages. Between the turns sit things the
 * conversation did rather than said: a tool that ran, a file that was read, a
 * model that changed, the point where yesterday ended. Those are not messages
 * and should not look like one — a bubble implies a speaker, and none of these
 * have one. A marker is the quieter row that carries them: small, muted, and
 * aligned to the transcript rather than to a side of it.
 *
 * ```tsx
 * <Marker>
 *   <Marker.Icon><CheckIcon /></Marker.Icon>
 *   <Marker.Content>Explored 4 files</Marker.Content>
 * </Marker>
 * ```
 *
 * `shimmer` on the content is for the row that is still happening — the sweep
 * runs through the glyphs while a step is in flight, and is dropped the moment
 * it finishes.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type AnimatedPressableProps } from '../../primitives/animated-pressable.js';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
type MarkerVariant = 'default' | 'border' | 'separator';
declare const markerVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        /** The plain row: an icon and a line of muted text. */
        default: {};
        /** Same row, closed by a hairline — for a step that ends a section. */
        border: {
            root: string;
        };
        /**
         * A centred label with a rule running out to each edge. The rules are
         * `Separator`s rather than borders so they follow the same token and
         * thickness as every other rule in the app.
         */
        separator: {
            root: string;
            content: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    content: string;
}, undefined, {
    variant: {
        /** The plain row: an icon and a line of muted text. */
        default: {};
        /** Same row, closed by a hairline — for a step that ends a section. */
        border: {
            root: string;
        };
        /**
         * A centred label with a rule running out to each edge. The rules are
         * `Separator`s rather than borders so they follow the same token and
         * thickness as every other rule in the app.
         */
        separator: {
            root: string;
            content: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    content: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        /** The plain row: an icon and a line of muted text. */
        default: {};
        /** Same row, closed by a hairline — for a step that ends a section. */
        border: {
            root: string;
        };
        /**
         * A centred label with a rule running out to each edge. The rules are
         * `Separator`s rather than borders so they follow the same token and
         * thickness as every other rule in the app.
         */
        separator: {
            root: string;
            content: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    content: string;
}>>;
export interface MarkerProps extends Omit<AnimatedPressableProps, 'children' | 'disabled'>, Omit<VariantProps<typeof markerVariants>, 'disabled'> {
    className?: string;
    disabled?: boolean;
    /**
     * `default` is the inline status row. `border` closes it with a hairline.
     * `separator` centres the content between two rules — the "Yesterday"
     * divider shape.
     */
    variant?: MarkerVariant;
    children?: ReactNode;
}
export interface MarkerIconProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface MarkerContentProps extends TextProps {
    className?: string;
    /**
     * Sweep a highlight through the text, for a step that is still running.
     * Drop it when the step finishes — a marker that shimmers forever reads as
     * a stuck one.
     */
    shimmer?: boolean;
    children?: ReactNode;
}
export declare const Marker: import("react").ForwardRefExoticComponent<MarkerProps & import("react").RefAttributes<ViewRef>> & {
    Icon: import("react").ForwardRefExoticComponent<MarkerIconProps & import("react").RefAttributes<ViewRef>>;
    Content: import("react").ForwardRefExoticComponent<MarkerContentProps & import("react").RefAttributes<TextRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map