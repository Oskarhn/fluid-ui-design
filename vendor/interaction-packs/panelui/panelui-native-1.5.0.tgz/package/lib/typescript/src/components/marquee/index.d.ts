/**
 * Marquee — content that travels across its container and never runs out.
 *
 * For a strip of logos, a ticker of prices, a row of testimonials: anything
 * whose job is to keep moving past a boundary rather than to be scrolled.
 *
 * ```tsx
 * <Marquee spacing={24} speed={40}>
 *   <View className="flex-row gap-6">
 *     {sponsors.map((s) => <Logo key={s.id} src={s.logo} />)}
 *   </View>
 * </Marquee>
 * ```
 *
 * ## How it loops
 *
 * The content is measured once, then laid out end to end enough times to cover
 * the container. One track holds every copy and it is that track, not the
 * copies, that moves. The track has a fixed copy budget: exceptionally short
 * content gets extra whitespace instead of multiplying its React subtree
 * hundreds of times. It travels exactly one layout period and starts over, so
 * the state it ends on is the state it began on and the seam never shows.
 *
 * The travel is a linear timing driven on the UI thread, so it costs nothing
 * per frame in JavaScript and keeps running while the thread is busy.
 *
 * ## Measurement needs room
 *
 * The copy that gets measured sits in a hidden scroller, because that is what
 * lets the content report the width it *wants* rather than the width the
 * container would give it. Content with no intrinsic size of its own — a child
 * stretched to `flex-1`, an image with no dimensions — measures as nothing and
 * the marquee will not start.
 *
 * ## Reading direction and reduced motion
 *
 * A horizontal marquee travels toward the end of the line, so it reverses in a
 * right-to-left subtree. `reverse` flips it again from wherever it landed.
 *
 * With the operating system set to reduce motion the content is rendered once
 * and held still. A ticker that never stops is the exact thing that setting is
 * there to turn off, so this is not a shorter animation — it is none.
 *
 * Screen readers get one copy. The rest are duplicates of content already
 * announced, and hearing a sponsor list four times over is not thoroughness.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
export type MarqueeDirection = 'horizontal' | 'vertical';
export interface MarqueeProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** The content to repeat. Measured once, then tiled along the axis. */
    children: ReactNode;
    /**
     * Travel speed in points per second. 40 by default, which is slow enough
     * that a word stays readable as it crosses. The cycle time follows from this
     * and the measured content, so longer content takes proportionally longer
     * rather than moving faster.
     */
    speed?: number;
    /** Minimum gap between the end of one copy and the start of the next. */
    spacing?: number;
    /** Axis the content travels along. */
    direction?: MarqueeDirection;
    /**
     * Send it the other way: toward the start of the line, or upward. Applied
     * after the reading direction, not instead of it.
     */
    reverse?: boolean;
    /** Set false to hold the content where it is. */
    playing?: boolean;
    /**
     * Show the built-in user pause/play control while motion is enabled.
     *
     * Defaults to `true` on its own, and to `false` inside a `Marquee.Group` —
     * the group draws one control for everything in it, and a control per row is
     * how two of them end up stacked on top of each other.
     */
    showPauseControl?: boolean;
    /** Visible and spoken label for the moving state. */
    pauseLabel?: string;
    /** Visible and spoken label for the user-paused state. */
    playLabel?: string;
    /** Reports changes made by the built-in control. */
    onPlayingChange?: (playing: boolean) => void;
}
declare function MarqueeRoot({ className, children, speed: speedProp, spacing, direction, reverse, playing, showPauseControl, pauseLabel, playLabel, onPlayingChange, style, onLayout, ...props }: MarqueeProps): import("react").JSX.Element;
declare namespace MarqueeRoot {
    var displayName: string;
}
export interface MarqueeGroupProps extends ViewProps {
    className?: string;
    /** Set false to hold every marquee in the group where it is. */
    playing?: boolean;
    /** Show the group's pause/play control. */
    showPauseControl?: boolean;
    /** Visible and spoken label for the moving state. */
    pauseLabel?: string;
    /** Visible and spoken label for the user-paused state. */
    playLabel?: string;
    /** Reports changes made by the group's control. */
    onPlayingChange?: (playing: boolean) => void;
    children?: ReactNode;
}
/**
 * Rows of travelling content that stop and start together, under one control.
 *
 * Moving content needs a way to stop it, so a marquee draws its own pause
 * button. Stacked — two rows of logos travelling against each other — that is
 * one button per row, each pinned to its own bottom corner, and the upper one
 * lands on top of the row beneath it. Two buttons for one piece of motion, and
 * one of them covering the content it belongs to.
 *
 * A group is the answer to both: the marquees inside it stop drawing their own
 * control, and the group draws a single one below them rather than over them.
 *
 * ```tsx
 * <Marquee.Group>
 *   <Marquee>{topRow}</Marquee>
 *   <Marquee reverse>{bottomRow}</Marquee>
 * </Marquee.Group>
 * ```
 *
 * Each marquee keeps its own `playing` prop. The group's pause is an additional
 * hold, not a replacement — a row already held still stays still.
 */
declare function MarqueeGroup({ className, children, playing, showPauseControl, pauseLabel, playLabel, onPlayingChange, ...props }: MarqueeGroupProps): import("react").JSX.Element;
declare namespace MarqueeGroup {
    var displayName: string;
}
export declare const Marquee: typeof MarqueeRoot & {
    Group: typeof MarqueeGroup;
};
export {};
//# sourceMappingURL=index.d.ts.map