/**
 * The arithmetic behind the loop, kept out of the component so it can be tested
 * without rendering one.
 *
 * Every value here reaches a Reanimated timing or a layout offset, and both
 * treat `NaN` and `Infinity` as a frame that never resolves rather than as an
 * error. A marquee handed a bad number should hold still, not wedge — so the
 * guards live at the boundary, once, instead of at each use.
 */
/**
 * Points per second. Slow enough that a word stays readable as it crosses,
 * which is the speed a ticker is actually for.
 */
export declare const DEFAULT_MARQUEE_SPEED = 40;
/**
 * Includes the copy just before and just after the viewport. Keeping this
 * fixed prevents tiny content (for example a one-point separator) from
 * multiplying an arbitrary React subtree hundreds of times.
 */
export declare const MAX_MARQUEE_COPIES = 32;
export declare function normalizeMarqueeSpeed(value: number): number;
export declare function normalizeMarqueeSpacing(value: number): number;
export declare function marqueeCopyCount(viewport: number, content: number, spacing: number): {
    period: number;
    count: number;
};
//# sourceMappingURL=marquee-math.d.ts.map