type MessageScrollerTarget = 'start' | 'end';
export declare const MESSAGE_SCROLLER_EDGE_THRESHOLD = 24;
/** Distance from the viewport to the edge a jump button targets. */
export declare function distanceFromMessageScrollerTarget(target: MessageScrollerTarget, contentOffsetY: number, contentHeight: number, viewportHeight: number): number;
/** Whether the control has enough distance to its target edge to be useful. */
export declare function isMessageScrollerTargetVisible(distance: number): boolean;
export interface MessageScrollerIndexedItem {
    messageId: string;
    scrollAnchor?: boolean;
}
/** Index used by initial positioning and id-addressed virtualized jumps. */
export declare function messageScrollerIndex(items: readonly MessageScrollerIndexedItem[], id: string): number | undefined;
/** Initial target for a list; `undefined` means use the physical end. */
export declare function initialMessageScrollerIndex(items: readonly MessageScrollerIndexedItem[], position: 'start' | 'end' | 'last-anchor'): number | undefined;
/** Anchor at or before the first visible virtualized row. */
export declare function messageScrollerAnchorAt(items: readonly MessageScrollerIndexedItem[], firstVisibleIndex: number): string | null;
export {};
//# sourceMappingURL=message-scroller-math.d.ts.map