/**
 * Message — a chat turn: avatar, bubble, and the metadata around it.
 *
 * The pieces are separate because conversations differ in which ones they
 * need. A support thread wants a sender name and a read receipt; an assistant
 * transcript wants neither, but does want the bubble to carry tool output and
 * actions. Composing them beats a component with a dozen optional props.
 *
 * `align` is the only thing the root decides, and everything downstream reads
 * it from context: which side the row sits on, which way the avatar goes,
 * which corner of the bubble is squared off, and which colour it takes.
 *
 * ```tsx
 * <Message align="end">
 *   <Message.Content>
 *     <Message.Bubble>
 *       <Message.BubbleContent>How can I help?</Message.BubbleContent>
 *     </Message.Bubble>
 *   </Message.Content>
 * </Message>
 * ```
 */
import { type ReactNode } from 'react';
import { type GestureResponderEvent, type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
declare const messageVariants: import("tailwind-variants").TVReturnType<{
    align: {
        start: {
            root: string;
            content: string;
            bubble: string;
            bubbleContent: string;
            header: string;
            footer: string;
        };
        end: {
            root: string;
            content: string;
            bubble: string;
            bubbleContent: string;
            header: string;
            footer: string;
        };
    };
}, {
    root: string;
    avatar: string;
    content: string;
    header: string;
    bubble: string;
    bubbleContent: string;
    footer: string;
    group: string;
}, undefined, {
    align: {
        start: {
            root: string;
            content: string;
            bubble: string;
            bubbleContent: string;
            header: string;
            footer: string;
        };
        end: {
            root: string;
            content: string;
            bubble: string;
            bubbleContent: string;
            header: string;
            footer: string;
        };
    };
}, {
    root: string;
    avatar: string;
    content: string;
    header: string;
    bubble: string;
    bubbleContent: string;
    footer: string;
    group: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    align: {
        start: {
            root: string;
            content: string;
            bubble: string;
            bubbleContent: string;
            header: string;
            footer: string;
        };
        end: {
            root: string;
            content: string;
            bubble: string;
            bubbleContent: string;
            header: string;
            footer: string;
        };
    };
}, {
    root: string;
    avatar: string;
    content: string;
    header: string;
    bubble: string;
    bubbleContent: string;
    footer: string;
    group: string;
}>>;
type Align = 'start' | 'end';
export interface MessageProps extends ViewProps, VariantProps<typeof messageVariants> {
    className?: string;
    /**
     * Which side of the conversation this turn belongs to. `end` is the
     * outgoing side — the person holding the device.
     */
    align?: Align;
    /**
     * Continuation of the message above it: tighter spacing, and the avatar slot
     * is reserved but left empty so bubbles stay aligned. `Message.Group` sets
     * this for you.
     */
    stacked?: boolean;
    /**
     * Fires on a long press anywhere on the turn — the gesture a chat uses to
     * surface per-message actions (copy, reply, react). Open a menu from it; the
     * component only exposes the press. When set, the whole row gains press
     * feedback. A plain tap should still do nothing, so there is no `onPress`.
     */
    onLongPress?: (event: GestureResponderEvent) => void;
    children?: ReactNode;
}
export interface MessageGroupProps extends ViewProps {
    className?: string;
    /** Alignment applied to every Message inside that does not set its own. */
    align?: Align;
    children?: ReactNode;
}
export interface MessageAvatarProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface MessageContentProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface MessageHeaderProps extends TextProps {
    className?: string;
}
export interface MessageBubbleProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface MessageBubbleContentProps extends TextProps {
    className?: string;
}
export interface MessageFooterProps extends TextProps {
    className?: string;
}
export interface MessageActionsProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export declare const Message: import("react").ForwardRefExoticComponent<MessageProps & import("react").RefAttributes<ViewRef>> & {
    Group: import("react").ForwardRefExoticComponent<MessageGroupProps & import("react").RefAttributes<ViewRef>>;
    Avatar: import("react").ForwardRefExoticComponent<MessageAvatarProps & import("react").RefAttributes<ViewRef>>;
    Content: import("react").ForwardRefExoticComponent<MessageContentProps & import("react").RefAttributes<ViewRef>>;
    Header: import("react").ForwardRefExoticComponent<MessageHeaderProps & import("react").RefAttributes<TextRef>>;
    Bubble: import("react").ForwardRefExoticComponent<MessageBubbleProps & import("react").RefAttributes<ViewRef>>;
    BubbleContent: import("react").ForwardRefExoticComponent<MessageBubbleContentProps & import("react").RefAttributes<TextRef>>;
    Footer: import("react").ForwardRefExoticComponent<MessageFooterProps & import("react").RefAttributes<TextRef>>;
    Actions: import("react").ForwardRefExoticComponent<MessageActionsProps & import("react").RefAttributes<ViewRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map