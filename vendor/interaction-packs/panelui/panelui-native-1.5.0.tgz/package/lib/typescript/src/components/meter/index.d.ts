import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type MeterColor, type MeterThreshold } from './meter-scale.js';
import type { ViewRef } from '../../primitives/refs.js';
declare const meterVariants: import("tailwind-variants").TVReturnType<{
    color: {
        primary: {
            track: string;
            indicator: string;
            segment: string;
        };
        success: {
            track: string;
            indicator: string;
            segment: string;
        };
        warning: {
            track: string;
            indicator: string;
            segment: string;
        };
        destructive: {
            track: string;
            indicator: string;
            segment: string;
        };
        info: {
            track: string;
            indicator: string;
            segment: string;
        };
        muted: {
            track: string;
            indicator: string;
            segment: string;
        };
    };
    size: {
        sm: {
            track: string;
            segments: string;
            segment: string;
        };
        md: {
            track: string;
            segments: string;
            segment: string;
        };
        lg: {
            track: string;
            segments: string;
            segment: string;
        };
    };
}, {
    root: string;
    header: string;
    track: string;
    indicator: string;
    segments: string;
    segment: string;
}, undefined, {
    color: {
        primary: {
            track: string;
            indicator: string;
            segment: string;
        };
        success: {
            track: string;
            indicator: string;
            segment: string;
        };
        warning: {
            track: string;
            indicator: string;
            segment: string;
        };
        destructive: {
            track: string;
            indicator: string;
            segment: string;
        };
        info: {
            track: string;
            indicator: string;
            segment: string;
        };
        muted: {
            track: string;
            indicator: string;
            segment: string;
        };
    };
    size: {
        sm: {
            track: string;
            segments: string;
            segment: string;
        };
        md: {
            track: string;
            segments: string;
            segment: string;
        };
        lg: {
            track: string;
            segments: string;
            segment: string;
        };
    };
}, {
    root: string;
    header: string;
    track: string;
    indicator: string;
    segments: string;
    segment: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    color: {
        primary: {
            track: string;
            indicator: string;
            segment: string;
        };
        success: {
            track: string;
            indicator: string;
            segment: string;
        };
        warning: {
            track: string;
            indicator: string;
            segment: string;
        };
        destructive: {
            track: string;
            indicator: string;
            segment: string;
        };
        info: {
            track: string;
            indicator: string;
            segment: string;
        };
        muted: {
            track: string;
            indicator: string;
            segment: string;
        };
    };
    size: {
        sm: {
            track: string;
            segments: string;
            segment: string;
        };
        md: {
            track: string;
            segments: string;
            segment: string;
        };
        lg: {
            track: string;
            segments: string;
            segment: string;
        };
    };
}, {
    root: string;
    header: string;
    track: string;
    indicator: string;
    segments: string;
    segment: string;
}>>;
type MeterVariantProps = VariantProps<typeof meterVariants>;
export interface MeterProps extends Omit<ViewProps, 'children'>, MeterVariantProps {
    className?: string;
    /** The measurement. Values outside the scale are clamped to its ends. */
    value: number;
    /**
     * The bottom of the scale — the value at which the bar reads as empty.
     * Defaults to `0`.
     */
    minValue?: number;
    /**
     * The top of the scale — the value at which the bar reads as full. Defaults
     * to `100`, so a bare percentage needs neither bound set.
     */
    maxValue?: number;
    /**
     * What is being measured. Also the accessibility label, and a meter without
     * one announces a number with nothing attached to it — "seventy-five
     * percent" of what is not an answer. Pass `accessibilityLabel` instead only
     * where the caption is drawn some other way.
     */
    label?: string;
    /** Draw the value above the track, opposite the label. */
    showValueLabel?: boolean;
    /**
     * Text for the value label. Overrides the formatted value — use it for a
     * word where a number reads worse: `Strong`, `Almost full`.
     *
     * It is spoken whether or not it is drawn, so it can give a screen reader
     * better words than the caption without changing the caption. Pair it with
     * `showValueLabel` to draw it too.
     */
    valueLabel?: string;
    /**
     * How to write the value, through `Intl.NumberFormat`. A `percent` style
     * formats how far up the scale the value sits; every other style formats
     * the value itself, so `{ style: 'unit', unit: 'gigabyte' }` against a
     * `maxValue` of `256` reads `64 GB` rather than a percentage of it. Falls
     * back to a rounded percent when omitted.
     */
    formatOptions?: Intl.NumberFormatOptions;
    /**
     * Points on the scale where the colour changes, each `{ from, color }`. The
     * highest one the reading has reached wins, so the order you list them in
     * does not matter; below all of them the `color` prop applies. Non-finite
     * `from` values are ignored.
     *
     * This is the difference between a meter and a bar: the colour is a
     * judgement about the reading. Which direction is bad is yours to say —
     * thresholds climbing to `destructive` suit a disk filling up, thresholds
     * falling to it suit a battery running down.
     */
    thresholds?: MeterThreshold[];
    /**
     * Draw the scale as this many discrete blocks instead of one continuous
     * bar. Blocks are all or nothing, which is the point of them: four blocks
     * say "three out of four" where a bar says "about seventy percent", and a
     * password is not seventy percent strong.
     *
     * Fractional counts round down and counts above 100 clamp to 100. Invalid,
     * non-positive, or sub-one counts use the continuous bar. Any value above
     * the floor lights at least one block, so a reading that is not empty never
     * looks it.
     */
    segments?: number;
    /** Extra classes for the fill, or for a lit segment. */
    indicatorClassName?: string;
    /** Extra classes for the label + value row. */
    headerClassName?: string;
}
/**
 * A measurement on a fixed scale: disk used, battery left, a score, a password's
 * strength. The fill is driven on the UI thread, so a value change costs one
 * render and nothing per frame.
 *
 * A meter is not a progress bar. Progress is a task moving towards an end that
 * finishing is the point of; a meter is a reading that happens to sit where it
 * sits, and may go back down. Reach for
 * [Progress](/docs/components/progress) when something is completing.
 *
 * `thresholds` paint the bar by where the reading falls, and `segments` draws
 * the scale as discrete blocks for readings that are counted rather than
 * measured.
 *
 * The value is read against `minValue` / `maxValue`, which default to 0 and
 * 100 — so a percentage needs neither. Set them and the meter speaks in
 * whatever is being measured: bytes, degrees, points. Nothing has to be
 * converted to a percent on the way in, and the screen reader is told the real
 * scale rather than a derived one.
 *
 * React Native has no meter role, so this announces as a progress bar with its
 * value, range and unit attached. That is the closest the platform offers, and
 * it is why `label` matters: the role will not distinguish a reading from a
 * task, and the name is what does.
 */
export declare const Meter: import("react").ForwardRefExoticComponent<MeterProps & import("react").RefAttributes<ViewRef>>;
export type { MeterColor, MeterThreshold };
//# sourceMappingURL=index.d.ts.map