/**
 * Where a reading sits on a meter's scale, and what colour it has earned.
 *
 * Kept apart from the component because it is the part that can be wrong
 * without looking wrong: a threshold picked in the wrong order, or a segment
 * count that rounds a real reading down to nothing, is a meter that lies
 * quietly. None of it touches React, so it can be tested on its own.
 */
/** The token a meter can be painted with. */
export type MeterColor = 'primary' | 'success' | 'warning' | 'destructive' | 'info' | 'muted';
/**
 * A point on the scale, and the colour the meter takes from there upwards.
 *
 * `from` is in the same units as `value` — not a percentage of the range — so
 * a threshold on a 0–8 GB meter is written in gigabytes.
 */
export interface MeterThreshold {
    /** The value at which this colour takes over. */
    from: number;
    /** What the bar is painted with at or above `from`. */
    color: MeterColor;
}
/** A bounded block count keeps malformed input from allocating without limit. */
export declare const MAX_METER_SEGMENTS = 100;
export interface MeterScale {
    min: number;
    max: number;
    value: number;
    fraction: number;
}
/**
 * Make a public scale safe for layout, animation and native accessibility.
 * Invalid bounds fall back to their documented defaults; if those still do
 * not produce a positive span, the scale honestly collapses at its floor.
 */
export declare function normalizeScale(value: number, min: number, max: number): MeterScale;
/** Positive counts are whole and bounded; zero means the continuous meter. */
export declare function normalizeSegments(segments: number | undefined): number;
/** `value` held inside the scale, so a stray number cannot escape the track. */
export declare function clamp(value: number, min: number, max: number): number;
/**
 * How far up the scale the value sits, 0–1. An empty or inverted range has no
 * meaningful position in it, so it reads as empty rather than dividing by zero.
 */
export declare function fractionOf(value: number, min: number, max: number): number;
/**
 * The colour the reading has earned: the highest threshold at or below the
 * value, or the base colour when it has reached none of them.
 *
 * Highest-wins rather than first-wins, so the caller can list thresholds in
 * any order and get the same answer. A rule that depended on the order would
 * make a reordered array a silent behaviour change.
 */
export declare function colorFor(value: number, base: MeterColor | undefined, thresholds: MeterThreshold[] | undefined): MeterColor | undefined;
/**
 * How many blocks of a segmented meter are lit.
 *
 * Rounded up, so any reading above the floor lights at least one. Rounding
 * down would leave the whole first block of a four-block meter dark, and "a
 * little" looking like "none" is the reading a meter can least afford to get
 * wrong.
 */
export declare function litSegments(fraction: number, segments: number): number;
/**
 * The value caption: an explicit override, an `Intl` rendering, or a rounded
 * percent.
 *
 * A `percent` style is given the fraction, because that is what a percentage
 * of the scale means; every other style is given the value, because a byte
 * count or a score is a quantity and not a proportion.
 */
export declare function formatValue(value: number, fraction: number, valueLabel?: string, formatOptions?: Intl.NumberFormatOptions): string;
/**
 * The meter's single spoken contract. Visual treatments such as segments,
 * thresholds and motion do not belong here: they do not change the reading.
 */
export declare function meterSemantics({ value, fraction, minValue, maxValue, label, accessibilityLabel, valueLabel, formatOptions, }: {
    value: number;
    fraction: number;
    minValue: number;
    maxValue: number;
    label?: string;
    accessibilityLabel?: string;
    valueLabel?: string;
    formatOptions?: Intl.NumberFormatOptions;
}): {
    label: string | undefined;
    text: string;
    value: {
        min: number;
        max: number;
        now: number;
        text: string;
    };
};
//# sourceMappingURL=meter-scale.d.ts.map