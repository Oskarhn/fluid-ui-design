/**
 * MirrorAreaChart — two readings of one timeline, one above a baseline and one
 * below it.
 *
 * ```tsx
 * <MirrorAreaChart data={load} xDataKey="time">
 *   <MirrorAreaChart.Grid />
 *   <MirrorAreaChart.Area dataKey="jobs" label="jobs" muted />
 *   <MirrorAreaChart.Area dataKey="high" label="high priority" />
 *   <MirrorAreaChart.Area dataKey="share" label="% high" side="bottom" />
 *   <MirrorAreaChart.Baseline />
 *   <MirrorAreaChart.Tooltip />
 * </MirrorAreaChart>
 * ```
 *
 * ## Two scales, one timeline
 *
 * Each half has its own scale, because the two readings are usually in
 * different units — a count above and a percentage below, or requests above
 * and errors below. Both grow away from the baseline, so a peak in one lines
 * up with whatever the other did at the same moment, and neither is squeezed
 * into the other's range.
 *
 * Areas on the same side overlay in the order they are declared. Declare the
 * whole first and the part of it second, so the part is drawn inside the whole.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type ChartAccessibilityProps } from '../../primitives/chart-accessibility.js';
import { type ChartCurve, type SeriesColorIndex } from '../../utils/chart.js';
type Layer = 'svg' | 'series' | 'overlay' | 'header';
export type MirrorAreaChartStatus = 'loading' | 'ready';
export type MirrorAreaChartSide = 'top' | 'bottom';
export type MirrorAreaChartDatum = Record<string, string | number | null | undefined>;
/** The row under the crosshair, for a header or a readout outside the chart. */
export declare function useMirrorAreaChart(): {
    activeIndex: number;
    activePoint: MirrorAreaChartDatum | null;
    xDataKey: string;
};
export interface MirrorAreaChartProps extends ViewProps, ChartAccessibilityProps<MirrorAreaChartDatum> {
    className?: string;
    /** The rows. Each one is a point along the x-axis. */
    data: MirrorAreaChartDatum[];
    /** Key holding the x label. Used by the axis and the readout. */
    xDataKey?: string;
    /**
     * How much of the plot's height sits above the baseline, from `0` to `1`.
     * Give the half you want read first the larger share.
     */
    split?: number;
    /**
     * Fix the top half's scale instead of deriving it from the data. Only the
     * upper end is used: the baseline is always zero.
     */
    topDomain?: [number, number];
    /** Fix the bottom half's scale. Only the upper end is used. */
    bottomDomain?: [number, number];
    /** `monotone` never overshoots between points; `linear` joins them straight. */
    curve?: ChartCurve;
    /**
     * `loading` holds the bands flat on the baseline and grows them out when it
     * turns `ready`. Add a `MirrorAreaChart.Skeleton` to show something meanwhile.
     */
    status?: MirrorAreaChartStatus;
    /** Width ÷ height. */
    aspectRatio?: number;
    /** Milliseconds for the bands to grow out on mount. */
    animationDuration?: number;
    /** Milliseconds for either scale to settle after the data changes. */
    domainDuration?: number;
    /**
     * The point under the crosshair as it moves, and `-1`/`null` when it lifts.
     * Fires when the index changes, not per frame.
     */
    onActiveIndexChange?: (index: number, datum: MirrorAreaChartDatum | null) => void;
    /** Drop the axis padding so the bands reach the edges, for a sparkline. */
    compact?: boolean;
    children?: ReactNode;
}
/** Imperative handle: re-run the reveal on demand, for a "replay" control. */
export interface MirrorAreaChartHandle {
    replay: () => void;
}
export interface MirrorAreaChartGridProps {
    /** `dots` is a field of points; `lines` is dashed rules across each half. */
    variant?: 'dots' | 'lines';
    /** Distance between dots, or how many rules each half gets. */
    spacing?: number;
    color?: string;
    opacity?: number;
}
/**
 * The texture behind the bands. Dots by default, which mark the plot's extent
 * without drawing lines that compete with the baseline.
 */
declare function MirrorAreaChartGrid({ variant, spacing, color, opacity }: MirrorAreaChartGridProps): import("react").JSX.Element;
declare namespace MirrorAreaChartGrid {
    var displayName: string;
    var layer: Layer;
}
export interface MirrorAreaChartBaselineProps {
    color?: string;
    strokeWidth?: number;
    opacity?: number;
}
/**
 * The line both halves grow away from. Declare it after the areas so it is
 * drawn over their bases.
 */
declare function MirrorAreaChartBaseline({ color, strokeWidth, opacity }: MirrorAreaChartBaselineProps): import("react").JSX.Element;
declare namespace MirrorAreaChartBaseline {
    var displayName: string;
    var layer: Layer;
}
export interface MirrorAreaChartAreaProps {
    /** Column in the data holding this series' values. */
    dataKey: string;
    /** Which half it is drawn in. */
    side?: MirrorAreaChartSide;
    /** The name shown by the readout and the legend. Defaults to `dataKey`. */
    label?: string;
    /** Explicit colour. Defaults to the `--color-chart-*` token for `colorIndex`. */
    color?: string;
    /** Which of the five chart tokens to take. */
    colorIndex?: SeriesColorIndex;
    /**
     * Draw it in the muted foreground colour instead, for a total that the
     * coloured areas are parts of.
     */
    muted?: boolean;
    /** Opacity of the fill at the band's outer edge. */
    fillOpacity?: number;
    /** Opacity of the fill at the baseline. Defaults to `fillOpacity`, a flat fill. */
    gradientToOpacity?: number;
    /** Draw the line along the band's outer edge. */
    showLine?: boolean;
    /** Thickness of that line. */
    strokeWidth?: number;
}
/**
 * One band, growing away from the baseline on its side. Areas on one side
 * overlay in declaration order, so a whole declared first is drawn behind a
 * part of it declared second.
 */
declare function MirrorAreaChartArea({ dataKey, side, label, color, colorIndex, muted, fillOpacity, gradientToOpacity, showLine, strokeWidth, }: MirrorAreaChartAreaProps): import("react").JSX.Element;
declare namespace MirrorAreaChartArea {
    var displayName: string;
    var layer: Layer;
    var area: true;
}
export interface MirrorAreaChartSkeletonProps {
    /** Milliseconds for one pass of the sweep. */
    duration?: number;
    color?: string;
}
/**
 * The loading state: a low band either side of the baseline with a highlight
 * travelling across it. Flat, so it says where the bands will be and nothing
 * about their shape.
 */
declare function MirrorAreaChartSkeleton({ duration, color }: MirrorAreaChartSkeletonProps): import("react").JSX.Element | null;
declare namespace MirrorAreaChartSkeleton {
    var displayName: string;
    var layer: Layer;
}
export interface MirrorAreaChartXAxisProps {
    ticks?: number;
    format?: (datum: MirrorAreaChartDatum, index: number) => string;
    className?: string;
}
/** The x labels. Real text, so they follow the theme's font and text scaling. */
declare function MirrorAreaChartXAxis({ ticks, format, className }: MirrorAreaChartXAxisProps): import("react").JSX.Element;
declare namespace MirrorAreaChartXAxis {
    var displayName: string;
    var layer: Layer;
}
export interface MirrorAreaChartYAxisProps {
    /** Format a value in the top half. */
    formatTop?: (value: number) => string;
    /** Format a value in the bottom half. */
    formatBottom?: (value: number) => string;
    className?: string;
}
/**
 * Three labels down the side: the top half's maximum, zero on the baseline,
 * and the bottom half's maximum. Two scales need two labels, and a column of
 * evenly spaced numbers would suggest one.
 */
declare function MirrorAreaChartYAxis({ formatTop, formatBottom, className }: MirrorAreaChartYAxisProps): import("react").JSX.Element;
declare namespace MirrorAreaChartYAxis {
    var displayName: string;
    var layer: Layer;
    var axis: "y";
}
export interface MirrorAreaChartTooltipProps {
    /** Colour of the crosshair and the dot. Defaults to the foreground token. */
    color?: string;
    /** Format one series' value. Defaults to a compact number. */
    formatValue?: (value: number, key: string) => string;
    /** Format the readout's heading from the row. Defaults to the value at xDataKey. */
    formatX?: (datum: MirrorAreaChartDatum) => string;
    /**
     * One line to show instead of a row per series — "1,120 jobs · 78% high".
     * Use it when the series only make sense read together.
     */
    formatSummary?: (datum: MirrorAreaChartDatum) => string;
    className?: string;
    /**
     * How long a press has to be held before the readout takes the touch, in
     * milliseconds.
     *
     * Until then the touch belongs to whatever else wants it: a quick tap still
     * reaches a button floating over the chart, and a swipe still scrolls the
     * screen the chart sits in. Set `0` to read on contact, only for a chart with
     * nothing over it and no scroll view around it.
     */
    activateAfterLongPress?: number;
}
/**
 * A dashed crosshair, a dot on the outer edge of the top half, and a readout
 * beside them. The hit area is the whole plot.
 */
declare function MirrorAreaChartTooltip({ color, formatValue, formatX, formatSummary, className, activateAfterLongPress, }: MirrorAreaChartTooltipProps): import("react").JSX.Element | null;
declare namespace MirrorAreaChartTooltip {
    var displayName: string;
    var layer: Layer;
}
export interface MirrorAreaChartLegendProps extends ViewProps {
    className?: string;
}
/** A swatch and a name per area, top half first. */
declare function MirrorAreaChartLegend({ className, ...props }: MirrorAreaChartLegendProps): import("react").JSX.Element | null;
declare namespace MirrorAreaChartLegend {
    var displayName: string;
    var layer: Layer;
}
export interface MirrorAreaChartHeaderProps extends ViewProps {
    className?: string;
    /** Small line above the value — what the chart is of. */
    title?: string;
    /** The readout. The largest thing on the card, and the first thing read. */
    value?: string;
    /** One muted line under the value — a period, a comparison, a total. */
    caption?: string;
    /** Draw a swatch and a name per area along the trailing edge. */
    legend?: boolean;
    /** Trailing slot — a control, a badge, a range picker. Wins over `legend`. */
    children?: ReactNode;
}
/**
 * The strip above the plot: what the chart is of and what it currently reads.
 * The value is not derived here — pass the formatted string, from
 * `onActiveIndexChange` if it follows the finger.
 */
declare function MirrorAreaChartHeader({ className, title, value, caption, legend, children, ...props }: MirrorAreaChartHeaderProps): import("react").JSX.Element;
declare namespace MirrorAreaChartHeader {
    var displayName: string;
    var layer: Layer;
}
export declare const MirrorAreaChart: import("react").ForwardRefExoticComponent<MirrorAreaChartProps & import("react").RefAttributes<MirrorAreaChartHandle>> & {
    Header: typeof MirrorAreaChartHeader;
    Grid: typeof MirrorAreaChartGrid;
    Area: typeof MirrorAreaChartArea;
    Baseline: typeof MirrorAreaChartBaseline;
    Skeleton: typeof MirrorAreaChartSkeleton;
    XAxis: typeof MirrorAreaChartXAxis;
    YAxis: typeof MirrorAreaChartYAxis;
    Tooltip: typeof MirrorAreaChartTooltip;
    Legend: typeof MirrorAreaChartLegend;
};
export {};
//# sourceMappingURL=index.d.ts.map