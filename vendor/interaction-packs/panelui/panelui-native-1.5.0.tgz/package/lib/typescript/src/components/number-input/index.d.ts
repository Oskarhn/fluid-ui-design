import { type TextInputProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { TextInputRef } from '../../primitives/refs.js';
declare const numberInputVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        outline: {
            control: string;
        };
        filled: {
            control: string;
        };
    };
    size: {
        sm: {
            control: string;
            button: string;
        };
        md: {
            control: string;
            button: string;
        };
        lg: {
            control: string;
            button: string;
        };
    };
    invalid: {
        true: {
            control: string;
        };
    };
    disabled: {
        true: {
            container: string;
        };
    };
}, {
    container: string;
    control: string;
    button: string;
    field: string;
    description: string;
    error: string;
}, undefined, {
    variant: {
        outline: {
            control: string;
        };
        filled: {
            control: string;
        };
    };
    size: {
        sm: {
            control: string;
            button: string;
        };
        md: {
            control: string;
            button: string;
        };
        lg: {
            control: string;
            button: string;
        };
    };
    invalid: {
        true: {
            control: string;
        };
    };
    disabled: {
        true: {
            container: string;
        };
    };
}, {
    container: string;
    control: string;
    button: string;
    field: string;
    description: string;
    error: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        outline: {
            control: string;
        };
        filled: {
            control: string;
        };
    };
    size: {
        sm: {
            control: string;
            button: string;
        };
        md: {
            control: string;
            button: string;
        };
        lg: {
            control: string;
            button: string;
        };
    };
    invalid: {
        true: {
            control: string;
        };
    };
    disabled: {
        true: {
            container: string;
        };
    };
}, {
    container: string;
    control: string;
    button: string;
    field: string;
    description: string;
    error: string;
}>>;
type NumberInputVariantProps = VariantProps<typeof numberInputVariants>;
export interface NumberInputProps extends Omit<NumberInputVariantProps, 'invalid' | 'disabled'>, Pick<TextInputProps, 'onFocus' | 'onBlur' | 'placeholder' | 'returnKeyType'> {
    className?: string;
    containerClassName?: string;
    /** Controlled value. Leave unset and pass `defaultValue` to run uncontrolled. */
    value?: number;
    /** Starting value when uncontrolled. Defaults to `min`, or 0. */
    defaultValue?: number;
    /** Lower bound. The decrement button disables here. */
    min?: number;
    /** Upper bound. The increment button disables here. */
    max?: number;
    /** Nudge per press, and the granularity the value snaps to. */
    step?: number;
    /** Fires whenever the committed value changes. */
    onValueChange?: (value: number) => void;
    /**
     * Format the displayed number — units, currency, grouping. The field shows
     * this string; typing still reads a bare number back. Defaults to the value
     * rounded to `step`'s precision.
     */
    formatValue?: (value: number) => string;
    /** Let the middle field be typed into. When false it is display-only. */
    editable?: boolean;
    disabled?: boolean;
    /** A label above the control. Doubles as the accessibility label. */
    label?: string;
    /** Helper text below the control. Hidden while an error shows. */
    description?: string;
    /** Error message. When set, the control renders in its invalid state. */
    errorMessage?: string;
    /** Marks the field required — an asterisk on the label, and the a11y state. */
    isRequired?: boolean;
    /**
     * Tick the haptic engine on each step. Needs the optional `expo-haptics`,
     * and is silent without it.
     */
    haptics?: boolean;
}
/**
 * A number stepped by buttons or typed by hand, reconciled to one clamped,
 * step-snapped value. See the file header for why it keeps both affordances.
 */
export declare const NumberInput: import("react").ForwardRefExoticComponent<NumberInputProps & import("react").RefAttributes<TextInputRef>>;
export {};
//# sourceMappingURL=index.d.ts.map