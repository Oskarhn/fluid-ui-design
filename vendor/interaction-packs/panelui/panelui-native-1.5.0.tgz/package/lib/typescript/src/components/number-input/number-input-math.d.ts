/** Decimals implied by `step`, including numbers written with an exponent. */
export declare function precisionOf(step: number): number;
export declare function clamp(value: number, min: number, max: number): number;
/**
 * Snaps to the nearest step from a finite base, then clears binary drift at
 * the step's decimal precision.
 */
export declare function normalize(value: number, min: number, max: number, step: number): number;
//# sourceMappingURL=number-input-math.d.ts.map