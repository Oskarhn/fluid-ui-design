import { type TextInputProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { TextInputRef } from '../../primitives/refs.js';
declare const otpVariants: import("tailwind-variants").TVReturnType<{
    size: {
        sm: {
            cell: string;
            char: string;
            caret: string;
            separator: string;
        };
        md: {
            cell: string;
            char: string;
            caret: string;
            separator: string;
        };
        lg: {
            cell: string;
            char: string;
            caret: string;
            separator: string;
        };
    };
    disabled: {
        true: {
            row: string;
        };
    };
}, {
    container: string;
    row: string;
    cell: string;
    char: string;
    caret: string;
    separator: string;
    error: string;
}, undefined, {
    size: {
        sm: {
            cell: string;
            char: string;
            caret: string;
            separator: string;
        };
        md: {
            cell: string;
            char: string;
            caret: string;
            separator: string;
        };
        lg: {
            cell: string;
            char: string;
            caret: string;
            separator: string;
        };
    };
    disabled: {
        true: {
            row: string;
        };
    };
}, {
    container: string;
    row: string;
    cell: string;
    char: string;
    caret: string;
    separator: string;
    error: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        sm: {
            cell: string;
            char: string;
            caret: string;
            separator: string;
        };
        md: {
            cell: string;
            char: string;
            caret: string;
            separator: string;
        };
        lg: {
            cell: string;
            char: string;
            caret: string;
            separator: string;
        };
    };
    disabled: {
        true: {
            row: string;
        };
    };
}, {
    container: string;
    row: string;
    cell: string;
    char: string;
    caret: string;
    separator: string;
    error: string;
}>>;
type OtpVariantProps = VariantProps<typeof otpVariants>;
export interface OtpInputProps extends Omit<TextInputProps, 'value' | 'defaultValue' | 'onChangeText' | 'maxLength' | 'children'>, Omit<OtpVariantProps, 'disabled'> {
    className?: string;
    /** Class applied to every cell — for a taller box or a different radius. */
    cellClassName?: string;
    /** How many cells, i.e. the length of the code. */
    length?: number;
    /** Controlled value. Longer strings and stray characters are trimmed to fit. */
    value?: string;
    /** Starting value when the field manages its own state. */
    defaultValue?: string;
    onChangeText?: (value: string) => void;
    /** Fires once, the moment the last cell is filled. */
    onComplete?: (value: string) => void;
    /**
     * What the keyboard offers and what the field accepts. `numeric` keeps
     * digits only and asks for the number pad; `text` accepts any character.
     */
    type?: 'numeric' | 'text';
    /** Hide each filled character behind a dot, the way a passcode field does. */
    mask?: boolean;
    /** A single character shown, dimmed, in every cell still waiting for input. */
    placeholder?: string;
    /** Draw a separator between groups of this many cells — 3 gives `xxx — xxx`. */
    groupEvery?: number;
    disabled?: boolean;
    /** Tint the field in its error colour and announce it as invalid. */
    isInvalid?: boolean;
    /** Error line under the field. Setting it also puts the field in its invalid state. */
    errorMessage?: string;
    /** Announced by a screen reader as the field's name. */
    accessibilityLabel?: string;
}
export declare const OtpInput: import("react").ForwardRefExoticComponent<OtpInputProps & import("react").RefAttributes<TextInputRef>>;
export {};
//# sourceMappingURL=index.d.ts.map