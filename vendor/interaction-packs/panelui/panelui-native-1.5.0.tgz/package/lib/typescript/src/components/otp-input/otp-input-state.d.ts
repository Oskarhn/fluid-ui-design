/** Resolve the native editing state without allowing `disabled` to be bypassed. */
export declare function resolveOtpEditable(editable: boolean | undefined, disabled: boolean | undefined): boolean;
//# sourceMappingURL=otp-input-state.d.ts.map