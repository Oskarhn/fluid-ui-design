/**
 * Pagination — moving through a result set one page at a time.
 *
 * The component owns the arithmetic and nothing else. Give it how many pages
 * there are and which one you are on, and it works out which numbers to show,
 * where the gaps fall, and which controls are dead at the ends; it never fetches
 * and never slices, because the data is yours.
 *
 * ```tsx
 * <Pagination count={12} page={page} onPageChange={setPage} />
 * ```
 *
 * Three presentations, because a phone is not a desktop:
 *
 * - `numbers` — the full run, with the middle folded into ellipses. Fits about
 *   seven targets across a phone, which is what `siblings` and `boundaries`
 *   are tuned for.
 * - `compact` — the two arrows with `3 / 12` between them. Digits and a slash,
 *   so there is no sentence to translate.
 * - `simple` — labelled Previous and Next, for a flow you walk rather than
 *   jump around in: a wizard, an article, a set of onboarding cards.
 *
 * Every target is at least 44pt in both axes, and the small size keeps that
 * reach with `hitSlop` rather than by growing — the row gets denser, the
 * fingers do not get smaller.
 *
 * An ellipsis is a button, not punctuation. A dead 44pt target in the middle of
 * a row of live ones is a thing people tap and then think is broken, so tapping
 * one jumps `pageJump` pages that way.
 *
 * Given children, the root becomes a row with them on the leading edge and the
 * controls on the trailing one — which is where `Pagination.Status` goes:
 *
 * ```tsx
 * <Pagination count={12} page={page} onPageChange={setPage} variant="compact">
 *   <Pagination.Status page={page} pageSize={20} total={240} />
 * </Pagination>
 * ```
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type AnimatedPressableProps } from '../../primitives/animated-pressable.js';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
export type PaginationVariant = 'numbers' | 'compact' | 'simple';
export type PaginationSize = 'sm' | 'default';
declare const paginationVariants: import("tailwind-variants").TVReturnType<{
    size: {
        default: {
            list: string;
            item: string;
            itemLabel: string;
            ellipsis: string;
            status: string;
            summary: string;
        };
        sm: {
            list: string;
            item: string;
            itemLabel: string;
            ellipsis: string;
            status: string;
            summary: string;
        };
    };
    /** Whether the item is the page you are on. */
    current: {
        true: {
            item: string;
            itemLabel: string;
        };
        false: {
            itemLabel: string;
        };
    };
    disabled: {
        true: {
            item: string;
        };
    };
}, {
    root: string;
    list: string;
    item: string;
    itemLabel: string;
    ellipsis: string;
    status: string;
    summary: string;
}, undefined, {
    size: {
        default: {
            list: string;
            item: string;
            itemLabel: string;
            ellipsis: string;
            status: string;
            summary: string;
        };
        sm: {
            list: string;
            item: string;
            itemLabel: string;
            ellipsis: string;
            status: string;
            summary: string;
        };
    };
    /** Whether the item is the page you are on. */
    current: {
        true: {
            item: string;
            itemLabel: string;
        };
        false: {
            itemLabel: string;
        };
    };
    disabled: {
        true: {
            item: string;
        };
    };
}, {
    root: string;
    list: string;
    item: string;
    itemLabel: string;
    ellipsis: string;
    status: string;
    summary: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        default: {
            list: string;
            item: string;
            itemLabel: string;
            ellipsis: string;
            status: string;
            summary: string;
        };
        sm: {
            list: string;
            item: string;
            itemLabel: string;
            ellipsis: string;
            status: string;
            summary: string;
        };
    };
    /** Whether the item is the page you are on. */
    current: {
        true: {
            item: string;
            itemLabel: string;
        };
        false: {
            itemLabel: string;
        };
    };
    disabled: {
        true: {
            item: string;
        };
    };
}, {
    root: string;
    list: string;
    item: string;
    itemLabel: string;
    ellipsis: string;
    status: string;
    summary: string;
}>>;
export type PaginationItemValue = number | 'start-ellipsis' | 'end-ellipsis';
/**
 * Which numbers to draw, and where the gaps go.
 *
 * The run is a fixed width rather than a sliding window: the same number of
 * targets whichever page you are on, so the row does not reflow under the
 * finger as you step through it and the arrow you were aiming at stays put.
 * `boundaries` pins the ends, `siblings` pads the middle, and a gap of exactly
 * one page is drawn as that page instead of an ellipsis — a `…` that hides a
 * single number is longer than the number.
 *
 * Exported because a caller sometimes needs the same run for a control of their
 * own, and two implementations of this would drift.
 */
export declare function paginationRange({ count, page, siblings, boundaries, }: {
    count: number;
    page: number;
    siblings?: number;
    boundaries?: number;
}): PaginationItemValue[];
export interface PaginationProps extends Omit<ViewProps, 'children'>, VariantProps<typeof paginationVariants> {
    className?: string;
    /**
     * How many pages there are. Pages are numbered from 1, so this is also the
     * last page's number.
     */
    count: number;
    /** The page being shown. Pass it to control the component. */
    page?: number;
    /** The page to start on when the component keeps its own. Defaults to 1. */
    defaultPage?: number;
    /** Called with the page that was asked for, already clamped to `count`. */
    onPageChange?: (page: number) => void;
    /** Which presentation to draw. */
    variant?: PaginationVariant;
    size?: PaginationSize;
    /**
     * How many pages to keep either side of the current one. Raise it on a
     * tablet, where there is room for a longer run.
     */
    siblings?: number;
    /** How many pages to keep pinned at each end of the run. */
    boundaries?: number;
    /**
     * Show the previous and next arrows. Turning them off leaves the numbers
     * alone, so only do it where something else moves the page — a swipe, a
     * scroller reaching its end.
     */
    controls?: boolean;
    /** How far tapping an ellipsis jumps. */
    pageJump?: number;
    /** Greys out and deafens the whole row — for a page that is still loading. */
    disabled?: boolean;
    /** Labels the row for a screen reader. Defaults to "Pagination". */
    accessibilityLabel?: string;
    /** Leading content — a `Pagination.Status`, a page-size control of your own. */
    children?: ReactNode;
}
export interface PaginationItemProps extends Omit<AnimatedPressableProps, 'children' | 'disabled'> {
    className?: string;
    /** The page this target goes to. */
    page: number;
    /** Styles the number. */
    labelClassName?: string;
    children?: ReactNode;
}
export interface PaginationPreviousProps extends Omit<AnimatedPressableProps, 'children'> {
    className?: string;
    /** Write the word beside the arrow, rather than leaving it as a glyph. */
    label?: boolean;
}
export interface PaginationNextProps extends Omit<AnimatedPressableProps, 'children'> {
    className?: string;
    /** Write the word beside the arrow, rather than leaving it as a glyph. */
    label?: boolean;
}
export interface PaginationEllipsisProps extends Omit<AnimatedPressableProps, 'children'> {
    className?: string;
    /** Which way the gap runs: `-1` towards page 1, `1` towards the last page. */
    direction?: -1 | 1;
    /** How many pages a tap covers. */
    jump?: number;
}
export interface PaginationSummaryProps extends TextProps {
    className?: string;
}
export interface PaginationStatusProps extends TextProps {
    className?: string;
    /** Which page the span is counted from. Read from the root when left out. */
    page?: number;
    /** How many rows a page holds. Required for the span to be worked out. */
    pageSize?: number;
    /** How many rows there are altogether. */
    total?: number;
    children?: ReactNode;
}
export declare const Pagination: import("react").ForwardRefExoticComponent<PaginationProps & import("react").RefAttributes<ViewRef>> & {
    Item: import("react").ForwardRefExoticComponent<PaginationItemProps & import("react").RefAttributes<ViewRef>>;
    Previous: {
        ({ ...props }: PaginationPreviousProps): import("react").JSX.Element;
        displayName: string;
    };
    Next: {
        ({ ...props }: PaginationNextProps): import("react").JSX.Element;
        displayName: string;
    };
    Ellipsis: import("react").ForwardRefExoticComponent<PaginationEllipsisProps & import("react").RefAttributes<ViewRef>>;
    Summary: import("react").ForwardRefExoticComponent<PaginationSummaryProps & import("react").RefAttributes<TextRef>>;
    Status: import("react").ForwardRefExoticComponent<PaginationStatusProps & import("react").RefAttributes<TextRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map