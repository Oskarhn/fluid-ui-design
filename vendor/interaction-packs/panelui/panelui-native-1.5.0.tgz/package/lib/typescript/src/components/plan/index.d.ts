/**
 * Plan — what an agent intends to do, before it does it.
 *
 * A card rather than a run of rows, because a plan is a thing the reader is
 * being asked to approve: it needs an edge around it so that where it starts
 * and stops is not a matter of interpretation, and a footer that can hold the
 * button that approves it.
 *
 * The body is a rail of steps rather than prose, because a plan is an ordered
 * list of things that will happen and the reader's question is always *which
 * one is running*. A paragraph describing the same four steps cannot be glanced
 * at to answer that; a column of markers can. The rail fills behind the steps
 * that are done, so progress is legible from its left edge alone, and
 * `Plan.Steps` counts itself so `Plan.Progress` can say `2 of 4` up in the
 * header without the total being stated twice.
 *
 * It streams. `isStreaming` puts a shimmer on the title, the description and
 * the one step that is running, which is the honest way to render text that is
 * still arriving — the alternative is a title that grows a word at a time and
 * reads as finished at every intermediate length.
 *
 * ```tsx
 * <Plan isStreaming={streaming}>
 *   <Plan.Header>
 *     <Plan.Icon><FileIcon size={16} /></Plan.Icon>
 *     <Plan.Title>Migrate the calendar</Plan.Title>
 *     <Plan.Description>Four files, no API change.</Plan.Description>
 *     <Plan.Action>
 *       <Plan.Progress />
 *       <Plan.Trigger />
 *     </Plan.Action>
 *   </Plan.Header>
 *   <Plan.Content>
 *     <Plan.Steps>
 *       <Plan.Step status="done" meta="utils/date.ts">Read the date utils</Plan.Step>
 *       <Plan.Step status="active">Replace the month grid</Plan.Step>
 *       <Plan.Step>Update the docs page</Plan.Step>
 *     </Plan.Steps>
 *   </Plan.Content>
 *   <Plan.Footer>
 *     <Button variant="outline">Revise</Button>
 *     <Button>Approve</Button>
 *   </Plan.Footer>
 * </Plan>
 * ```
 *
 * ## Where the props come from
 *
 * With the AI SDK a plan is usually an `experimental_useObject` stream, where
 * `isStreaming` is the hook's `isLoading` and the fields arrive one at a time —
 * which is exactly the case the shimmer exists for, since a partial object has
 * a title before it has anything else.
 */
import { type ReactNode } from 'react';
import { type PressableProps, type ViewProps } from 'react-native';
import { type TextProps } from '../../primitives/text.js';
export type PlanStepStatus = 'pending' | 'active' | 'done' | 'skipped';
/** How far down the rail the plan has got. Reported by `Plan.Steps`. */
export interface PlanStepCounts {
    done: number;
    total: number;
}
export interface PlanProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** Whether the plan is still being written. Shimmers the title and description. */
    isStreaming?: boolean;
    /** Controlled open state of the body. */
    open?: boolean;
    /** Initial state when uncontrolled. */
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    children?: ReactNode;
}
declare function PlanRoot({ className, isStreaming, open: openProp, defaultOpen, onOpenChange, children, ...props }: PlanProps): import("react").JSX.Element;
declare namespace PlanRoot {
    var displayName: string;
}
export interface PlanHeaderProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/**
 * The title, the description and whatever acts on them.
 *
 * The heading is wrapped in a column of its own so the action stays pinned to
 * the trailing edge as the title wraps, rather than riding down with it. An
 * icon is pulled out to the leading edge for the same reason, in the other
 * direction — a badge that rode down with a wrapping title would stop reading
 * as a badge for the plan.
 */
declare function PlanHeader({ className, children, ...props }: PlanHeaderProps): import("react").JSX.Element;
declare namespace PlanHeader {
    var displayName: string;
}
export interface PlanIconProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/** A badge on the header's leading edge — what kind of plan this is. */
declare function PlanIcon({ className, children, ...props }: PlanIconProps): import("react").JSX.Element;
declare namespace PlanIcon {
    var displayName: string;
}
export interface PlanTitleProps extends TextProps {
    className?: string;
    children?: ReactNode;
}
/** The plan's name. Shimmers while it is still being written. */
declare function PlanTitle({ className, children, ...props }: PlanTitleProps): import("react").JSX.Element;
declare namespace PlanTitle {
    var displayName: string;
}
export interface PlanDescriptionProps extends TextProps {
    className?: string;
    children?: ReactNode;
}
declare function PlanDescription({ className, children, ...props }: PlanDescriptionProps): import("react").JSX.Element;
declare namespace PlanDescription {
    var displayName: string;
}
export interface PlanActionProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/** Pinned to the header's trailing edge — the toggle, a badge, a menu. */
declare function PlanAction({ className, children, ...props }: PlanActionProps): import("react").JSX.Element;
declare namespace PlanAction {
    var displayName: string;
}
export interface PlanTriggerProps extends Omit<PressableProps, 'children' | 'style'> {
    className?: string;
    children?: ReactNode;
}
/** Folds the body away. Its chevron turns to point at the state it will reach. */
declare function PlanTrigger({ className, children, onPress, ...props }: PlanTriggerProps): import("react").JSX.Element;
declare namespace PlanTrigger {
    var displayName: string;
}
export interface PlanContentProps extends Omit<ViewProps, 'children'> {
    className?: string;
    children?: ReactNode;
}
/** The steps. Collapses rather than unmounting, so it can still be growing. */
declare function PlanContent({ className, children, ...props }: PlanContentProps): import("react").JSX.Element;
declare namespace PlanContent {
    var displayName: string;
}
export interface PlanStepsProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
/**
 * The rail. A plan is an ordered list of things that will happen, and this is
 * the list — a paragraph describing the same four steps cannot be glanced at to
 * see which one is running.
 *
 * It counts its own steps and reports the count up, which is what lets
 * `Plan.Progress` sit in the header without the caller stating the total twice.
 */
declare function PlanSteps({ className, children, ...props }: PlanStepsProps): import("react").JSX.Element;
declare namespace PlanSteps {
    var displayName: string;
}
export interface PlanStepProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** How far this step has got. Decides the marker, the title and the rail below it. */
    status?: PlanStepStatus;
    /** A line under the title — what the step will touch, or what it found. */
    description?: ReactNode;
    /** A file path, a count, a duration. Rendered as a small mono chip. */
    meta?: ReactNode;
    /** Drop the connector below this step. `Plan.Steps` sets it for you. */
    last?: boolean;
    children?: ReactNode;
}
/**
 * One step. The marker says which of the four states it is in and the rail
 * below it is filled once it is done, so the plan's progress is legible from
 * the shape of the left-hand column alone.
 */
declare function PlanStep({ className, status, description, meta, last, children, ...props }: PlanStepProps): import("react").JSX.Element;
declare namespace PlanStep {
    var displayName: string;
}
export interface PlanProgressProps extends TextProps {
    className?: string;
    /** Steps settled so far. Defaults to what `Plan.Steps` counted. */
    value?: number;
    /** Steps in total. Defaults to what `Plan.Steps` counted. */
    total?: number;
}
/**
 * How far down the rail the plan has got, as `2 of 4`. Renders nothing until
 * there is a rail to count — a plan with no steps has no progress to report,
 * and `0 of 0` is worse than silence.
 */
declare function PlanProgress({ className, value, total, ...props }: PlanProgressProps): import("react").JSX.Element | null;
declare namespace PlanProgress {
    var displayName: string;
}
export interface PlanFooterProps extends ViewProps {
    className?: string;
    /**
     * How the actions divide the row. `stretch` splits it between them, which is
     * what a phone wants: the decision is the point of the card, and the two
     * buttons that make it should be the width of a thumb. `end` packs them
     * against the trailing edge for a plan sitting inside something denser.
     */
    layout?: 'stretch' | 'end';
    children?: ReactNode;
}
/**
 * Where the buttons that answer the plan go.
 *
 * Each action takes an equal share of the row by default. A pair of small
 * buttons hugging the trailing corner is a pointer-and-cursor shape; on a phone
 * the answer to "shall I do this" is the most important control on the screen
 * and wants to be hit without aiming.
 */
declare function PlanFooter({ className, layout, children, ...props }: PlanFooterProps): import("react").JSX.Element;
declare namespace PlanFooter {
    var displayName: string;
}
export declare const Plan: typeof PlanRoot & {
    Header: typeof PlanHeader;
    Icon: typeof PlanIcon;
    Title: typeof PlanTitle;
    Description: typeof PlanDescription;
    Action: typeof PlanAction;
    Progress: typeof PlanProgress;
    Trigger: typeof PlanTrigger;
    Content: typeof PlanContent;
    Steps: typeof PlanSteps;
    Step: typeof PlanStep;
    Footer: typeof PlanFooter;
};
export {};
//# sourceMappingURL=index.d.ts.map