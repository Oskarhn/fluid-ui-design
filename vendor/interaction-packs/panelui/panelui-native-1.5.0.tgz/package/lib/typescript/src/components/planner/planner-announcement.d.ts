interface PlannerMonthAnnouncementOptions {
    /** The settled month currently visible in the grid. */
    monthKey: number;
    monthLabel: string;
    announce: (label: string) => void;
}
/**
 * Announces a month only when the next committed render accepts a user request.
 *
 * Prop-driven months stay silent. In a controlled planner, a render that keeps
 * the previous month rejects the pending request and clears it without speaking.
 */
export declare function usePlannerMonthAnnouncement({ monthKey, monthLabel, announce, }: PlannerMonthAnnouncementOptions): (month: Date) => void;
export {};
//# sourceMappingURL=planner-announcement.d.ts.map