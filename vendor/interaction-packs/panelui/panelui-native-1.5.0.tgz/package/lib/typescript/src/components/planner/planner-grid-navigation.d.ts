export type PlannerGridNavigationKey = 'ArrowLeft' | 'ArrowRight' | 'ArrowUp' | 'ArrowDown' | 'Home' | 'End';
/**
 * Whether a cell can take focus. Some looks leave the days either side of the
 * month blank, and a blank has nothing to focus — so the caller says which
 * indices are real and movement steps over the rest.
 */
export type PlannerGridNavigable = (index: number) => boolean;
/** Returns the next visible cell for a bounded, row-major month grid. */
export declare function plannerGridTarget(key: string, index: number, count: number, columns?: number, navigable?: PlannerGridNavigable): number | null;
//# sourceMappingURL=planner-grid-navigation.d.ts.map