interface PlannerMonthLifecycleOptions {
    month: Date | undefined;
    defaultMonth: Date | undefined;
    settleMonth: (month: Date) => Date;
    onMonthChange: ((month: Date) => void) | undefined;
}
/** Keeps controlled requests separate from the month a parent has accepted. */
export declare function usePlannerMonthLifecycle({ month: monthProp, defaultMonth, settleMonth, onMonthChange, }: PlannerMonthLifecycleOptions): readonly [Date, (month: Date) => void];
interface PlannerSelectionLifecycleOptions {
    selected: Date | null | undefined;
    defaultSelected: Date | null;
    onSelectedChange: ((date: Date | null) => void) | undefined;
}
/** Commits locally only when selection is uncontrolled, but always reports a request. */
export declare function usePlannerSelectionLifecycle({ selected: selectedProp, defaultSelected, onSelectedChange, }: PlannerSelectionLifecycleOptions): readonly [
    Date | null,
    (date: Date | null) => void
];
export {};
//# sourceMappingURL=planner-lifecycle.d.ts.map