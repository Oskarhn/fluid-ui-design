export declare function millisecondsUntilNextLocalDay(now: Date): number;
//# sourceMappingURL=planner-today.d.ts.map