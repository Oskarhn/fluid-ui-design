export interface PlotSeriesRegistration {
    key: string;
    colors: readonly string[];
}
export declare function registerPlotSeries(current: readonly PlotSeriesRegistration[], key: string, color: string): PlotSeriesRegistration[];
export declare function unregisterPlotSeries(current: readonly PlotSeriesRegistration[], key: string, color?: string): PlotSeriesRegistration[];
export declare function visiblePlotSeries(registrations: readonly PlotSeriesRegistration[]): [string, string][];
//# sourceMappingURL=plot-series-registry.d.ts.map