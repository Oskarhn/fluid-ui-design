/**
 * PolarAreaChart — several parts, compared on one measure.
 *
 * ```tsx
 * <PolarAreaChart data={scores}>
 *   <PolarAreaChart.Header title="Scores" />
 *   <PolarAreaChart.Grid />
 *   <PolarAreaChart.Wedges />
 *   <PolarAreaChart.Labels />
 *   <PolarAreaChart.Legend />
 * </PolarAreaChart>
 * ```
 *
 * ## What it is, against the pie beside it
 *
 * A pie divides one total: the angles are the quantity and they must come to a
 * full turn, so a slice only means anything next to the others. Here every
 * wedge takes the same angle and the *radius* is the quantity, which means the
 * values do not have to add up to anything. Six unrelated readings on one scale
 * are a polar area chart; six parts of one budget are a pie.
 *
 * What it buys over a bar chart is the shape. Bars are easier to read one at a
 * time, and a reader who has to rank the middle three should be given bars. A
 * dial is for the silhouette — which direction the weight sits in, whether one
 * reading runs away from the rest — read at a glance and without a legend walk.
 *
 * ## Radius, and what it overstates
 *
 * `scale` decides what the radius means, and the two answers are not the same
 * chart:
 *
 * - `radius` (the default) puts the value straight on the radius, so a reading
 *   can be counted off the rings. The cost is that a wedge worth twice another
 *   covers four times the area, and area is what the eye adds up first.
 * - `area` puts it on the square root instead, so the ink is proportional to
 *   the value and nothing is overstated. The cost is the rings: they still mark
 *   equal steps, but they are no longer equally spaced.
 *
 * The grid is drawn through the same conversion either way, so a ring is always
 * where its value falls rather than where an even split would put it.
 *
 * Touch, not hover: a wedge is selected by pressing it, and pressing the same
 * one again clears the selection.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
/** Whether the chart is showing data or waiting for it. */
export type PolarAreaChartStatus = 'loading' | 'ready';
/** What a wedge's radius stands for. */
export type PolarAreaScale = 'radius' | 'area';
/** One wedge. Its angle is fixed, so only the value decides how far it reaches. */
export interface PolarAreaDatum {
    /** Name for the legend, the readout and the accessibility label. */
    label: string;
    /** How far the wedge reaches, against `maxValue`. Negatives are treated as zero. */
    value: number;
    /** Explicit colour, overriding the `--color-chart-*` token. */
    color?: string;
}
/** The selected wedge and its reading, for something rendered inside the chart. */
export declare function usePolarAreaChart(): {
    activeIndex: number;
    activeWedge: PolarAreaDatum | null;
    /** The selected wedge's value against the maximum, 0 to 1. */
    activeFraction: number;
};
export interface PolarAreaChartProps extends ViewProps {
    className?: string;
    /** One entry per wedge, drawn in the order they are listed. */
    data: PolarAreaDatum[];
    /** Diameter in points. Left out, the chart fills its column as a square. */
    size?: number;
    /**
     * The value the outermost ring stands for. Defaults to the largest value
     * rounded up to a round number.
     *
     * Fix it to compare two dials against each other — the same reading has to be
     * the same distance out on both, and a maximum derived per chart makes the
     * largest wedge of each one reach the edge whatever it is worth.
     */
    maxValue?: number;
    /** Whether the radius or the area carries the value. */
    scale?: PolarAreaScale;
    /** Where the first wedge starts, in degrees clockwise from twelve o'clock. */
    startAngle?: number;
    /** Gap between wedges, in degrees. */
    padAngle?: number;
    /** `loading` draws the dial undivided, with nothing split up yet. */
    status?: PolarAreaChartStatus;
    /** Milliseconds for the wedges to grow out of the centre. */
    animationDuration?: number;
    /** The selected wedge, to drive the selection from outside. */
    activeIndex?: number;
    onActiveIndexChange?: (index: number) => void;
    children?: ReactNode;
}
export interface PolarAreaChartHandle {
    /** Play the growth again. */
    replay: () => void;
}
export interface PolarAreaChartWedgesProps {
    /** Rounds the four turns of each wedge, in points. */
    cornerRadius?: number;
    /** Opacity of the wedges that are not selected, once one is. */
    dimOpacity?: number;
}
/**
 * Every wedge, drawn in the order the data lists them.
 *
 * One part rather than one per datum: the wedges share a dial, a maximum and a
 * scale by definition, and a chart where one of them could be given a different
 * maximum would be a chart drawing a lie.
 */
declare function PolarAreaChartWedges({ cornerRadius, dimOpacity, }: PolarAreaChartWedgesProps): import("react").JSX.Element | null;
declare namespace PolarAreaChartWedges {
    var displayName: string;
    var slot: "svg";
}
export interface PolarAreaChartGridProps {
    /** How many rings, including the outermost. */
    rings?: number;
    /** Overrides the themed hairline colour. */
    color?: string;
    /** Draw a line from the centre out along each wedge's edge. */
    spokes?: boolean;
}
/**
 * The scale, drawn as rings.
 *
 * Each ring stands for an even step of the value and is placed where that value
 * falls, which under `scale="area"` is not an even step of the radius. Spacing
 * them evenly instead would be quicker and would put every ring in the wrong
 * place on half the charts.
 */
declare function PolarAreaChartGrid({ rings, color, spokes }: PolarAreaChartGridProps): import("react").JSX.Element | null;
declare namespace PolarAreaChartGrid {
    var displayName: string;
    var slot: "svg";
}
export interface PolarAreaChartLabelsProps {
    /** Format the value. Defaults to a compact number. */
    formatValue?: (value: number, datum: PolarAreaDatum) => string;
    /** Wedges reaching less far than this, in points, are left unlabelled. */
    minRadius?: number;
    className?: string;
}
/**
 * The reading on each wedge that has room for it.
 *
 * A wedge shorter than `minRadius` is left blank — the label would sit outside
 * the wedge it belongs to, next to a neighbour it does not describe. Those are
 * read through `Tooltip` and the legend instead.
 *
 * Each label takes its colour from the wedge under it. A wedge is a theme
 * colour and a theme is free to set that anywhere on the scale, so a fixed
 * white label disappears on the pale ones.
 */
declare function PolarAreaChartLabels({ formatValue, minRadius, className, }: PolarAreaChartLabelsProps): import("react").JSX.Element | null;
declare namespace PolarAreaChartLabels {
    var displayName: string;
    var slot: "overlay";
}
export interface PolarAreaChartTooltipProps {
    /** Format the value. Defaults to a compact number. */
    formatValue?: (value: number, datum: PolarAreaDatum) => string;
    className?: string;
}
/**
 * The readout for the selected wedge, floating over the dial.
 *
 * This is how the short wedges are named. They are the ones with no room for a
 * label, so without it the chart answers questions about its largest readings
 * only — which is the half the reader could already see.
 */
declare function PolarAreaChartTooltip({ formatValue, className }: PolarAreaChartTooltipProps): import("react").JSX.Element | null;
declare namespace PolarAreaChartTooltip {
    var displayName: string;
    var slot: "overlay";
}
export interface PolarAreaChartLegendProps extends ViewProps {
    className?: string;
    /** Show each wedge's reading beside its name. */
    showValue?: boolean;
    /** Format the value. Defaults to a compact number. */
    formatValue?: (value: number, datum: PolarAreaDatum) => string;
}
/**
 * A swatch, a name and a reading per wedge, under the dial and across the width
 * of it. Pressable in the same way the wedges are, and the easier target of the
 * two for anything short.
 *
 * The reading rather than a share, unlike the pie next door: these values need
 * not add up to anything, so a percentage of their sum would be a number about
 * nothing.
 */
declare function PolarAreaChartLegend({ className, showValue, formatValue, ...props }: PolarAreaChartLegendProps): import("react").JSX.Element | null;
declare namespace PolarAreaChartLegend {
    var displayName: string;
    var slot: "footer";
}
export interface PolarAreaChartSkeletonProps {
    color?: string;
}
/**
 * The loading state: the dial as one plain disc, with nothing divided up yet.
 *
 * Deliberately undivided. Placeholder wedges would be a made-up set of
 * readings, and a reader has no way to tell an invented one from a real one
 * until it changes under them.
 */
declare function PolarAreaChartSkeleton({ color }: PolarAreaChartSkeletonProps): import("react").JSX.Element | null;
declare namespace PolarAreaChartSkeleton {
    var displayName: string;
    var slot: "svg";
}
export interface PolarAreaChartHeaderProps extends ViewProps {
    className?: string;
    /** Small line above the value — what the chart is of. */
    title?: string;
    /** The readout. The largest thing on the card, and the first thing read. */
    value?: string;
    /** One muted line under the value — a period, a comparison, a caveat. */
    caption?: string;
    /** Prettier names for the wedges, keyed by their `label`. */
    labels?: Record<string, string>;
    /**
     * Draw a swatch and a name per wedge along the trailing edge.
     *
     * For two or three short names. Past that use `PolarAreaChart.Legend`, which
     * runs under the dial across the full width.
     */
    legend?: boolean;
    /** Trailing slot — a control, a badge, a range picker. Wins over `legend`. */
    children?: ReactNode;
}
/**
 * The strip above the dial: what the chart is of, what it reads, and what the
 * colours mean.
 *
 * The value is not derived here even though there are values to derive one
 * from, because the formatting is not the chart's to guess: 18420 is a count, a
 * currency or a duration depending on what was measured.
 */
declare function PolarAreaChartHeader({ className, title, value, caption, labels, legend, children, ...props }: PolarAreaChartHeaderProps): import("react").JSX.Element;
declare namespace PolarAreaChartHeader {
    var displayName: string;
    var slot: "header";
}
export declare const PolarAreaChart: import("react").ForwardRefExoticComponent<PolarAreaChartProps & import("react").RefAttributes<PolarAreaChartHandle>> & {
    Header: typeof PolarAreaChartHeader;
    Grid: typeof PolarAreaChartGrid;
    Wedges: typeof PolarAreaChartWedges;
    Labels: typeof PolarAreaChartLabels;
    Tooltip: typeof PolarAreaChartTooltip;
    Legend: typeof PolarAreaChartLegend;
    Skeleton: typeof PolarAreaChartSkeleton;
};
export {};
//# sourceMappingURL=index.d.ts.map