import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
declare const progressVariants: import("tailwind-variants").TVReturnType<{
    color: {
        primary: {
            track: string;
            indicator: string;
        };
        success: {
            track: string;
            indicator: string;
        };
        warning: {
            track: string;
            indicator: string;
        };
        destructive: {
            track: string;
            indicator: string;
        };
        info: {
            track: string;
            indicator: string;
        };
    };
    size: {
        sm: {
            track: string;
        };
        md: {
            track: string;
        };
        lg: {
            track: string;
        };
    };
}, {
    root: string;
    header: string;
    track: string;
    indicator: string;
}, undefined, {
    color: {
        primary: {
            track: string;
            indicator: string;
        };
        success: {
            track: string;
            indicator: string;
        };
        warning: {
            track: string;
            indicator: string;
        };
        destructive: {
            track: string;
            indicator: string;
        };
        info: {
            track: string;
            indicator: string;
        };
    };
    size: {
        sm: {
            track: string;
        };
        md: {
            track: string;
        };
        lg: {
            track: string;
        };
    };
}, {
    root: string;
    header: string;
    track: string;
    indicator: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    color: {
        primary: {
            track: string;
            indicator: string;
        };
        success: {
            track: string;
            indicator: string;
        };
        warning: {
            track: string;
            indicator: string;
        };
        destructive: {
            track: string;
            indicator: string;
        };
        info: {
            track: string;
            indicator: string;
        };
    };
    size: {
        sm: {
            track: string;
        };
        md: {
            track: string;
        };
        lg: {
            track: string;
        };
    };
}, {
    root: string;
    header: string;
    track: string;
    indicator: string;
}>>;
type ProgressVariantProps = VariantProps<typeof progressVariants>;
export interface ProgressProps extends Omit<ViewProps, 'children'>, ProgressVariantProps {
    className?: string;
    /**
     * Where the work has got to, somewhere between `minValue` and `maxValue`.
     * Ignored when `indeterminate` is set.
     */
    value?: number;
    /**
     * The bottom of the range — the value at which the bar reads as empty.
     * Defaults to `0`.
     */
    minValue?: number;
    /**
     * The top of the range — the value at which the bar reads as full. Defaults
     * to `100`, so a bare percentage keeps working with neither bound set.
     */
    maxValue?: number;
    /**
     * Show a looping animation for unknown-duration work. Under the platform's
     * reduce-motion setting the bar fills the track and pulses instead of
     * travelling across it, so it still reads as running.
     */
    indeterminate?: boolean;
    /** Extra classes for the moving indicator. */
    indicatorClassName?: string;
    /**
     * Caption drawn above the track, on the left. Supplying it (or
     * `showValueLabel`) wraps the bar in a header row; the track alone renders
     * otherwise.
     */
    label?: string;
    /**
     * Draw the percentage above the track, on the right. Hidden while
     * `indeterminate` — there is nothing meaningful to show.
     */
    showValueLabel?: boolean;
    /**
     * Text for the value label. Overrides the formatted percentage — use it for
     * a byte count, a step tally, anything that is not a bare percent.
     */
    valueLabel?: string;
    /**
     * How to write the value, through `Intl.NumberFormat`. A `percent` style
     * formats how far along the bar is; every other style formats the value
     * itself, so `{ style: 'currency', currency: 'USD' }` against a `maxValue`
     * of `2000` reads `$1,250.00` rather than a percentage of it. Falls back to
     * a rounded percent when omitted.
     */
    formatOptions?: Intl.NumberFormatOptions;
    /** Extra classes for the label + value-label row. */
    headerClassName?: string;
}
/**
 * Determinate or indeterminate progress bar. The fill width (determinate) and
 * the sliding bar (indeterminate) are both driven on the UI thread, so updates
 * never re-render past the value change itself.
 *
 * Pass `label` or `showValueLabel` to caption the bar with a header row; the
 * bare track renders when neither is set, so existing call sites are untouched.
 *
 * The value is read against `minValue` / `maxValue`, which default to 0 and
 * 100 — so a percentage needs neither. Set them and the bar speaks in whatever
 * the work is actually counted in: bytes uploaded, seats filled, points
 * scored. Nothing has to be converted to a percent on the way in, and the
 * screen reader is told the real range rather than a derived one.
 *
 * Reduce motion is honoured in both modes: the fill lands on its value rather
 * than springing to it, and the indeterminate bar pulses in place rather than
 * crossing the track.
 */
export declare const Progress: import("react").ForwardRefExoticComponent<ProgressProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map