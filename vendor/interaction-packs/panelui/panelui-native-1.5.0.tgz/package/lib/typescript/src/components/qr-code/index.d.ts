/**
 * QRCode — a string, drawn as something a camera can read.
 *
 * ```tsx
 * <QRCode value="https://panelui.dev">
 *   <QRCode.Frame>
 *     <QRCode.Canvas />
 *   </QRCode.Frame>
 *   <QRCode.Caption>Scan to open the docs</QRCode.Caption>
 * </QRCode>
 * ```
 *
 * Composition is the API, as everywhere else here: a code in a titled panel is
 * one with a `QRCode.Header` in it, and a code behind a button is one wrapped
 * in a `QRCode.Trigger` and a `QRCode.Content` — not one with a prop turned on.
 *
 * ## What it draws
 *
 * Three `<Path>`s: the body, the three corner rings, and the three corner
 * centres. Every module is a subpath of one of them, not a `<Rect>` of its
 * own. A version 10 code is 3,481 modules; half of them dark is seventeen
 * hundred native views for a picture that never changes, and the difference
 * between that and three nodes is the difference between a code that appears
 * and one that appears eventually.
 *
 * Three rather than one because they are the three things worth colouring and
 * shaping separately. A code is found by its corner eyes before a single
 * module is read, so they are the part a design touches first — and the part
 * it is most dangerous to touch badly.
 *
 * The colours come from the theme, so a code drawn on a card is legible on
 * every one of them — and light-on-dark is drawn the way scanners expect it,
 * with the quiet zone painted rather than left transparent. A code with
 * nothing behind it reads at about half the distance.
 *
 * ## Shaping it
 *
 * `moduleShape`, `eyeFrameShape` and `eyeBallShape` on `QRCode.Canvas` change
 * the geometry; `color`, `eyeFrameColor`, `eyeBallColor` and `backgroundColor`
 * change the ink. A scanner samples the centre of each cell, so every shape
 * here reads exactly as a square does — what changes is how much of the cell
 * is covered. `dot` fills about two thirds of it and `diamond` half, which is
 * read distance spent on a look. Raise `errorCorrection` to pay for it, and
 * check a printed code rather than one on a screen.
 *
 * ## The hole in the middle
 *
 * `QRCode.Logo` clears a square of modules and puts its children there.
 * Error correction is what makes that survivable — the modules are gone, and
 * the code still reads because there is enough redundancy to reconstruct them.
 * How much is `errorCorrection`, and a logo raises the level it needs: the
 * default `M` tolerates about 15% loss, `H` about 30%. A logo is measured
 * against that budget and the level is raised for you if it has to be.
 */
import { type ReactElement, type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type PopoverContentProps } from '../popover/index.js';
import { type ErrorCorrectionLevel } from './qr-encode.js';
import { type QRCodeEyeBallShape, type QRCodeEyeFrameShape, type QRCodeModuleShape } from './qr-shapes.js';
import type { ViewRef } from '../../primitives/refs.js';
export type { ErrorCorrectionLevel };
export type { QRCodeModuleShape, QRCodeEyeFrameShape, QRCodeEyeBallShape };
declare const qrCodeVariants: import("tailwind-variants").TVReturnType<{
    size: {
        sm: {};
        md: {};
        lg: {};
    };
}, {
    root: string;
    frame: string;
    header: string;
    panel: string;
    caption: string;
    value: string;
}, undefined, {
    size: {
        sm: {};
        md: {};
        lg: {};
    };
}, {
    root: string;
    frame: string;
    header: string;
    panel: string;
    caption: string;
    value: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        sm: {};
        md: {};
        lg: {};
    };
}, {
    root: string;
    frame: string;
    header: string;
    panel: string;
    caption: string;
    value: string;
}>>;
type QrCodeVariantProps = VariantProps<typeof qrCodeVariants>;
/** How big the drawn code is. */
export type QRCodeSize = NonNullable<QrCodeVariantProps['size']>;
/** Where the code is drawn: in place, in a popover, or up from the bottom. */
export type QRCodePresentation = 'inline' | 'popover' | 'bottom-sheet';
export interface QRCodeProps extends Omit<ViewProps, 'children'>, QrCodeVariantProps {
    className?: string;
    /**
     * What the code encodes. Anything: a URL, a WiFi string, a vCard. Encoded
     * as UTF-8, and the version grows to fit it.
     */
    value: string;
    /**
     * How much of the code can be lost and still read — `L` about 7%, `M` 15%,
     * `Q` 25%, `H` 30%. More correction means a denser code at the same size, so
     * `M` is the default. Raised automatically when a `QRCode.Logo` needs it.
     */
    errorCorrection?: ErrorCorrectionLevel;
    /**
     * Fix the QR version, 1–40, instead of taking the smallest that fits. Worth
     * setting when the content changes and the code should not visibly change
     * density with it.
     */
    version?: number;
    /**
     * Where the code appears. `inline` draws it where it sits; the other two
     * put it behind a `QRCode.Trigger` and draw it in a `QRCode.Content`.
     */
    presentation?: QRCodePresentation;
    /** Controlled open state. Ignored while `presentation` is `inline`. */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    children?: ReactNode;
}
export interface QRCodeCanvasProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** Side length in points. Defaults to the size variant's. */
    pixelSize?: number;
    /** Dark modules. See the note below before overriding this. */
    color?: string;
    /** The plate the modules sit on. See the note below. */
    backgroundColor?: string;
    /**
     * How a data module is drawn.
     *
     * `rounded` and `classy` join to their neighbours — a corner is rounded only
     * where both cells touching it are light — so a run reads as one stroke
     * rather than as a string of beads with a light seam through it.
     *
     * `dot` and `diamond` do not tile, and cost read distance for it: `dot`
     * covers about two thirds of its cell and `diamond` exactly half, so the
     * same code is a fainter code at the same size. Raise `errorCorrection` with
     * them, and check a printed one rather than a screen.
     */
    moduleShape?: QRCodeModuleShape;
    /** How the ring around each of the three corner eyes is drawn. */
    eyeFrameShape?: QRCodeEyeFrameShape;
    /** How the square inside each corner eye is drawn. */
    eyeBallShape?: QRCodeEyeBallShape;
    /** The three corner rings. Defaults to `color`. */
    eyeFrameColor?: string;
    /** The three corner centres. Defaults to `eyeFrameColor`, then `color`. */
    eyeBallColor?: string;
}
export interface QRCodeFrameProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface QRCodeHeaderProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface QRCodeTitleProps {
    className?: string;
    children?: ReactNode;
}
/** What the code is for. Muted — it is a caption on the tray, not a heading. */
declare function QRCodeTitle({ className, children }: QRCodeTitleProps): import("react").JSX.Element;
declare namespace QRCodeTitle {
    var displayName: string;
}
export interface QRCodeActionProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface QRCodePanelProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface QRCodeDescriptionProps {
    className?: string;
    children?: ReactNode;
}
/** A muted line inside the panel, under the code. */
declare function QRCodeDescription({ className, children }: QRCodeDescriptionProps): import("react").JSX.Element;
declare namespace QRCodeDescription {
    var displayName: string;
}
export interface QRCodeCaptionProps {
    className?: string;
    children?: ReactNode;
}
/** A line under the code saying what scanning it does. */
declare function QRCodeCaption({ className, children }: QRCodeCaptionProps): import("react").JSX.Element;
declare namespace QRCodeCaption {
    var displayName: string;
}
export interface QRCodeValueProps {
    className?: string;
    /** Show the whole string rather than one line of it. */
    full?: boolean;
}
/**
 * The encoded string itself, for someone who cannot scan it — typing a URL out
 * is slower than pointing a camera at it and it is the only way through when
 * the camera is the thing you are setting up.
 */
declare function QRCodeValue({ className, full }: QRCodeValueProps): import("react").JSX.Element;
declare namespace QRCodeValue {
    var displayName: string;
}
export interface QRCodeLogoProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface QRCodeTriggerProps {
    /** The element that opens it. Must accept `onPress`. */
    children: ReactElement<{
        onPress?: (...args: unknown[]) => void;
    }>;
}
/** What opens a `popover` or `bottom-sheet` code. */
declare function QRCodeTrigger({ children }: QRCodeTriggerProps): import("react").JSX.Element;
declare namespace QRCodeTrigger {
    var displayName: string;
}
export interface QRCodeContentProps extends PopoverContentProps {
}
/** The panel the code is drawn in, when it is not drawn in place. */
declare function QRCodeContent({ className, width, children, ...props }: QRCodeContentProps): import("react").JSX.Element;
declare namespace QRCodeContent {
    var displayName: string;
}
export declare const QRCode: import("react").ForwardRefExoticComponent<QRCodeProps & import("react").RefAttributes<ViewRef>> & {
    Canvas: import("react").ForwardRefExoticComponent<QRCodeCanvasProps & import("react").RefAttributes<ViewRef>>;
    Frame: import("react").ForwardRefExoticComponent<QRCodeFrameProps & import("react").RefAttributes<ViewRef>>;
    Header: import("react").ForwardRefExoticComponent<QRCodeHeaderProps & import("react").RefAttributes<ViewRef>>;
    Title: typeof QRCodeTitle;
    Action: import("react").ForwardRefExoticComponent<QRCodeActionProps & import("react").RefAttributes<ViewRef>>;
    Panel: import("react").ForwardRefExoticComponent<QRCodePanelProps & import("react").RefAttributes<ViewRef>>;
    Description: typeof QRCodeDescription;
    Caption: typeof QRCodeCaption;
    Value: typeof QRCodeValue;
    Logo: import("react").ForwardRefExoticComponent<QRCodeLogoProps & import("react").RefAttributes<ViewRef>>;
    Trigger: typeof QRCodeTrigger;
    Content: typeof QRCodeContent;
};
//# sourceMappingURL=index.d.ts.map