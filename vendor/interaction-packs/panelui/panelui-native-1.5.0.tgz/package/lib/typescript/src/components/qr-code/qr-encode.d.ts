/**
 * A QR encoder, in TypeScript, with no dependencies.
 *
 * Vendored rather than installed for the reason the rest of this library has
 * no runtime dependencies: a component that needs an npm package to draw
 * itself is one the CLI has to install on someone's behalf, and every project
 * that copies the source in inherits it. This is a few hundred lines of
 * arithmetic that has not changed since 2000 — it is cheaper to own.
 *
 * Byte mode only. The alphanumeric and numeric modes pack more into the same
 * version, but they only accept their own alphabets, and the thing people
 * encode is a URL. Byte mode takes anything.
 *
 * The output is a square matrix of booleans, dark first. Everything about how
 * it is drawn — module size, colour, quiet zone, the hole in the middle for a
 * logo — belongs to the component, not here.
 */
/** How much of the code can be lost and still read. */
export type ErrorCorrectionLevel = 'L' | 'M' | 'Q' | 'H';
export interface QrMatrix {
    /** `true` is a dark module. Row-major, `[y][x]`. */
    modules: boolean[][];
    /** Modules per side, quiet zone excluded. */
    size: number;
    /** The version chosen for this data, 1–40. */
    version: number;
}
/**
 * Encode `text` as a QR matrix.
 *
 * `version` is chosen to be the smallest that fits unless one is given. A
 * fixed version is worth asking for when the content changes and the code
 * should not visibly change size with it.
 */
export declare function encodeQr(text: string, { errorCorrection, version: requestedVersion, }?: {
    errorCorrection?: ErrorCorrectionLevel;
    version?: number;
}): QrMatrix;
//# sourceMappingURL=qr-encode.d.ts.map