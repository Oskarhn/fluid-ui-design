/**
 * The geometry a styled QR code is drawn from.
 *
 * A code is three different things wearing one colour: the body — every module
 * that carries data — and the three corner eyes, each of which is a square
 * ring with a square inside it. Scanners find a code by those three eyes
 * before they read a single module, which is why they are the part worth
 * shaping separately and the part it is most dangerous to shape badly.
 *
 * Everything here works in **module units**: one module is 1×1, and the paths
 * are placed into a viewBox that is the matrix plus its quiet zone. So a shape
 * is written once and scales to whatever the code is drawn at, with no
 * arithmetic per module and no rounding gaps between neighbours at fractional
 * sizes.
 *
 * ## What is safe to change and what is not
 *
 * A scanner locates a module by sampling the centre of its cell, so a shape
 * that stays inside its own cell and keeps that centre dark reads exactly as a
 * square does. All of these do. What actually costs read distance is *area*:
 * `dot` covers about two thirds of its cell and `diamond` exactly half, so a
 * code in either is a fainter code at the same size, and one in `diamond` at a
 * low error-correction level is a code that works on a screen and not on
 * paper.
 *
 * The rounded shapes join to their neighbours rather than rounding every
 * corner. A corner is rounded only where both cells touching it are light —
 * otherwise a run of modules would be a string of beads with a light seam
 * through it, and the seam is what the sampler sees.
 */
/** How a data module is drawn. */
export type QRCodeModuleShape = 'square' | 'rounded' | 'dot' | 'classy' | 'diamond';
/** How the ring around each of the three corner eyes is drawn. */
export type QRCodeEyeFrameShape = 'square' | 'rounded' | 'circle' | 'leaf' | 'shield';
/** How the square inside each corner eye is drawn. */
export type QRCodeEyeBallShape = 'square' | 'rounded' | 'dot' | 'diamond' | 'leaf';
/** A finder pattern is seven modules on a side, in three of the four corners. */
export declare const FINDER_SIZE = 7;
/** True where `(x, y)` falls inside one of the three finder patterns. */
export declare function inFinder(x: number, y: number, size: number): boolean;
/** Which corner of the code an eye sits in. */
export type QRCodeEyeCorner = 'tl' | 'tr' | 'bl';
/**
 * Where each finder pattern starts, and which corner it is in.
 *
 * The corner is not decoration: an asymmetric eye shape has to be turned to
 * face outwards, or two of the three point into the middle of the code and
 * read as a mistake rather than as a style.
 */
export declare function finderOrigins(size: number): [number, number, QRCodeEyeCorner][];
/** One data module, in the requested shape, offset into the quiet zone. */
export declare function modulePath(shape: QRCodeModuleShape, modules: boolean[][], x: number, y: number, size: number, offset: number): string;
/**
 * One eye's ring: a 7×7 outline with a 5×5 hole in it.
 *
 * Two subpaths and `fillRule="evenodd"`, rather than a stroked rectangle. A
 * stroke is centred on its path, so its outer edge lands half a module outside
 * the seven the specification allows — and the eye stops being seven modules
 * wide, which is the one measurement a scanner takes before it reads anything.
 */
export declare function eyeFramePath(shape: QRCodeEyeFrameShape, x: number, y: number, offset: number, corner?: QRCodeEyeCorner): string;
/** One eye's centre: the 3×3 square two modules inside the ring. */
export declare function eyeBallPath(shape: QRCodeEyeBallShape, x: number, y: number, offset: number): string;
//# sourceMappingURL=qr-shapes.d.ts.map