/**
 * RadioGroup — one choice from a set.
 *
 * The group owns the value and hands each item its selected state through
 * context, so an item is a thin pressable that reports its own value up and
 * reads selection back down.
 *
 * Two shapes, chosen on the group and inherited by every item: `dot` is the
 * classic label-beside-a-disc row; `card` turns the whole surface into the
 * target — for pickable options where the disc is a confirmation rather than
 * the thing you aim at. The card is the same treatment `Checkbox` offers, so a
 * form mixing single- and multi-select choices reads as one family.
 *
 * ```tsx
 * <RadioGroup value={plan} onValueChange={setPlan} variant="card">
 *   <RadioGroup.Item value="pro" label="Pro" description="For growing teams" />
 *   <RadioGroup.Item value="max" label="Max" description="Everything, uncapped" />
 * </RadioGroup>
 * ```
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
type RadioVariant = 'dot' | 'card';
type RadioOrientation = 'vertical' | 'horizontal';
declare const itemVariants: import("tailwind-variants").TVReturnType<{
    size: {
        xs: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
            description: string;
        };
        sm: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
        };
        md: {};
        lg: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
            description: string;
        };
        xl: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
            description: string;
        };
    };
    variant: {
        dot: {};
        card: {
            row: string;
            label: string;
        };
    };
    selected: {
        true: {};
    };
    disabled: {
        true: {
            row: string;
        };
    };
    /**
     * A card in a row shares the width rather than filling it, so two or three
     * options sit side by side instead of each taking the whole line.
     */
    horizontal: {
        true: {};
    };
}, {
    row: string;
    indicator: string;
    dot: string;
    label: string;
    description: string;
}, undefined, {
    size: {
        xs: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
            description: string;
        };
        sm: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
        };
        md: {};
        lg: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
            description: string;
        };
        xl: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
            description: string;
        };
    };
    variant: {
        dot: {};
        card: {
            row: string;
            label: string;
        };
    };
    selected: {
        true: {};
    };
    disabled: {
        true: {
            row: string;
        };
    };
    /**
     * A card in a row shares the width rather than filling it, so two or three
     * options sit side by side instead of each taking the whole line.
     */
    horizontal: {
        true: {};
    };
}, {
    row: string;
    indicator: string;
    dot: string;
    label: string;
    description: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        xs: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
            description: string;
        };
        sm: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
        };
        md: {};
        lg: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
            description: string;
        };
        xl: {
            row: string;
            indicator: string;
            dot: string;
            label: string;
            description: string;
        };
    };
    variant: {
        dot: {};
        card: {
            row: string;
            label: string;
        };
    };
    selected: {
        true: {};
    };
    disabled: {
        true: {
            row: string;
        };
    };
    /**
     * A card in a row shares the width rather than filling it, so two or three
     * options sit side by side instead of each taking the whole line.
     */
    horizontal: {
        true: {};
    };
}, {
    row: string;
    indicator: string;
    dot: string;
    label: string;
    description: string;
}>>;
/** How big a group's discs and labels are. */
type RadioSize = NonNullable<VariantProps<typeof itemVariants>['size']>;
export interface RadioGroupProps extends ViewProps {
    className?: string;
    value?: string;
    onValueChange: (value: string) => void;
    disabled?: boolean;
    /**
     * `dot` is the label-beside-a-disc row. `card` makes the whole surface the
     * target and highlights the selected option — for a plan picker or a
     * settings choice where each option carries a description.
     */
    variant?: RadioVariant;
    /**
     * How big every option's disc and label are. Set on the group rather than
     * per option, because options of different sizes read as though one of them
     * matters more. The row keeps a 48-point target at every size.
     */
    size?: RadioSize;
    /**
     * `horizontal` lays the options out along a row that wraps — for two or
     * three short choices, where a stacked list wastes the width and reads as
     * longer than it is.
     */
    orientation?: RadioOrientation;
    children: ReactNode;
}
export interface RadioGroupItemProps {
    /**
     * Styles the pressable row — layout, border, fill. It does not reach the
     * label: text colour is not inherited from a view in React Native, so use
     * `labelClassName` for that.
     */
    className?: string;
    value: string;
    label?: string;
    /** Classes for the label text, merged over the defaults — e.g. `text-black`. */
    labelClassName?: string;
    /** Secondary line under the label. Most at home in the `card` variant. */
    description?: string;
    /** Classes for the description text, merged over the defaults. */
    descriptionClassName?: string;
    disabled?: boolean;
    /** Hide the disc entirely — for a card whose selected fill is enough. */
    hideIndicator?: boolean;
    children?: ReactNode;
}
export declare const RadioGroup: import("react").ForwardRefExoticComponent<RadioGroupProps & import("react").RefAttributes<ViewRef>> & {
    Item: import("react").ForwardRefExoticComponent<RadioGroupItemProps & import("react").RefAttributes<ViewRef>>;
};
export type { RadioVariant, RadioSize };
//# sourceMappingURL=index.d.ts.map