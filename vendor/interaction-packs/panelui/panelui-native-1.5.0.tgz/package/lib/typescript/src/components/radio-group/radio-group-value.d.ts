export declare function requestRadioValueChange(currentValue: string | undefined, nextValue: string, onValueChange: (value: string) => void): void;
//# sourceMappingURL=radio-group-value.d.ts.map