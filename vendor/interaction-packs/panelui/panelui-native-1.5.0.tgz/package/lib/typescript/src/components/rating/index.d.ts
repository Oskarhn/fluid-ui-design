import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
declare const ratingVariants: import("tailwind-variants").TVReturnType<{
    size: {
        sm: {
            row: string;
        };
        md: {
            row: string;
        };
        lg: {
            row: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    header: string;
    label: string;
    value: string;
    row: string;
}, undefined, {
    size: {
        sm: {
            row: string;
        };
        md: {
            row: string;
        };
        lg: {
            row: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    header: string;
    label: string;
    value: string;
    row: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        sm: {
            row: string;
        };
        md: {
            row: string;
        };
        lg: {
            row: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    header: string;
    label: string;
    value: string;
    row: string;
}>>;
type RatingVariantProps = VariantProps<typeof ratingVariants>;
export type RatingSize = NonNullable<RatingVariantProps['size']>;
export type RatingColor = 'warning' | 'primary' | 'success' | 'destructive' | 'info' | 'foreground';
export interface RatingProps extends Omit<RatingVariantProps, 'disabled'> {
    className?: string;
    /** Controlled value. Leave unset and pass `defaultValue` to run uncontrolled. */
    value?: number;
    /** Starting value when uncontrolled. */
    defaultValue?: number;
    /** How many stars. */
    max?: number;
    /**
     * Smallest step a tap can pick, as a fraction of a star. `1` is whole stars,
     * `0.5` lets the left half of a star mean a half. Reading a value renders any
     * precision — this only constrains what a finger can set.
     */
    precision?: number;
    /** Fires as the value changes, including live while dragging. */
    onValueChange?: (value: number) => void;
    /** Fires once when a tap or drag ends — the place for expensive side effects. */
    onValueCommit?: (value: number) => void;
    /** Show the stars but ignore touches — the display half of the component. */
    readOnly?: boolean;
    disabled?: boolean;
    /**
     * Let a second tap on the current value clear it back to zero, so a rating
     * given by mistake can be taken back without a separate control.
     */
    allowClear?: boolean;
    /** Which token the filled stars are painted with. */
    color?: RatingColor;
    /** Caption above the stars. Also becomes the accessibility label. */
    label?: string;
    /** Show the numeric value on the caption row, opposite the label. */
    showValue?: boolean;
    /** Format the shown value. Defaults to the number as written. */
    formatValue?: (value: number) => string;
    /**
     * A tick under the finger each time a drag crosses onto a new star. Off by
     * default — needs the optional `expo-haptics`, and is silent without it.
     */
    haptics?: boolean;
    /** Extra classes for the caption row. */
    headerClassName?: string;
    /** Extra classes for the row of stars. */
    rowClassName?: string;
}
export declare const Rating: import("react").ForwardRefExoticComponent<RatingProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map