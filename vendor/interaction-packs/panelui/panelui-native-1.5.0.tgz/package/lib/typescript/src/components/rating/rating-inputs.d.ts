export declare function normalizeRatingMax(max: number | undefined): number;
export declare function normalizeRatingPrecision(precision: number | undefined): number;
export declare function normalizeRatingValue(value: number | undefined, max: number): number;
//# sourceMappingURL=rating-inputs.d.ts.map