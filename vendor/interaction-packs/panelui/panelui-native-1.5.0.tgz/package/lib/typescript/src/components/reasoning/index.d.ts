/**
 * Reasoning — the model's working, shown while it happens and folded away after.
 *
 * A reasoning trace is interesting for exactly as long as it is the only thing
 * arriving. Once the answer starts, it is a wall of text above the thing the
 * reader actually asked for. So it opens itself when the trace starts streaming
 * and closes itself about a second after it stops — once, and only if it ever
 * streamed, because a trace that arrives complete was never a live thing to
 * watch and should not perform.
 *
 * The trigger changes with it: a shimmering "Thinking…" while the tokens are
 * coming, and "Thought for 8 seconds" afterwards. The duration is measured from
 * the first streaming frame rather than taken on trust, so it is the time the
 * reader actually waited.
 *
 * ```tsx
 * <Reasoning isStreaming={streaming}>
 *   <Reasoning.Trigger />
 *   <Reasoning.Content>{text}</Reasoning.Content>
 * </Reasoning>
 * ```
 *
 * ## Where the props come from
 *
 * With the AI SDK, `isStreaming` is whether the last part of the last message
 * is a reasoning part while the request is still streaming, and the content is
 * every `reasoning` part joined together. Joined, not one component each:
 * some models emit a run of separate reasoning parts, and one component per
 * part is a column of "Thinking…" rows for a single thought.
 */
import { type ReactNode } from 'react';
import { type PressableProps, type ViewProps } from 'react-native';
export interface ReasoningProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /**
     * Whether the trace is still arriving. Drives the shimmer on the trigger,
     * opens the panel on the way in and closes it a beat after it goes false.
     */
    isStreaming?: boolean;
    /**
     * How long the trace took, in seconds. Measured from the first streaming
     * frame when it is not given, which is the number worth showing — it is what
     * the reader actually waited.
     */
    duration?: number;
    /** Controlled open state. */
    open?: boolean;
    /**
     * Initial state when uncontrolled. Defaults to whether it is streaming, so a
     * live trace is open and a finished one arrives folded. Passing `false`
     * explicitly also opts out of the auto-open.
     */
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    children?: ReactNode;
}
declare function ReasoningRoot({ className, isStreaming, duration: durationProp, open: openProp, defaultOpen, onOpenChange, children, ...props }: ReasoningProps): import("react").JSX.Element;
declare namespace ReasoningRoot {
    var displayName: string;
}
export interface ReasoningTriggerProps extends Omit<PressableProps, 'children' | 'style'> {
    className?: string;
    /**
     * What the row says. Given the streaming state and the measured duration, so
     * a caller can put its own words to both without reimplementing the timing.
     */
    label?: (isStreaming: boolean, duration?: number) => ReactNode;
    /** Replaces the whole row, icon and chevron included. */
    children?: ReactNode;
}
/** The row that says how long it thought, and folds the trace away. */
declare function ReasoningTrigger({ className, label, children, onPress, ...props }: ReasoningTriggerProps): import("react").JSX.Element;
declare namespace ReasoningTrigger {
    var displayName: string;
}
export interface ReasoningContentProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** The trace. A string is wrapped for you; anything else is left alone. */
    children?: ReactNode;
}
/**
 * The trace itself.
 *
 * Kept mounted and collapsed to nothing rather than unmounted, because it is
 * usually still growing while it is folded — and a body that remounts on every
 * open would drop whatever the reader had scrolled to.
 */
declare function ReasoningContent({ className, children, ...props }: ReasoningContentProps): import("react").JSX.Element;
declare namespace ReasoningContent {
    var displayName: string;
}
export declare const Reasoning: typeof ReasoningRoot & {
    Trigger: typeof ReasoningTrigger;
    Content: typeof ReasoningContent;
};
export {};
//# sourceMappingURL=index.d.ts.map