/**
 * Where a flow diagram's nodes and ribbons go.
 *
 * Kept apart from the component for the same reason the splitter's maths is:
 * it is the part with answers that can be checked, and a test that has to
 * mount a chart to check them is a test nobody writes twice.
 *
 * ## The problem the layout is solving
 *
 * A node's column is decided by the flow, not by the caller — a stage that
 * receives from another has to be drawn after it or the ribbon runs backwards.
 * Its height is its value. Neither of those is a choice. What is left over is
 * the *order within a column*, and that is the whole difficulty: the same graph
 * drawn in two orders is the same numbers with a different number of crossings,
 * and crossings are the only thing that makes one of these unreadable.
 *
 * There is no cheap exact answer — minimising crossings is the kind of problem
 * that is only solved by trying — so the order is settled by relaxation. Every
 * node is pulled towards the average height of what it connects to, the pull
 * weakens each round, and nodes that end up overlapping are pushed apart. Six
 * rounds is where the picture stops visibly improving.
 *
 * ## Why it never throws
 *
 * A flow that loops back on itself has no left-to-right reading at all, and the
 * textbook answer is to refuse the graph. A chart cannot refuse: the data is
 * usually arriving from somewhere nobody in the room controls, and a screen
 * that crashes on a bad row is worse than one that draws the rows it can. So a
 * link that closes a loop is dropped, counted, and reported on the layout —
 * the caller can say so, and the rest of the diagram is still true.
 */
/** Which column a node is pushed into when the flow leaves a choice. */
export type SankeyAlign = 'justify' | 'left' | 'right' | 'center';
export interface SankeyLayoutNodeInput {
    /** Stable key the links name. */
    id: string;
    /**
     * Pins the node's total, for a stage whose links do not account for all of
     * it — a step that also loses some of what it received to nowhere.
     */
    value?: number;
}
export interface SankeyLayoutLinkInput {
    source: string;
    target: string;
    value: number;
}
/** Which nodes get folded into one, and what the result is called. */
export interface SankeyCollapse {
    /**
     * Keep at most this many nodes in a column, bucket included. A column with
     * more folds its smallest until it fits.
     */
    maxPerColumn?: number;
    /**
     * Fold any node worth less than this share of its own column, `0` to `1`.
     */
    minShare?: number;
    /** What the bucket is called. Defaults to `Other`. */
    label?: string;
}
export interface SankeyLayoutOptions {
    width: number;
    height: number;
    /** How thick a node's bar is drawn, in points. */
    nodeWidth: number;
    /** The gap asked for between two nodes in a column, in points. */
    nodePadding: number;
    align: SankeyAlign;
    /** Relaxation rounds. More is steadier and slower; six is the useful knee. */
    iterations: number;
    /**
     * Folds a column's smallest nodes into one bucket before laying it out.
     *
     * A ribbon carries its value in its thickness, so a column of thirty is
     * thirty hairlines — present in the data and unreadable on the screen. This
     * is the only option here that reduces what is drawn rather than rearranging
     * it.
     */
    collapse?: SankeyCollapse;
}
export interface SankeyLayoutNode {
    id: string;
    /**
     * Position in the input array, so a caller can find its own datum again.
     * `-1` on a node the layout made up rather than was given — see `collapsed`.
     */
    index: number;
    /**
     * The ids folded into this node, on the bucket `collapse` produced. Absent
     * on every node that came from the caller's array, which is how the two are
     * told apart without comparing ids against the input.
     */
    collapsed?: string[];
    /** Which column it landed in, counting from the left. */
    layer: number;
    /** What flows through it: the larger of what arrives and what leaves. */
    value: number;
    x0: number;
    x1: number;
    y0: number;
    y1: number;
}
export interface SankeyLayoutLink {
    index: number;
    /**
     * Position in the caller's link array. Not the same as `index`: links that
     * name nothing or close a loop are dropped, so the drawn order closes up
     * behind them while this still points at the row it came from.
     */
    input: number;
    /** Index into the laid-out nodes, not into the caller's array. */
    source: number;
    target: number;
    value: number;
    /** How thick the ribbon is, in points. */
    width: number;
    /**
     * The ribbon's centre where it leaves the source, across the flow — points
     * from the top of an upright layout, and from the left of a transposed one.
     */
    y0: number;
    /** And where it meets the target. */
    y1: number;
}
export interface SankeyLayout {
    nodes: SankeyLayoutNode[];
    links: SankeyLayoutLink[];
    /** How many columns the flow turned out to need. */
    columns: number;
    /** Links dropped for closing a loop, naming nothing, or carrying nothing. */
    dropped: number;
}
/**
 * The same arrangement, read down the screen instead of across it.
 *
 * A flow diagram has one axis carrying the order of the stages and another
 * carrying the values, and which of them is horizontal is a question about the
 * screen rather than about the data. So the layout is solved once, upright,
 * and turned afterwards — the alternative is a second copy of the relaxation
 * with every comparison reversed, which is the same maths maintained twice.
 *
 * Reflecting about the diagonal, so it is its own inverse: transposing twice
 * returns the layout unchanged. Call `sankeyLayout` with `width` and `height`
 * swapped and then pass the result through here, or the diagram comes back
 * fitted to the wrong box.
 */
export declare function transposeLayout(layout: SankeyLayout): SankeyLayout;
export declare function sankeyLayout(nodeInput: readonly SankeyLayoutNodeInput[], linkInput: readonly SankeyLayoutLinkInput[], options: SankeyLayoutOptions): SankeyLayout;
//# sourceMappingURL=sankey-layout.d.ts.map