/**
 * ScrollCanvas — an image frame whose contents move as you scroll past it.
 *
 * The counterpart to `ScrollText`: same scrubbed reveal, applied to a picture
 * instead of a sentence. The frame stays where the layout puts it and the image
 * moves *inside* it, which is what separates a parallax from a thing sliding
 * about the page.
 *
 * ```tsx
 * <ScrollProgress>
 *   <ScrollView>
 *     <ScrollCanvas source={{ uri }} effect="parallax" />
 *   </ScrollView>
 * </ScrollProgress>
 * ```
 *
 * Four effects, and they are four different jobs:
 *
 * - **`parallax`** — the image drifts against the scroll, so the frame reads as
 *   a window onto something further away.
 * - **`zoom`** — it settles from slightly oversized to its natural size.
 * - **`reveal`** — a wipe uncovers it from the bottom edge up.
 * - **`sequence`** — the scroll position picks a frame out of a series, so the
 *   reader scrubs an animation with their thumb.
 *
 * "Canvas" here is the frame the pictures move behind, not a drawing surface —
 * nothing is rasterised, and there is no `<canvas>` anywhere near it.
 */
import { type ImageSourcePropType, type ViewProps } from 'react-native';
import { type SharedValue } from 'react-native-reanimated';
export type ScrollCanvasEffect = 'parallax' | 'zoom' | 'reveal' | 'sequence';
export interface ScrollCanvasProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** The image. Ignored by `sequence`, which reads `sources` instead. */
    source?: ImageSourcePropType;
    /**
     * The frames a `sequence` scrubs through, in order. Keep it to a couple of
     * dozen — every frame is a decoded bitmap held in memory for the whole time
     * the canvas is mounted.
     */
    sources?: ImageSourcePropType[];
    /** Which of the four scroll effects to apply. */
    effect?: ScrollCanvasEffect;
    /** Width ÷ height of the frame. */
    aspectRatio?: number;
    /** Multiplier on how far the effect travels. */
    distance?: number;
    /**
     * Where down the viewport the frame's top sits when the effect starts, as a
     * fraction of the viewport height.
     */
    start?: number;
    /** Where its bottom sits when the effect completes. Smaller is a longer scrub. */
    end?: number;
    /** Drive the effect from a value of your own rather than from scroll. */
    progress?: SharedValue<number>;
    /** Set false to render the image plainly. */
    enabled?: boolean;
    /** Extra classes for the image itself, rather than the frame around it. */
    imageClassName?: string;
}
export declare function ScrollCanvas({ className, imageClassName, source, sources, effect, aspectRatio, distance, start, end, progress: external, enabled, style, ...props }: ScrollCanvasProps): import("react").JSX.Element;
export declare namespace ScrollCanvas {
    var displayName: string;
}
//# sourceMappingURL=index.d.ts.map