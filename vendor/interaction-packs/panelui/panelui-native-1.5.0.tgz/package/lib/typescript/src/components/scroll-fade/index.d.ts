/**
 * ScrollFade — fades the edges of a scroll container.
 *
 * Content that runs past a boundary reads better fading out than being cut
 * off, and the fade doubles as an affordance: an edge that is fading is an
 * edge with more content behind it.
 *
 * Scroll position, content size and viewport size are all held in shared
 * values and consumed by `useAnimatedStyle`, so the fades track the scroll on
 * the UI thread without re-rendering React.
 *
 * ```tsx
 * <ScrollFade>
 *   <ScrollView horizontal>…</ScrollView>
 * </ScrollFade>
 * ```
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
export interface ScrollFadeProps extends ViewProps {
    className?: string;
    /** Depth of the fade in pixels. */
    size?: number;
    /** Which edges fade. */
    edges?: 'both' | 'start' | 'end' | 'none';
    /**
     * Scroll axis. Inferred from the child's `horizontal` prop when omitted —
     * pass it explicitly for children that scroll horizontally without that prop
     * (a `FlatList` with `horizontal` set through `contentContainerStyle`, say).
     */
    orientation?: 'horizontal' | 'vertical';
    /**
     * Colour the fade resolves to — normally whatever sits behind the
     * scrollable. Defaults to the theme's background.
     */
    color?: string;
    /** Distance in pixels over which an edge fades from clear to full. */
    fadeInDistance?: number;
    /** Set false to render the child with no fades at all. */
    enabled?: boolean;
    children?: ReactNode;
}
export declare function ScrollFade({ className, size, edges, orientation, color, fadeInDistance, enabled, children, ...props }: ScrollFadeProps): import("react").JSX.Element;
export declare namespace ScrollFade {
    var displayName: string;
}
//# sourceMappingURL=index.d.ts.map