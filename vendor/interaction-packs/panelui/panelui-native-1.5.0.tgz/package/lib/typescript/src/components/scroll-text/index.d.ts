import { type SharedValue } from 'react-native-reanimated';
import { type TextProps } from '../../primitives/text.js';
export type ScrollTextEffect = 'color' | 'fade' | 'rise' | 'highlight';
export type ScrollTextSplit = 'word' | 'character';
export interface ScrollTextProps extends Omit<TextProps, 'children'> {
    className?: string;
    /** The sentence. Split into words or characters, then revealed across them. */
    children?: string;
    /**
     * `color` crossfades each word between two colours, `fade` brings it up from
     * transparent, `rise` lifts it into place, `highlight` sweeps a background
     * behind it.
     */
    effect?: ScrollTextEffect;
    /** Reveal a word at a time, or a character at a time. */
    by?: ScrollTextSplit;
    /** Colour before a word is reached. Defaults to the muted foreground token. */
    from?: string;
    /** Colour once it has been. Defaults to the foreground token. */
    to?: string;
    /**
     * Where down the viewport the block's top sits when the reveal starts, as a
     * fraction of the viewport height.
     */
    start?: number;
    /** Where its bottom sits when the reveal completes. Smaller is a longer scrub. */
    end?: number;
    /**
     * How much of the whole reveal a single word takes, `0` to `1`. Small values
     * make a hard edge travelling along the line; large ones make the whole
     * sentence brighten together.
     */
    stagger?: number;
    /**
     * Drive the reveal from a value of your own rather than from scroll — a
     * progress bar, a gesture, a timeline.
     */
    progress?: SharedValue<number>;
    /** Set false to render the text resolved, with no effect at all. */
    enabled?: boolean;
}
export declare function ScrollText({ className, children, effect, by, from, to, start, end, stagger, progress: external, enabled, ...textProps }: ScrollTextProps): import("react").JSX.Element;
export declare namespace ScrollText {
    var displayName: string;
}
//# sourceMappingURL=index.d.ts.map