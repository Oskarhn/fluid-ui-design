export interface SearchBarDebounceTimer {
    current: ReturnType<typeof setTimeout> | null;
}
export declare function cancelSearchBarDebounce(timer: SearchBarDebounceTimer): void;
export declare function scheduleSearchBarDebounce(timer: SearchBarDebounceTimer, callback: ((value: string) => void) | undefined, value: string, delay: number): void;
export declare function flushSearchBarDebounce(timer: SearchBarDebounceTimer, callback: ((value: string) => void) | undefined, value: string): void;
//# sourceMappingURL=search-bar-debounce.d.ts.map