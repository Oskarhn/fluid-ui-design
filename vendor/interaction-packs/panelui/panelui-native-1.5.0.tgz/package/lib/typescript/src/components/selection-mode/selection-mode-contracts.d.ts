/** Add one value without duplicating it or crossing the configured cap. */
export declare function selectValue(selected: string[], value: string, max?: number): string[];
/** Remove an existing value, or add it under the same contract used by entry. */
export declare function toggleValue(selected: string[], value: string, max?: number): string[];
/** The values produced by select-all, capped by the same normalized limit. */
export declare function selectAllValues(values: string[], max?: number): string[];
/** How many selections constitute all selectable values. */
export declare function selectionTarget(total: number, max?: number): number;
/**
 * A selection-ineligible row keeps its ordinary action in every mode. Only an
 * active, eligible row gives its press to selection.
 */
export declare function selectionOwnsPress(active: boolean, disabled: boolean): boolean;
/** Execute the one action owned by a row press under the interaction contract. */
export declare function handleSelectionItemPress(active: boolean, disabled: boolean, toggle: () => void, action?: () => void): void;
/** Long press enters only from an inactive screen row that can be selected. */
export declare function canEnterSelection(active: boolean, disabled: boolean, sheet: boolean): boolean;
//# sourceMappingURL=selection-mode-contracts.d.ts.map