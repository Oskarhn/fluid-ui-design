/**
 * Separator — a rule between content.
 *
 * React Native has no `<hr>` and no border shorthand that survives a flex row,
 * so a separator here is a view with a size on one axis and a stretch on the
 * other. That is why orientation is a prop rather than something the layout
 * infers: the component has to know which axis carries the thickness.
 *
 * ```tsx
 * <Separator />
 * <Separator orientation="vertical" />
 * <Separator>or</Separator>
 * ```
 *
 * A vertical separator takes its length from the parent, so the parent needs a
 * height — inside a `flex-row` with `items-stretch`, or with an explicit `h-*`
 * on either the row or the separator itself. Without one it measures zero and
 * nothing draws.
 *
 * Passing children turns it into a *labelled* separator: the rule breaks around
 * centred content — the "or continue with" divider in a sign-in form. Only the
 * horizontal axis carries a label, because a stacked word is not a divider; a
 * vertical separator ignores its children and stays a plain hairline.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
declare const separatorVariants: import("tailwind-variants").TVReturnType<{
    orientation: {
        horizontal: "w-full";
        vertical: "h-full";
    };
    variant: {
        thin: "";
        thick: "";
    };
}, undefined, "bg-border", {
    orientation: {
        horizontal: "w-full";
        vertical: "h-full";
    };
    variant: {
        thin: "";
        thick: "";
    };
}, undefined, import("tailwind-variants").TVReturnTypeLike<{
    orientation: {
        horizontal: "w-full";
        vertical: "h-full";
    };
    variant: {
        thin: "";
        thick: "";
    };
}, undefined>>;
export interface SeparatorProps extends ViewProps, VariantProps<typeof separatorVariants> {
    className?: string;
    /**
     * Thickness in pixels, overriding the variant. Sets the height of a
     * horizontal separator and the width of a vertical one.
     */
    thickness?: number;
    /**
     * Whether the separator is only visual. A decorative separator is skipped by
     * screen readers; set false when the split itself carries meaning — between
     * two groups of menu items, say — and it is announced instead. A labelled
     * separator is never decorative: its label is content, so it is always read.
     */
    decorative?: boolean;
    /**
     * Optional label sitting in the break of a horizontal rule — the "or"
     * between two sign-in paths. A bare string is wrapped in the muted label
     * style; an element is rendered as-is. Ignored on the vertical axis, where a
     * label is not a divider.
     */
    children?: ReactNode;
    /** Styles the label text of a labelled separator. */
    labelClassName?: string;
}
export declare const Separator: import("react").ForwardRefExoticComponent<SeparatorProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map