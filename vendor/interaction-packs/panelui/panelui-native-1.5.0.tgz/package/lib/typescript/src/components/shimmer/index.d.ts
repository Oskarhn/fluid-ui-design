/**
 * Shimmer — a highlight that sweeps *through* content rather than over it.
 *
 * The content is used as a mask, and a gradient band is swept behind it on the
 * UI thread. Because the content is the mask, the highlight is clipped to the
 * glyph shapes: text reads as though the letters themselves are catching a
 * light, which is the "thinking…" treatment familiar from AI chat interfaces.
 *
 * ```tsx
 * <Shimmer>Thinking…</Shimmer>
 * ```
 *
 * Set `as="view"` to shimmer arbitrary children (skeleton blocks, cards) — the
 * mask is then the rendered subtree's alpha instead of a line of text.
 */
import { type ReactNode } from 'react';
import { type StyleProp, type TextStyle, type ViewProps } from 'react-native';
export interface ShimmerProps extends ViewProps {
    className?: string;
    /**
     * `text` renders `children` as a single styled string and masks the sweep to
     * the glyphs. `view` masks the sweep to whatever subtree you pass.
     */
    as?: 'text' | 'view';
    /** Milliseconds for one sweep. */
    duration?: number;
    /** Width of the highlight band, as a multiple of the content width. */
    spread?: number;
    /** Colour of the content at rest. Defaults to the theme's muted foreground. */
    baseColor?: string;
    /** Colour at the centre of the sweep. Defaults to the theme's foreground. */
    shimmerColor?: string;
    /** `loop` restarts from the left; `ping-pong` reverses on each pass. */
    mode?: 'loop' | 'ping-pong';
    /** Sweep once instead of repeating. */
    once?: boolean;
    /** Sweep right-to-left. */
    reverse?: boolean;
    /** Set false to render the content statically without animating. */
    enabled?: boolean;
    /** Extra classes for the text when `as="text"`. */
    textClassName?: string;
    /** Extra styles for the text when `as="text"`. */
    textStyle?: StyleProp<TextStyle>;
    /**
     * @deprecated Use `shimmerColor`.
     */
    color?: string;
    /**
     * Peak opacity of the highlight.
     * @deprecated Set `shimmerColor` to a colour with the alpha you want.
     */
    intensity?: number;
    children?: ReactNode;
}
export declare function Shimmer({ className, as, duration, spread, baseColor, shimmerColor, mode, once, reverse, enabled, textClassName, textStyle, color, intensity, children, ...props }: ShimmerProps): import("react").JSX.Element;
export declare namespace Shimmer {
    var displayName: string;
}
//# sourceMappingURL=index.d.ts.map