export type SignatureChangeKind = 'draw' | 'undo' | 'redo' | 'clear';
export interface SignatureAccessibilityAction {
    name: string;
    label: string;
}
/**
 * What the pad reads as when it is focused.
 *
 * It counts strokes and says nothing about whether the signature is finished,
 * because the component cannot know that — one mark may be the whole signature
 * or the first letter of it. Announcing "complete" after the first stroke tells
 * somebody who cannot see the pad that they are done when they may not be.
 */
export declare function signatureAccessibilityValue(strokeCount: number): {
    text: string;
};
export declare function signatureAccessibilityActions(strokeCount: number, undoneCount: number, alternative: boolean, disabled: boolean): SignatureAccessibilityAction[];
/**
 * Spoken when the pad crosses between empty and not, and nowhere else.
 *
 * Every stroke is silent on purpose: a running commentary during drawing is
 * noise over the one gesture the reader is concentrating on. The two crossings
 * are the ones that cannot be felt — that the pad now holds something, and that
 * it no longer does.
 */
export declare function signatureAnnouncement(previousCount: number, strokeCount: number, change: SignatureChangeKind): string | null;
//# sourceMappingURL=signature-accessibility.d.ts.map