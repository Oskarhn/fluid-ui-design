import type { ViewProps } from 'react-native';
export interface SkeletonProps {
    className?: string;
    /**
     * View style for the placeholder — a dimension computed at runtime, or one no
     * utility class expresses. Ordinary sizing belongs in `className`, and a
     * value here wins over the class that sets the same property.
     *
     * The pulse owns `opacity`; setting it here has no effect.
     */
    style?: ViewProps['style'];
    /**
     * What is loading, for a screen reader. Setting it makes this skeleton
     * announce as a busy status; leaving it unset keeps the placeholder out of
     * the accessibility tree entirely.
     *
     * A screen full of placeholders needs **one** of them labelled, not all of
     * them — put it on the skeleton standing for the region and leave the rest
     * silent.
     */
    label?: string;
}
/**
 * Pulsing placeholder for content that has not arrived. The opacity animation
 * runs on the UI thread.
 *
 * A placeholder is a picture of absent content, so it is hidden from assistive
 * technology by default — an unlabelled grey box announces nothing worth
 * hearing, and a screen of them announces it many times over. Pass `label` on
 * the one skeleton that stands for the region to have the wait announced once.
 *
 * Under the platform's reduce-motion setting the pulse stops and the
 * placeholder holds at a middle opacity. Unlike a spinner, a skeleton that
 * stops moving does not read as hung: it is a shape where content will be, and
 * the shape says that on its own.
 */
export declare const Skeleton: import("react").MemoExoticComponent<({ className, style, label, }: SkeletonProps) => import("react").JSX.Element>;
//# sourceMappingURL=index.d.ts.map