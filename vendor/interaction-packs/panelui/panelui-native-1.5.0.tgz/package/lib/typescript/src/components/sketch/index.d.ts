import { type ViewProps } from 'react-native';
/** True when a sketch can be rasterised to PNG. */
export declare const hasSketchRaster: boolean;
export type SketchTool = 'pen' | 'shape' | 'eraser';
export type SketchShape = 'line' | 'arrow' | 'rectangle' | 'ellipse' | 'triangle' | 'diamond' | 'star' | 'heart';
/** One document entry. Shapes are stored as the path they were drawn as. */
export type SketchItem = {
    type: 'stroke';
    d: string;
    color: string;
    width: number;
} | {
    type: 'shape';
    shape: SketchShape;
    d: string;
    color: string;
    width: number;
} | {
    type: 'erase';
    d: string;
    width: number;
};
export interface SketchResult {
    /** The drawing as a standalone SVG document, sized to the canvas. */
    svg: string;
    /** The canvas size in points, which is the SVG's coordinate space. */
    width: number;
    height: number;
    /** Everything drawn, in order, including eraser strokes. */
    items: SketchItem[];
}
export interface SketchHandle {
    /** Take back the last stroke, shape or eraser stroke. */
    undo(): void;
    /** Remove everything. */
    clear(): void;
    /** True until something has been drawn. */
    isEmpty(): boolean;
    /** The drawing as a standalone SVG document. Pure string building. */
    toSVG(): string;
    /**
     * Rasterise the canvas to a PNG and resolve its temporary file URI. Needs
     * the optional `react-native-view-shot`, and throws by name without it.
     */
    toPNG(options?: {
        scale?: number;
    }): Promise<string>;
}
export interface SketchProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** The swatches along the bottom. The custom-colour button sits before them. */
    colors?: string[];
    /** The ink to start with. Defaults to the theme's foreground. */
    defaultColor?: string;
    /** The tool selected when the surface opens. Default `pen`. */
    defaultTool?: SketchTool;
    /** The shape the shape tool draws until another is picked. Default `rectangle`. */
    defaultShape?: SketchShape;
    /** Which shapes the grid offers, in order. Defaults to all eight. */
    shapes?: SketchShape[];
    /** Stroke width to start with, in points. Default 6. */
    defaultSize?: number;
    /** The thinnest stroke the slider reaches. Default 2. */
    minSize?: number;
    /** The thickest stroke the slider reaches. Default 24. */
    maxSize?: number;
    /** Show the custom-colour button before the swatches. Default true. */
    customColor?: boolean;
    /**
     * Called by the close button in the top leading corner. Leave it out and
     * there is no close button — for a sketch embedded in a screen that has its
     * own way out.
     */
    onClose?: () => void;
    /**
     * Called by the confirm button with the finished drawing. Leave it out and
     * there is no confirm button. The button is disabled until something has
     * been drawn.
     */
    onDone?: (result: SketchResult) => void;
    /** The number of items in the document changed — by drawing, undo or clear. */
    onChange?: (itemCount: number) => void;
}
export interface SketchSheetProps extends SketchProps {
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /**
     * Present the platform's own sheet, painted solid in the theme's popover
     * surface. On by default. Requires the optional `@expo/ui` package; without
     * it the styled sheet is used instead.
     *
     * On iOS the sheet cannot be dragged away, so a downward stroke draws
     * rather than moving the sheet. The close button is the way out.
     */
    native?: boolean;
}
export declare const Sketch: import("react").ForwardRefExoticComponent<SketchProps & import("react").RefAttributes<SketchHandle>> & {
    Sheet: import("react").ForwardRefExoticComponent<SketchSheetProps & import("react").RefAttributes<SketchHandle>>;
};
//# sourceMappingURL=index.d.ts.map