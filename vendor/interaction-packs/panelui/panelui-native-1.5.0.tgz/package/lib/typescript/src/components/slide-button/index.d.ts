/**
 * SlideButton — drag across to confirm, with the distance drawn on the button.
 *
 * ```tsx
 * <SlideButton onComplete={ship}>
 *   <SlideButton.Label>Slide to ship</SlideButton.Label>
 * </SlideButton>
 * ```
 *
 * For an action worth a moment's deliberation, where a hold is the wrong
 * shape. A hold asks for time and shows a clock; a slide asks for a movement
 * and shows a distance — so the reader can go as fast as they like, and still
 * cannot arrive by tapping. Pair it with [ProgressButton](../progress-button)
 * rather than choosing between them: the hold suits an action that should feel
 * expensive, the slide one that should feel deliberate.
 *
 * ## The far end is the promise
 *
 * Nothing fires until the thumb clears `threshold`, which defaults to nine
 * tenths of the rail. Released short, it springs home and the fill goes with
 * it. Released short but travelling, it is honoured — a flick that had
 * plainly committed is not worth refusing on a technicality, and the velocity
 * is projected forward to decide.
 *
 * ## How it is drawn
 *
 * A track, a fill that follows the thumb, and a label that fades as the thumb
 * reaches it. The label fades rather than sliding out of the way because the
 * thumb is about to be where the label is, and two things moving toward each
 * other at different speeds reads as a collision.
 *
 * The thumb is translated and the fill's width animated, both on the UI thread
 * off one shared value, so a drag never re-renders React.
 *
 * ## Sliding without a finger
 *
 * A drag is not available to a screen reader, so the rail is also a button:
 * it takes an `activate` accessibility action and completes on it. This is not
 * a lesser path bolted on — a confirmation control that can only be reached by
 * dragging is a confirmation control some people cannot use.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type SharedValue } from 'react-native-reanimated';
import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
declare const slideButtonVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        secondary: {
            label: string;
            fill: string;
        };
        destructive: {
            label: string;
            fill: string;
        };
        success: {
            label: string;
            fill: string;
        };
    };
    size: {
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
    };
    fullWidth: {
        true: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    /**
     * The ground the handle has covered.
     *
     * Inset on every side by the same padding the handle sits in, so at rest
     * it is exactly zero wide and there is nothing to see — a trail with a
     * sliver of colour in it before anything has been dragged is a control
     * that looks part-finished.
     */
    fill: string;
    /** The label, centred in the rail rather than in the space beside it. */
    label: string;
    /**
     * The draggable handle. Wider than it is tall, so it reads as something to
     * push rather than as a dot that happens to be on a track — and the extra
     * width is what gives the chevron room to sit in without crowding the
     * curve at either end.
     */
    thumb: string;
    /** What the thumb holds — a chevron at rest, a tick once it has arrived. */
    thumbContent: string;
}, undefined, {
    variant: {
        secondary: {
            label: string;
            fill: string;
        };
        destructive: {
            label: string;
            fill: string;
        };
        success: {
            label: string;
            fill: string;
        };
    };
    size: {
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
    };
    fullWidth: {
        true: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    /**
     * The ground the handle has covered.
     *
     * Inset on every side by the same padding the handle sits in, so at rest
     * it is exactly zero wide and there is nothing to see — a trail with a
     * sliver of colour in it before anything has been dragged is a control
     * that looks part-finished.
     */
    fill: string;
    /** The label, centred in the rail rather than in the space beside it. */
    label: string;
    /**
     * The draggable handle. Wider than it is tall, so it reads as something to
     * push rather than as a dot that happens to be on a track — and the extra
     * width is what gives the chevron room to sit in without crowding the
     * curve at either end.
     */
    thumb: string;
    /** What the thumb holds — a chevron at rest, a tick once it has arrived. */
    thumbContent: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        secondary: {
            label: string;
            fill: string;
        };
        destructive: {
            label: string;
            fill: string;
        };
        success: {
            label: string;
            fill: string;
        };
    };
    size: {
        sm: {
            root: string;
            label: string;
        };
        md: {
            root: string;
            label: string;
        };
        lg: {
            root: string;
            label: string;
        };
    };
    fullWidth: {
        true: {
            root: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    /**
     * The ground the handle has covered.
     *
     * Inset on every side by the same padding the handle sits in, so at rest
     * it is exactly zero wide and there is nothing to see — a trail with a
     * sliver of colour in it before anything has been dragged is a control
     * that looks part-finished.
     */
    fill: string;
    /** The label, centred in the rail rather than in the space beside it. */
    label: string;
    /**
     * The draggable handle. Wider than it is tall, so it reads as something to
     * push rather than as a dot that happens to be on a track — and the extra
     * width is what gives the chevron room to sit in without crowding the
     * curve at either end.
     */
    thumb: string;
    /** What the thumb holds — a chevron at rest, a tick once it has arrived. */
    thumbContent: string;
}>>;
type SlideButtonVariantProps = VariantProps<typeof slideButtonVariants>;
/** How a slide button looks. */
export type SlideButtonVariant = NonNullable<SlideButtonVariantProps['variant']>;
/** How big a slide button is. */
export type SlideButtonSize = NonNullable<SlideButtonVariantProps['size']>;
/** The slide's progress and whether it has completed, for a custom part. */
export declare function useSlideButton(): {
    progress: SharedValue<number>;
    completed: boolean;
};
export interface SlideButtonProps extends Omit<ViewProps, 'children'>, Omit<SlideButtonVariantProps, 'disabled'> {
    /** Extra classes for the rail — the box the button occupies in your layout. */
    className?: string;
    /**
     * The fraction of the rail the thumb has to cover for the slide to count.
     * Defaults to `0.9`, clamped to between `0.1` and `1`.
     */
    threshold?: number;
    /** Fires once the thumb has been taken past the threshold and released. */
    onComplete?: () => void;
    /** Fires whenever the completed state changes, including on a reset. */
    onCompletedChange?: (completed: boolean) => void;
    /** Controlled completion. Leave unset to let the button own it. */
    completed?: boolean;
    /** Return to the unslid state after `autoResetDelay`. */
    autoReset?: boolean;
    /** Milliseconds to stay completed before resetting. Defaults to `1000`. */
    autoResetDelay?: number;
    /** Dim the button and refuse the drag outright. */
    disabled?: boolean;
    /**
     * A tick as the thumb arms and a knock when it commits. Off by default,
     * because a control used several times in a row is one a reader may not want
     * buzzing every time.
     */
    haptics?: boolean;
    /**
     * What a screen reader is told the button does, in the imperative — it is
     * announced as the action of a button rather than as an instruction to drag,
     * since dragging is not available there. Defaults to `'Confirm'`.
     */
    accessibilityActionLabel?: string;
    children?: ReactNode;
}
export interface SlideButtonLabelProps extends ViewProps {
    /** Extra classes for the label's text. */
    className?: string;
    children?: ReactNode;
}
/**
 * What the button says.
 *
 * Centred in the whole rail rather than in the space beside the thumb, and it
 * does not move or fade — the thumb simply passes over it, and the rail's own
 * clip takes the rest.
 *
 * Fading it out was worse in a way that only shows on a device: the label
 * disappears while there is still most of a rail left to cross, so the button
 * spends the second half of the gesture saying nothing at all. Covered
 * instead, the text is legible right up to the moment the handle reaches it,
 * which is also the moment the reader no longer needs it.
 */
declare function SlideButtonLabel({ className, style, children, ...props }: SlideButtonLabelProps): import("react").JSX.Element;
declare namespace SlideButtonLabel {
    var displayName: string;
}
export interface SlideButtonThumbProps extends ViewProps {
    /** Extra classes for the thumb — its fill and shape. Its size comes from `size`. */
    className?: string;
    /** Replaces the chevron. The tick that lands on completion is unaffected. */
    children?: ReactNode;
}
/**
 * The disc the finger moves.
 *
 * Translated rather than laid out at a position, so a drag costs no layout
 * pass. It sits absolutely at the rail's leading inset and travels from there.
 */
declare function SlideButtonThumb({ className, style, children, ...props }: SlideButtonThumbProps): import("react").JSX.Element;
declare namespace SlideButtonThumb {
    var displayName: string;
}
export declare const SlideButton: import("react").ForwardRefExoticComponent<SlideButtonProps & import("react").RefAttributes<ViewRef>> & {
    Label: typeof SlideButtonLabel;
    Thumb: typeof SlideButtonThumb;
};
export {};
//# sourceMappingURL=index.d.ts.map