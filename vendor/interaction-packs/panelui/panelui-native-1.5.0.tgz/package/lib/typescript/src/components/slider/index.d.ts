import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
declare const sliderVariants: import("tailwind-variants").TVReturnType<{
    color: {
        primary: {
            fill: string;
            thumb: string;
        };
        success: {
            fill: string;
            thumb: string;
        };
        warning: {
            fill: string;
            thumb: string;
        };
        destructive: {
            fill: string;
            thumb: string;
        };
        info: {
            fill: string;
            thumb: string;
        };
    };
    size: {
        sm: {
            track: string;
            thumb: string;
        };
        md: {
            track: string;
            thumb: string;
        };
        lg: {
            track: string;
            thumb: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    header: string;
    label: string;
    value: string;
    track: string;
    fill: string;
    thumb: string;
    knob: string;
}, undefined, {
    color: {
        primary: {
            fill: string;
            thumb: string;
        };
        success: {
            fill: string;
            thumb: string;
        };
        warning: {
            fill: string;
            thumb: string;
        };
        destructive: {
            fill: string;
            thumb: string;
        };
        info: {
            fill: string;
            thumb: string;
        };
    };
    size: {
        sm: {
            track: string;
            thumb: string;
        };
        md: {
            track: string;
            thumb: string;
        };
        lg: {
            track: string;
            thumb: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    header: string;
    label: string;
    value: string;
    track: string;
    fill: string;
    thumb: string;
    knob: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    color: {
        primary: {
            fill: string;
            thumb: string;
        };
        success: {
            fill: string;
            thumb: string;
        };
        warning: {
            fill: string;
            thumb: string;
        };
        destructive: {
            fill: string;
            thumb: string;
        };
        info: {
            fill: string;
            thumb: string;
        };
    };
    size: {
        sm: {
            track: string;
            thumb: string;
        };
        md: {
            track: string;
            thumb: string;
        };
        lg: {
            track: string;
            thumb: string;
        };
    };
    disabled: {
        true: {
            root: string;
        };
    };
}, {
    root: string;
    header: string;
    label: string;
    value: string;
    track: string;
    fill: string;
    thumb: string;
    knob: string;
}>>;
type SliderVariantProps = VariantProps<typeof sliderVariants>;
export interface SliderProps extends Omit<SliderVariantProps, 'disabled'> {
    className?: string;
    /** Controlled value. Leave unset and pass `defaultValue` to run uncontrolled. */
    value?: number;
    /** Starting value when uncontrolled. */
    defaultValue?: number;
    /**
     * Controlled span, as `[low, high]`. Passing this — or `defaultRange` — gives
     * the slider two thumbs and fills between them instead of from the start.
     */
    range?: [number, number];
    /** Starting span when uncontrolled, as `[low, high]`. */
    defaultRange?: [number, number];
    /** Lower bound. */
    min?: number;
    /** Upper bound. */
    max?: number;
    /** Snap granularity. The value is always a multiple of `step` from `min`. */
    step?: number;
    /**
     * How many steps the two thumbs must stay apart on a range slider. `0` lets
     * them meet; `1` keeps a step between them, so the span is never empty.
     */
    minStepsBetweenThumbs?: number;
    /** Fires on every change while dragging — cheap updates only. */
    onValueChange?: (value: number) => void;
    /** Fires once when the gesture ends — the place for expensive side effects. */
    onValueCommit?: (value: number) => void;
    /** The range equivalent of `onValueChange`. Only fires on a range slider. */
    onRangeChange?: (range: [number, number]) => void;
    /** The range equivalent of `onValueCommit`. Only fires on a range slider. */
    onRangeCommit?: (range: [number, number]) => void;
    disabled?: boolean;
    /**
     * Render the platform's own slider instead of this one. Requires the
     * optional `@expo/ui` package; without it this prop does nothing.
     *
     * **Theme tokens do not apply** — the platform draws the control, so
     * `color`, `size` and the slot classNames are ignored. `label` and
     * `showValue` still render the caption row above it, since that is ours.
     *
     * **Ignored on a range slider.** Neither platform ships a two-thumb slider,
     * so a range draws ours rather than quietly losing a thumb.
     */
    native?: boolean;
    /** Caption above the track. Also becomes the accessibility label. */
    label?: string;
    /** Show the current value on the caption row, opposite the label. */
    showValue?: boolean;
    /** Format the shown value. Defaults to the rounded number. */
    formatValue?: (value: number) => string;
    /**
     * A tick under the finger each time a drag crosses onto a new step, and once
     * more when the drag ends. Off by default — needs the optional `expo-haptics`,
     * and is silent without it.
     */
    haptics?: boolean;
    /** Extra classes for the caption row. */
    headerClassName?: string;
    /** Extra classes for the unfilled track. */
    trackClassName?: string;
    /** Extra classes for the filled portion. */
    fillClassName?: string;
    /** Extra classes for the draggable thumb. */
    thumbClassName?: string;
    /** Extra classes for the knob inside the thumb. */
    knobClassName?: string;
}
export declare const Slider: import("react").ForwardRefExoticComponent<SliderProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map