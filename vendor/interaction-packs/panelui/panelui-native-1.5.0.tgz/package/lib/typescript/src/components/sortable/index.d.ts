/**
 * Sortable — a list whose rows can be dragged into a different order.
 *
 * The one list interaction nothing else in the library covers. `Swipe` acts on
 * a row, `Tree` opens one, `Table` sorts every row at once by a column — none
 * of them let a person say *this one goes above that one*, which is how a
 * playlist, a task list, a set of form fields or a run of dashboard tiles is
 * actually arranged.
 *
 * ```tsx
 * const [tasks, setTasks] = useState(TASKS);
 *
 * <Sortable
 *   value={tasks.map((task) => task.id)}
 *   onReorder={(_, { from, to }) => setTasks((t) => reorderItems(t, from, to))}
 *   gap={8}
 * >
 *   {tasks.map((task) => (
 *     <Sortable.Item key={task.id} id={task.id}>
 *       <Item variant="outline">
 *         <Item.Content>
 *           <Item.Title>{task.title}</Item.Title>
 *         </Item.Content>
 *         <Sortable.Handle />
 *       </Item>
 *     </Sortable.Item>
 *   ))}
 * </Sortable>
 * ```
 *
 * ## Nothing is ever moved in the tree
 *
 * The rows stay exactly where they were laid out and are pushed around with
 * transforms. A row's offset is the difference between where its slot sits in
 * the order being dragged and where it sits in the order that was rendered —
 * one subtraction, on the UI thread, per row per frame. Reordering the
 * children instead would mean React reconciling the whole list on every slot
 * the finger crosses, which is the one thing a drag cannot afford.
 *
 * It also means the component never owns the order. It reports where a row was
 * dropped and the list is the caller's to rearrange, because the caller is the
 * only one who knows what the ids stand for — a `value` that disagreed with
 * the children would put rows in places their content had not moved to.
 *
 * ## Heights are measured, not assumed
 *
 * Every row reports its own height, so a list of rows of different sizes lands
 * in the right slots. A fixed row height would be one number to get wrong in
 * every list that has a two-line row in it, and the measurement costs one
 * layout pass on mount.
 *
 * ## Where the drop is reported
 *
 * `onReorder` fires when the row has finished settling, not when the finger
 * lifts. Between those two moments the row is animating into a slot that the
 * layout does not know about yet; re-rendering the list in the middle of that
 * would relayout every row underneath it and the settling row would jump. By
 * the time the callback runs the rows are already where the new order puts
 * them, so the re-render that follows changes nothing on screen.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import Animated, { type AnimatedRef } from 'react-native-reanimated';
/** What starts a drag. */
export type SortableActivation = 'handle' | 'longPress';
/** Where a row ended up, alongside the order it produced. */
export interface SortableReorderDetails {
    /** The row that was dragged. */
    id: string;
    /** Its index before the drag. */
    from: number;
    /** Its index after it. */
    to: number;
}
/**
 * The same move applied to a list of your own.
 *
 * `onReorder` hands back the new order of the ids, but a list is rarely a list
 * of ids — it is a list of the things they name. This does the move on that
 * list, and returns a new array rather than sorting in place, because the one
 * that mutated would be the one React had already decided was unchanged.
 *
 * ```tsx
 * onReorder={(_, { from, to }) => setTasks((tasks) => reorderItems(tasks, from, to))}
 * ```
 *
 * Indices outside the list are returned unchanged rather than throwing: a
 * reorder is not worth crashing a screen over, and a list that did not move is
 * the honest result of a move that had nowhere to go.
 */
export declare function reorderItems<T>(items: readonly T[], from: number, to: number): T[];
/**
 * What the row being rendered knows about itself.
 *
 * For a handle of your own, or for a row that looks different while it is
 * being carried — dimmed neighbours, a border, a shadow. `isActive` is a plain
 * boolean and changes twice in a drag rather than sixty times a second: it is
 * set when the row is lifted and cleared when it lands, and nothing between
 * those two moments touches React at all.
 */
export declare function useSortableItem(): {
    id: string;
    index: number;
    isActive: boolean;
    disabled: boolean;
};
export interface SortableProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /**
     * The ids of the rows, in the order they are rendered below. It is the
     * caller's array rather than the component's, because only the caller knows
     * what an id stands for — an order held here that disagreed with the
     * children would put rows in places their content had not moved to.
     */
    value: string[];
    /**
     * The rows, one `Sortable.Item` per id in `value` and in the same order.
     * They may be wrapped in anything; each row registers itself.
     */
    children?: ReactNode;
    /**
     * Told the new order once the dropped row has settled, and where it came
     * from and went. Rearrange your own list from `details` — `reorderItems`
     * does exactly this move.
     */
    onReorder?: (order: string[], details: SortableReorderDetails) => void;
    /**
     * Space between rows, in points. A prop rather than a `gap` class because
     * the drag has to know it: the slot a row lands in is measured, and a gap
     * the component cannot read is a gap it drops rows into the middle of.
     */
    gap?: number;
    /**
     * What lifts a row. `handle` is the default and the safer one — the rest of
     * the row stays free to be pressed, and a list of rows with buttons on them
     * still works. `longPress` gives the whole row to the drag.
     */
    activation?: SortableActivation;
    /** How long `longPress` activation waits, in milliseconds. */
    longPressDelay?: number;
    /**
     * Knock when a row is lifted, tick as it passes each slot. On by default:
     * a drag with no feedback under the finger is the interaction people give up
     * on halfway through, unsure whether anything is happening.
     */
    haptics?: boolean;
    /** Turn every row's drag off and leave the list static. */
    disabled?: boolean;
    /**
     * The scroller the list sits in, from `useAnimatedRef`. Given one, a drag
     * carried to the top or bottom edge scrolls it, so a list longer than the
     * screen can be reordered end to end. Without it a drag stops at the edge,
     * which is correct for a list that fits.
     */
    scrollRef?: AnimatedRef<Animated.ScrollView>;
    /** Points from the scroller's edge at which the scrolling begins. */
    autoscrollThreshold?: number;
    /** Points per frame at the very edge, tapering to nothing at the threshold. */
    autoscrollSpeed?: number;
    /** Told which row was lifted, the moment it is. */
    onDragStart?: (id: string) => void;
    /** Told when it lands, whether or not the order changed. */
    onDragEnd?: (id: string) => void;
}
/**
 * The list, and everything the rows share.
 *
 * It renders one plain `View` in a column and nothing else. The rows are the
 * caller's, laid out by flexbox in the order they were written; the component
 * only ever adds a transform to them.
 */
declare function SortableRoot({ className, value, children, onReorder, gap, activation, longPressDelay, haptics, disabled, scrollRef, autoscrollThreshold, autoscrollSpeed, onDragStart, onDragEnd, ...props }: SortableProps): import("react").JSX.Element;
declare namespace SortableRoot {
    var displayName: string;
}
export interface SortableItemProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /**
     * What this row is, and the id that appears in `value` and in the order
     * handed back. Stable across renders — an id derived from the index changes
     * the moment the list is reordered, and the rows lose track of themselves.
     */
    id: string;
    children?: ReactNode;
    /**
     * Stop this row being picked up. The others still move past it, because a
     * row that cannot be dragged is not the same as a row that cannot be
     * displaced — that is what `pinned` is for, and conflating the two would mean
     * silently refusing drops that look like they worked.
     */
    disabled?: boolean;
    /**
     * Hold this row's place in the list. It cannot be picked up, and — unlike a
     * `disabled` row — nothing else can take its slot either: the rows being
     * dragged reorder among the places left over, and one carried past this row
     * goes around it rather than through it.
     *
     * For the row that means something by being where it is. A header, a total, a
     * step that has to come first.
     */
    pinned?: boolean;
    /**
     * Extra classes for the row while it is being carried, applied last. A
     * lifted row is given an opaque surface and a shadow so it is never drawn
     * see-through over the rows it is passing; this is what overrides that.
     */
    activeClassName?: string;
}
/**
 * One row.
 *
 * It measures itself, carries its own transform, and holds the pan — which is
 * either wrapped around the whole row or handed to a `Sortable.Handle` inside
 * it, depending on what lifts a row in this list.
 */
declare function SortableItem({ className, activeClassName, id, children, disabled, pinned, ...props }: SortableItemProps): import("react").JSX.Element;
declare namespace SortableItem {
    var displayName: string;
}
export interface SortableHandleProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** Replaces the grip glyph. Anything at all — the drag is on the box. */
    children?: ReactNode;
    /** What a screen reader calls the grip. */
    accessibilityLabel?: string;
}
/**
 * The part of a row that lifts it.
 *
 * A grip exists so the rest of the row does not have to be given up to the
 * drag: a row with a button, a checkbox or a link on it needs those to stay
 * pressable, and a long press on the whole row takes all of them. It is sized
 * to be hit rather than to be seen, which is why the box around the glyph is
 * larger than the glyph.
 *
 * Inert in a list that lifts on a long press — the whole row already carries
 * the gesture there, and a second one inside it would fight the first.
 */
declare function SortableHandle({ className, children, accessibilityLabel, ...props }: SortableHandleProps): import("react").JSX.Element;
declare namespace SortableHandle {
    var displayName: string;
}
export declare const Sortable: typeof SortableRoot & {
    Item: typeof SortableItem;
    Handle: typeof SortableHandle;
};
export {};
//# sourceMappingURL=index.d.ts.map