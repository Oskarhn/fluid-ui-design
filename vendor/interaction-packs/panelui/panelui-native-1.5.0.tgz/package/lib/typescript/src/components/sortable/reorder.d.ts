type PinnedItems = Readonly<Record<string, boolean>>;
/**
 * Move one item, then restore pinned items to the slots in `laid`.
 *
 * Restoring after the move lets an item cross a pin instead of turning that
 * slot into a wall. The laid-out order is the source of truth because it is
 * the last arrangement the caller rendered and therefore the one whose pins
 * are known to be in their promised positions.
 */
export declare function moveWithPinned(list: readonly string[], laid: readonly string[], pinned: PinnedItems, id: string, from: number, to: number): string[];
/** Move by one available slot, stepping past pinned slots that would be a no-op. */
export declare function stepWithPinned(list: readonly string[], laid: readonly string[], pinned: PinnedItems, id: string, from: number, delta: number): string[];
export {};
//# sourceMappingURL=reorder.d.ts.map