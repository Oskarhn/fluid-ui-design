import { type ViewProps } from 'react-native';
import { type SharedValue } from 'react-native-reanimated';
export type SoundwaveVariant = 'pills' | 'bars' | 'line' | 'ambient';
export type SoundwaveState = 'idle' | 'listening' | 'thinking' | 'speaking';
export interface SoundwaveProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /**
     * Which look to draw: `pills` for a few capsules over a microphone button,
     * `bars` for a metering strip, `line` for a travelling wave, `ambient` for a
     * glow that fills its parent.
     */
    variant?: SoundwaveVariant;
    /**
     * What the app is doing. With no `level` supplied this picks the motion the
     * wave runs on its own; it always sets what a screen reader announces.
     */
    state?: SoundwaveState;
    /**
     * Input level, 0–1, from your own recorder's metering. Pass a `SharedValue`
     * to keep updates off the JS thread entirely. Omit it and the wave animates
     * plausible motion for the current `state`.
     */
    level?: number | SharedValue<number>;
    /**
     * Per-band levels, 0–1 each, for `bars` in `static` mode when the app has a
     * real frequency analysis — or the stored shape of a finished recording.
     * Resampled to the bar count, and drawn still rather than animated.
     */
    levels?: number[];
    /**
     * Playback position through a recording, 0–1. Bars behind it keep full ink
     * and the rest are dimmed, which is the voice-note progress bar. `bars` only,
     * and it goes with `levels` — a recording has a fixed shape to play through.
     */
    progress?: number | SharedValue<number>;
    /** How many capsules (`pills`) or bars (`bars`) to draw. */
    bars?: number;
    /** Capsule width, or bar stroke width. Also the stroke width of `line`. */
    barWidth?: number;
    /** Gap between capsules. `bars` spaces itself evenly across the width. */
    barGap?: number;
    /** Drawing height. `ambient` ignores it and fills its parent. */
    height?: number;
    /**
     * `static` gives every bar a band of the current level; `scrolling` keeps a
     * history that slides across, newest at the trailing edge. `bars` only.
     */
    mode?: 'static' | 'scrolling';
    /** Grow bars from the middle out rather than up from the baseline. */
    centered?: boolean;
    /** Fade the wave out at both ends, so it does not stop at a hard edge. */
    fadeEdges?: boolean;
    /** Multiplier on the incoming level, applied before it is clamped to 1. */
    sensitivity?: number;
    /** Multiplier on the wave's own tempo, including how fast history scrolls. */
    speed?: number;
    /**
     * Ink. Takes a colour — `#f97316`, `rgba(…)` — or a **theme token name**,
     * `color="--color-info"`, which resolves against the active theme and follows
     * it into dark mode.
     *
     * Left unset, a wave inside a surface that publishes a foreground (a chat
     * bubble, a button) is drawn in that foreground, and anywhere else in
     * `--color-foreground` — or `--color-info` for `ambient`.
     */
    color?: string;
    /**
     * Colour across the wave instead of one flat ink: two or more colours spread
     * left to right, or ramped up from the bottom edge for `ambient`. Literal
     * colours only — for a themed one, resolve the tokens with `useCSSVariable`
     * and pass the result.
     */
    gradient?: readonly string[];
    /**
     * Colour of the part of a recording that has not played yet. Defaults to the
     * ink at low opacity, which is right for most surfaces; set it when you want
     * the track to read as its own thing. `bars` with `progress`.
     */
    trackColor?: string;
    /** Freeze on the current frame. */
    paused?: boolean;
    /** Corner radius `ambient` traces. Match it to the screen it sits on. */
    radius?: number;
    /** Overrides the per-state default announced to screen readers. */
    accessibilityLabel?: string;
}
export declare function Soundwave({ className, variant, state, level, levels, progress, bars, barWidth, barGap, height, mode, centered, fadeEdges, sensitivity, speed, color, gradient, trackColor, paused, radius, accessibilityLabel, style, ...props }: SoundwaveProps): import("react").JSX.Element;
export declare namespace Soundwave {
    var displayName: string;
}
//# sourceMappingURL=index.d.ts.map