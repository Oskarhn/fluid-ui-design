/**
 * Sources — where an answer came from, folded under a count.
 *
 * A cited answer usually cites more places than anyone wants listed above it,
 * so the list opens from a single line: "Used 6 sources". Folded is the resting
 * state, unlike `Reasoning`, because a citation list is a thing you go and
 * check rather than a thing you watch arrive.
 *
 * ```tsx
 * <Sources>
 *   <Sources.Trigger count={sources.length} />
 *   <Sources.Content>
 *     {sources.map((source) => (
 *       <Sources.Source key={source.url} href={source.url} title={source.title} />
 *     ))}
 *   </Sources.Content>
 * </Sources>
 * ```
 *
 * ## Where the props come from
 *
 * With the AI SDK these are the `source-url` parts of an assistant message:
 * `part.url` is the `href` and `part.title` the `title`. A part carries no
 * title of its own when the model did not supply one, in which case the host
 * of the URL is a better label than the whole of it.
 */
import { type ReactNode } from 'react';
import { type PressableProps, type ViewProps } from 'react-native';
export interface SourcesProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** Controlled open state. */
    open?: boolean;
    /** Initial state when uncontrolled. Folded, which is where a citation list belongs. */
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    children?: ReactNode;
}
declare function SourcesRoot({ className, open: openProp, defaultOpen, onOpenChange, children, ...props }: SourcesProps): import("react").JSX.Element;
declare namespace SourcesRoot {
    var displayName: string;
}
export interface SourcesTriggerProps extends Omit<PressableProps, 'children' | 'style'> {
    className?: string;
    /** How many sources the list holds. Reads "Used 6 sources". */
    count?: number;
    /** Replaces the whole row. */
    children?: ReactNode;
}
declare function SourcesTrigger({ className, count, children, onPress, ...props }: SourcesTriggerProps): import("react").JSX.Element;
declare namespace SourcesTrigger {
    var displayName: string;
}
export interface SourcesContentProps extends Omit<ViewProps, 'children'> {
    className?: string;
    children?: ReactNode;
}
declare function SourcesContent({ className, children, ...props }: SourcesContentProps): import("react").JSX.Element;
declare namespace SourcesContent {
    var displayName: string;
}
export interface SourcesSourceProps extends Omit<PressableProps, 'children' | 'style'> {
    className?: string;
    /** Where the row goes. Opened with the platform's own handler. */
    href?: string;
    /**
     * What the row says. Falls back to the URL's host, which is a better label
     * than a hundred characters of path — and models often send no title at all.
     */
    title?: string;
    /** Leading glyph. A link by default; a favicon suits a real citation list. */
    icon?: ReactNode;
    children?: ReactNode;
}
/** One citation. */
declare function SourcesSource({ className, href, title, icon, children, onPress, ...props }: SourcesSourceProps): import("react").JSX.Element;
declare namespace SourcesSource {
    var displayName: string;
}
export declare const Sources: typeof SourcesRoot & {
    Trigger: typeof SourcesTrigger;
    Content: typeof SourcesContent;
    Source: typeof SourcesSource;
};
export {};
//# sourceMappingURL=index.d.ts.map