import { type VariantProps } from 'tailwind-variants';
declare const spinnerVariants: import("tailwind-variants").TVReturnType<{
    size: {
        sm: "h-4 w-4";
        md: "h-6 w-6";
        lg: "h-8 w-8 border-[3px]";
    };
}, undefined, "rounded-full border-2 border-muted border-t-primary", {
    size: {
        sm: "h-4 w-4";
        md: "h-6 w-6";
        lg: "h-8 w-8 border-[3px]";
    };
}, undefined, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        sm: "h-4 w-4";
        md: "h-6 w-6";
        lg: "h-8 w-8 border-[3px]";
    };
}, undefined>>;
export interface SpinnerProps extends VariantProps<typeof spinnerVariants> {
    className?: string;
    /**
     * What is loading, for a screen reader. Setting it makes the spinner
     * announce as a busy status; leaving it unset keeps it out of the
     * accessibility tree.
     *
     * Leave it unset wherever something around the spinner already says the
     * wait is on — a loading button, a row with its own caption. Set it where
     * the spinner is the only sign, or the wait passes in silence.
     */
    label?: string;
    /**
     * The colour of the turning arc. Any colour React Native accepts — a hex
     * string, `rgb()`, a named colour. Leave it unset to follow the theme's
     * primary colour.
     *
     * Set it where the spinner sits on a surface the theme did not choose for
     * it: a spinner on a filled button, or over a photo, wants the colour of the
     * text around it rather than the accent.
     */
    color?: string;
    /**
     * The colour of the faint ring the arc turns around. Leave it unset for the
     * theme's muted colour. Worth setting alongside `color` on a dark or
     * coloured surface, where the default ring can read as a second, fainter
     * spinner rather than as a track.
     */
    trackColor?: string;
}
/**
 * Rotating ring for work of unknown length. The animation runs entirely on the
 * UI thread.
 *
 * A bare ring carries no words, so it is hidden from assistive technology
 * unless `label` is given — an unnamed progress indicator announces its role
 * and nothing else, which is noise standing in for information.
 *
 * Under the platform's reduce-motion setting the ring stops turning and fades
 * in place instead. Stopping it dead is the other option and it is the wrong
 * one: a spinner that holds still reads as one that has hung, which is the
 * single thing a spinner exists to rule out. Reduce motion asks for less
 * travel, not for less news.
 */
export declare const Spinner: import("react").MemoExoticComponent<({ className, size, label, color, trackColor, }: SpinnerProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=index.d.ts.map