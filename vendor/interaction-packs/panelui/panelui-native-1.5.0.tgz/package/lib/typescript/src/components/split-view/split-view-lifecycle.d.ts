interface SplitViewIndexLifecycleOptions {
    snapIndex: number | undefined;
    defaultSnapIndex: number;
    count: number;
    onSnapIndexChange?: (index: number) => void;
}
/** Keeps requested indices intact until the measured snap-point list exists. */
export declare function useSplitViewIndexLifecycle({ snapIndex, defaultSnapIndex, count, onSnapIndexChange, }: SplitViewIndexLifecycleOptions): {
    index: number;
    requestIndex: (next: number) => void;
    requestToken: number;
};
export {};
//# sourceMappingURL=split-view-lifecycle.d.ts.map