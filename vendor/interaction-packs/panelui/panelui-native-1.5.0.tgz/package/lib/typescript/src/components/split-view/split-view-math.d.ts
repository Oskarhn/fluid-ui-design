/**
 * The arithmetic a split view runs while its seam is under a finger.
 *
 * A split view differs from a free-resize splitter in one way that decides the
 * whole of this file: it does not stop wherever the finger stopped. It settles
 * on one of a few heights the caller named, so the numbers a drag produces are
 * only ever on the way to one of those — and picking which one, from a position
 * and the speed it arrived at, is the part with the edge cases.
 *
 * It lives apart from the component because it runs on the UI thread, where a
 * wrong answer is a pane that sticks rather than an exception anybody sees.
 */
/** Smallest top pane, in points, when the caller names none. */
export declare const DEFAULT_MIN_HEIGHT = 100;
/** Where the panes sit when the caller names no snap points, as ratios. */
export declare const DEFAULT_SNAP_POINTS: readonly [0.2, 0.5, 0.8];
export declare function clamp(value: number, low: number, high: number): number;
/**
 * One length, in points, from the two ways of writing it.
 *
 * A number at or below 1 is a fraction of the room the panes share, which is
 * what survives a rotation: half is half at any screen size. Anything larger is
 * already points. A negative number is measured back from the far edge, for the
 * case that is always written as a subtraction — "everything but the last 80".
 */
export declare function resolveLength(value: number | undefined, room: number, fallback: number): number;
/**
 * The heights a seam may settle at, in points, in order and without repeats.
 *
 * Every point is clamped into the range the panes are allowed, which is what
 * lets a caller name ratios without also checking them against a minimum they
 * did not choose. Two points that clamp onto each other become one, because a
 * list with the same height twice makes a flick land on a snap that looks like
 * it did nothing.
 */
export declare function resolveSnapPoints(points: readonly number[] | undefined, room: number, minPx: number, maxPx: number): number[];
/**
 * Which snap point a release belongs to.
 *
 * The height it is measured against is where the pane is plus where the throw
 * was going, so a fast flick carries past a midpoint the finger never crossed —
 * the difference between a control that follows a gesture and one that merely
 * records where it ended.
 *
 * The result is then held to one point either side of where the pane actually
 * is. Capping the distance is not enough on its own: the same throw skips two
 * points in a list packed close together and none in a list spread wide, so the
 * guarantee has to be made in points rather than in pixels. A release that
 * lands two snaps from where it was aimed reads as the control guessing.
 */
export declare function nearestSnapIndex(height: number, points: readonly number[], velocity: number, room: number): number;
/** The index a caller asked to start at, kept inside the list that exists. */
export declare function normalizeSnapIndex(index: number | undefined, length: number): number;
//# sourceMappingURL=split-view-math.d.ts.map