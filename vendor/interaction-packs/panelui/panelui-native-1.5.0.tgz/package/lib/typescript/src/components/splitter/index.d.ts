import { type ViewProps } from 'react-native';
export type SplitterOrientation = 'horizontal' | 'vertical';
export interface SplitterProps extends ViewProps {
    className?: string;
    /** Which way the panes are laid out. Defaults to `horizontal`. */
    orientation?: SplitterOrientation;
    /**
     * Controlled layout, as one percentage per panel. Pair it with
     * `onLayoutChange`: a seam that is let go snaps back to this unless the value
     * moves with it.
     */
    layout?: number[];
    /**
     * Starting layout when uncontrolled, as one percentage per panel. Panels left
     * out of it fall back to their own `defaultSize`, and then to an even share.
     */
    defaultLayout?: number[];
    /** Called with the new layout once a seam is let go, or stepped. */
    onLayoutChange?: (layout: number[]) => void;
    /** Freezes every seam. */
    disabled?: boolean;
    /** How far one accessibility step moves a seam, in percent. Defaults to `5`. */
    step?: number;
}
declare function SplitterRoot({ className, orientation, layout: layoutProp, defaultLayout, onLayoutChange, disabled, step, children, onLayout, ...props }: SplitterProps): import("react").JSX.Element;
declare namespace SplitterRoot {
    var displayName: string;
}
export interface SplitterPanelProps extends ViewProps {
    className?: string;
    /** Starting share of the splitter, in percent. Unsized panes split the rest. */
    defaultSize?: number;
    /** Smallest share this pane may hold while open, in percent. Defaults to `10`. */
    minSize?: number;
    /** Largest share this pane may hold, in percent. Defaults to `100`. */
    maxSize?: number;
    /** Lets a drag past `minSize` shut the pane rather than stopping at it. */
    collapsible?: boolean;
    /** Share this pane holds while shut, in percent. Defaults to `0`. */
    collapsedSize?: number;
}
/**
 * One pane.
 *
 * It clips what is inside it, so a pane dragged narrower hides its content
 * rather than pushing it into the pane beside it.
 */
declare function SplitterPanel({ className, children, style, ...props }: SplitterPanelProps): import("react").JSX.Element;
declare namespace SplitterPanel {
    var displayName: string;
}
export interface SplitterHandleProps extends ViewProps {
    className?: string;
    /** Freezes this seam on its own, leaving the others draggable. */
    disabled?: boolean;
    /** Draws the grip in the middle of the seam. Defaults to `true`. */
    withGrip?: boolean;
    /** What a screen reader calls the seam. Defaults to "Resize panels". */
    accessibilityLabel?: string;
}
/**
 * The seam between two panes.
 *
 * Put one between each pair. It is `adjustable` to a screen reader, so the
 * layout can be moved a step at a time without a drag, and a double tap puts
 * the pair back where it started — the fastest way out of a pane dragged shut
 * by accident.
 */
declare function SplitterHandle({ className, disabled, withGrip, accessibilityLabel, style, ...props }: SplitterHandleProps): import("react").JSX.Element;
declare namespace SplitterHandle {
    var displayName: string;
}
export declare const Splitter: typeof SplitterRoot & {
    Panel: typeof SplitterPanel;
    Handle: typeof SplitterHandle;
};
export { DEFAULT_MAX_SIZE, DEFAULT_MIN_SIZE, isCollapsed, layoutOffset, normalizeConstraint, panelFloor, resetLayout, resizeLayout, resolveLayout, type SplitterConstraint, type SplitterConstraintInput, } from './splitter-math.js';
//# sourceMappingURL=index.d.ts.map