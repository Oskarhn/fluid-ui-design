/**
 * The arithmetic a splitter runs while a seam is under a finger.
 *
 * Sizes are percentages of the whole splitter, never points, which is what
 * makes a dragged layout survive a rotation or a window resize: the numbers
 * mean the same thing at any container size, so nothing has to be re-measured
 * and re-derived when one changes.
 *
 * It lives apart from the component for two reasons. It is the part with the
 * edge cases — a pair of panels that cannot both honour their minimums, a
 * collapse that has to decide between shut and its floor, a caller's sizes that
 * do not add up — and it is the part that runs on the UI thread, where a wrong
 * answer is a layout that sticks rather than an exception anybody sees.
 */
/** How small a panel may get before its neighbour stops taking room, in percent. */
export declare const DEFAULT_MIN_SIZE = 10;
/** How large a panel may get, in percent. */
export declare const DEFAULT_MAX_SIZE = 100;
export interface SplitterConstraint {
    /** Smallest share the panel may hold while open, in percent. */
    minSize: number;
    /** Largest share the panel may hold, in percent. */
    maxSize: number;
    /** Whether dragging past the minimum shuts the panel instead of stopping. */
    collapsible: boolean;
    /** Share the panel holds while shut, in percent. */
    collapsedSize: number;
}
export interface SplitterConstraintInput {
    minSize?: number;
    maxSize?: number;
    collapsible?: boolean;
    collapsedSize?: number;
}
/** The smallest share a panel can hold at all — its floor once shut, or its minimum. */
export declare function panelFloor(constraint: SplitterConstraint): number;
/**
 * Fills a panel's declared limits in, in an order that cannot contradict
 * itself: the maximum is never below the minimum, and a collapsed size is never
 * above the minimum it exists to sit below.
 */
export declare function normalizeConstraint(input: SplitterConstraintInput | undefined): SplitterConstraint;
/**
 * Turns whatever sizes a caller gave into one layout that adds up.
 *
 * Panels with no size of their own split what the sized ones left over, so a
 * three-pane splitter that only pins its sidebar gets the sensible reading of
 * that: the sidebar keeps its number and the other two share the rest.
 */
export declare function resolveLayout(sizes: (number | undefined)[], constraints: SplitterConstraint[]): number[];
/**
 * Moves one seam, in percent, and hands back the whole layout.
 *
 * Only the two panels either side of the seam change: a drag borrows from its
 * neighbour and nobody else, so the panels further along stay exactly where the
 * reader left them.
 *
 * Collapsing is only ever offered to the panel being shrunk. Both sides could
 * technically be past their minimum at once at the end of a long drag, and
 * shutting the panel that is currently growing is never what the drag meant.
 */
export declare function resizeLayout(layout: number[], boundary: number, delta: number, constraints: SplitterConstraint[]): number[];
/** Restores one pair's initial ratio without escaping its current constraints. */
export declare function resetLayout(layout: number[], initial: number[], boundary: number, constraints: SplitterConstraint[]): number[];
/** Where a seam sits, in percent, measured from the start of the splitter. */
export declare function layoutOffset(layout: number[], boundary: number): number;
/** Whether a panel is currently shut rather than merely small. */
export declare function isCollapsed(size: number, constraint: SplitterConstraint): boolean;
//# sourceMappingURL=splitter-math.d.ts.map