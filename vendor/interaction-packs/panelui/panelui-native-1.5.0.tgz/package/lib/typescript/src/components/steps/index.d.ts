/**
 * Steps — a stepper for multi-step flows.
 *
 * A row or column of numbered stops, each one completed, active, inactive or
 * loading. An item works that state out from its own position against the
 * root's `value` rather than being told it, so the four states stay mutually
 * exclusive and in order — there is no way to write two active steps, or to
 * mark step four done while step three is still pending.
 *
 * The state is resolved in JS and passed down through context into `tv()`
 * variants, because React Native has no attribute selectors a stylesheet could
 * key off. Alert and Timeline resolve their states the same way.
 *
 * Steps does not own your flow: it reflects whatever step your app says is
 * active. Pass `value` to control it, or `defaultValue` to let it manage
 * its own.
 *
 * The connectors are the component's job, not yours. The root counts the items
 * it holds and each one draws the connector to the next, so a stepper is just
 * its steps — there is no separator to forget, mis-order, or leave dangling
 * past the last stop. An item that contains its own `Steps.Separator` keeps it
 * and gets no second one, so hand-placed connectors still work; `separators`
 * turns the automatic ones off wholesale.
 *
 * Knowing the count is also what lets a step say where it sits. A screen reader
 * reaching the middle of a wizard hears "Payment, step 2 of 3, completed" —
 * the position and the state, which are the two things the circle and its fill
 * convey to everyone else.
 */
import { type ReactNode } from 'react';
import { type PressableProps, type ViewProps } from 'react-native';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
export type StepState = 'active' | 'completed' | 'inactive' | 'loading';
export type StepsOrientation = 'horizontal' | 'vertical';
export interface StepsProps extends ViewProps {
    className?: string;
    /** Active step when uncontrolled. */
    defaultValue?: number;
    /** Active step, controlled. */
    value?: number;
    onValueChange?: (value: number) => void;
    orientation?: StepsOrientation;
    /**
     * Draw the connector between one item and the next. On by default — an item
     * that holds its own `Steps.Separator` is left alone either way, so this is
     * for a stepper that wants no connectors at all rather than for one that
     * places them by hand.
     */
    separators?: boolean;
    children?: ReactNode;
}
export interface StepsItemProps extends ViewProps {
    className?: string;
    /** This item's position in the flow, zero-based by convention. */
    step: number;
    /** Force the completed state, regardless of the active step. */
    completed?: boolean;
    disabled?: boolean;
    /** Shows a spinner in place of the number while this step is active. */
    loading?: boolean;
    children?: ReactNode;
}
export interface StepsTriggerProps extends PressableProps {
    className?: string;
    children?: ReactNode;
}
export interface StepsIndicatorProps extends ViewProps {
    className?: string;
    /** Replaces the number / check / spinner entirely. */
    children?: ReactNode;
}
export interface StepsSeparatorProps extends ViewProps {
    className?: string;
}
export declare const Steps: import("react").ForwardRefExoticComponent<StepsProps & import("react").RefAttributes<ViewRef>> & {
    Item: import("react").ForwardRefExoticComponent<StepsItemProps & import("react").RefAttributes<ViewRef>>;
    Trigger: import("react").ForwardRefExoticComponent<StepsTriggerProps & import("react").RefAttributes<ViewRef>>;
    Indicator: import("react").ForwardRefExoticComponent<StepsIndicatorProps & import("react").RefAttributes<ViewRef>>;
    Title: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Description: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Separator: import("react").ForwardRefExoticComponent<StepsSeparatorProps & import("react").RefAttributes<ViewRef>>;
};
//# sourceMappingURL=index.d.ts.map