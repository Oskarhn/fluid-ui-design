export declare function stepsTriggerDisabled(itemDisabled: boolean, triggerDisabled: boolean | null | undefined): boolean;
//# sourceMappingURL=steps-trigger.d.ts.map