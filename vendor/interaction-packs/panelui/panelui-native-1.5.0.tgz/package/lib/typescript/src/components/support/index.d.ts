/**
 * Support — the screen a person arrives on when they need help.
 *
 * It is the front of a support section, not the conversation itself. What a
 * reader needs here is four answers, in this order: is anyone there, how do I
 * reach them, what is this about, and what happened to the thing I already
 * asked. Each is a part, because an app that has no help centre should not
 * have to pass `articles={null}` to say so.
 *
 * The transcript is deliberately somewhere else. A support thread is a chat
 * transcript with a name on it, and this library already has the pieces —
 * compose `MessageScroller`, `Message` and `AIInput` behind whichever channel
 * the reader picks, rather than growing a second set of bubbles in here that
 * would drift away from the first.
 *
 * `availability` is the one thing the root decides, and everything downstream
 * reads it from context: the dot beside the status line, the wording it falls
 * back to, and whether a channel that needs someone at the other end presents
 * itself as open.
 *
 * ```tsx
 * <Support availability="online">
 *   <Support.Header title="Support" />
 *   <Support.Status replyTime="Typically replies in under an hour" />
 *   <Support.Channels>
 *     <Support.Channel icon={<MessageCircleIcon />} label="Message us" />
 *   </Support.Channels>
 * </Support>
 * ```
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
/** Whether anyone is at the other end. */
export type SupportAvailability = 'online' | 'away' | 'offline';
/**
 * Where a request has got to, in the words the person who made it sees.
 *
 * Shorter than the set a support desk runs internally, and deliberately: the
 * states a helpdesk distinguishes for its own routing are not distinctions the
 * person waiting can act on, and offering them invites a question about the
 * difference that nobody wants to answer.
 */
export type SupportConversationStatus = 'open' | 'pending' | 'solved' | 'closed';
declare const supportVariants: import("tailwind-variants").TVReturnType<{
    availability: {
        online: {
            statusDot: string;
        };
        away: {
            statusDot: string;
        };
        offline: {
            statusDot: string;
        };
    };
    selected: {
        true: {
            topic: string;
        };
        false: {
            topic: string;
        };
    };
    disabled: {
        true: {
            channel: string;
            topic: string;
        };
    };
}, {
    root: string;
    header: string;
    headerText: string;
    status: string;
    statusDot: string;
    group: string;
    groupTitle: string;
    channel: string;
    channelIcon: string;
    channelText: string;
    topic: string;
    topicText: string;
    conversation: string;
    article: string;
    badge: string;
    agent: string;
    ticket: string;
    note: string;
    handoff: string;
    replies: string;
    reply: string;
    resolution: string;
}, undefined, {
    availability: {
        online: {
            statusDot: string;
        };
        away: {
            statusDot: string;
        };
        offline: {
            statusDot: string;
        };
    };
    selected: {
        true: {
            topic: string;
        };
        false: {
            topic: string;
        };
    };
    disabled: {
        true: {
            channel: string;
            topic: string;
        };
    };
}, {
    root: string;
    header: string;
    headerText: string;
    status: string;
    statusDot: string;
    group: string;
    groupTitle: string;
    channel: string;
    channelIcon: string;
    channelText: string;
    topic: string;
    topicText: string;
    conversation: string;
    article: string;
    badge: string;
    agent: string;
    ticket: string;
    note: string;
    handoff: string;
    replies: string;
    reply: string;
    resolution: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    availability: {
        online: {
            statusDot: string;
        };
        away: {
            statusDot: string;
        };
        offline: {
            statusDot: string;
        };
    };
    selected: {
        true: {
            topic: string;
        };
        false: {
            topic: string;
        };
    };
    disabled: {
        true: {
            channel: string;
            topic: string;
        };
    };
}, {
    root: string;
    header: string;
    headerText: string;
    status: string;
    statusDot: string;
    group: string;
    groupTitle: string;
    channel: string;
    channelIcon: string;
    channelText: string;
    topic: string;
    topicText: string;
    conversation: string;
    article: string;
    badge: string;
    agent: string;
    ticket: string;
    note: string;
    handoff: string;
    replies: string;
    reply: string;
    resolution: string;
}>>;
interface SupportContextValue {
    availability: SupportAvailability;
}
/** The availability set by the nearest Support. */
export declare function useSupport(): SupportContextValue;
export interface SupportProps extends ViewProps {
    className?: string;
    /**
     * Whether anyone is at the other end. Read by every part below rather than
     * passed to each — a screen that is half "we're here" and half "we're not"
     * is worse than either.
     */
    availability?: SupportAvailability;
    children?: ReactNode;
}
export interface SupportHeaderProps extends ViewProps {
    className?: string;
    /** The screen's own name. */
    title?: string;
    /** One line under it — who answers, or what this section covers. */
    description?: string;
    /** Trailing slot: the faces of the people who answer, or a close button. */
    children?: ReactNode;
}
export interface SupportStatusProps extends ViewProps {
    className?: string;
    /** Overrides the availability the root published. */
    availability?: SupportAvailability;
    /**
     * How long a reply takes, in your own words — "Typically replies in under an
     * hour", "Back on Monday". Left unset, the availability alone is stated.
     *
     * A string rather than a number of minutes, because the honest version of
     * this is a median somebody measured and the rounding is a judgement about
     * tone: "a few minutes" and "4 minutes" promise different things.
     */
    replyTime?: string;
    children?: ReactNode;
}
export interface SupportGroupProps extends ViewProps {
    className?: string;
    /** Small heading above the rows. */
    title?: string;
    children?: ReactNode;
}
export interface SupportChannelProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** The glyph on the left. Tinted to match the row. */
    icon?: ReactNode;
    /** What the channel is called — the thing pressed, so write it as an action. */
    label: string;
    /** One line under it: what it is for, or the address behind it. */
    description?: string;
    /** Trailing note — a wait time, an opening hour. */
    detail?: string;
    disabled?: boolean;
    onPress?: () => void;
}
export interface SupportTopicsProps extends ViewProps {
    className?: string;
    /** Small heading above the list. */
    title?: string;
    /** The selected topic. Leave unset to let the group track it. */
    value?: string | null;
    /** The topic selected before anybody pressed anything. */
    defaultValue?: string | null;
    onValueChange?: (value: string) => void;
    children?: ReactNode;
}
export interface SupportTopicProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** What this topic is worth to the group's `value`. */
    value: string;
    icon?: ReactNode;
    label: string;
    /** One line of what belongs under it, for the ones whose name is not enough. */
    description?: string;
    disabled?: boolean;
    onPress?: () => void;
}
export interface SupportConversationProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** What it was about. */
    title: string;
    /** The last thing said in it. */
    preview?: string;
    /** Where it has got to. */
    status?: SupportConversationStatus;
    /** When it last moved, in your own words — "2h", "Yesterday". */
    timestamp?: string;
    /**
     * There is a reply here the reader has not seen.
     *
     * Separate from `updated`, because they are different facts: a thread can
     * move without anything being addressed to you, and a dot that means both
     * means neither.
     */
    unread?: boolean;
    /** The thread moved since it was last opened, with nothing new to read. */
    updated?: boolean;
    /** Reference for the request, shown beside the status. */
    reference?: string;
    onPress?: () => void;
}
export interface SupportArticleProps extends Omit<ViewProps, 'children'> {
    className?: string;
    icon?: ReactNode;
    /** The article's own title. */
    title: string;
    /** Which part of the help centre it came from. */
    collection?: string;
    onPress?: () => void;
}
export interface SupportAgentProps extends Omit<ViewProps, 'children' | 'role'> {
    className?: string;
    /** Slot for the avatar. */
    avatar?: ReactNode;
    /** Who is answering. */
    name: string;
    /** What they are — "Support", "Billing team", "Assistant". */
    role?: string;
    /** Overrides the availability the root published. */
    availability?: SupportAvailability;
    /** They are writing a reply right now. */
    typing?: boolean;
}
export interface SupportTicketProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** Reference for the request, as the reader sees it. */
    reference?: string;
    /** What it was about. */
    subject?: string;
    status?: SupportConversationStatus;
}
export interface SupportHandoffProps extends ViewProps {
    className?: string;
    icon?: ReactNode;
    children?: ReactNode;
}
export interface SupportNoteProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface SupportRepliesProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface SupportReplyProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** What pressing it sends. Defaults to the label. */
    value?: string;
    label: string;
    disabled?: boolean;
    onPress?: (value: string) => void;
}
export interface SupportResolutionProps extends ViewProps {
    className?: string;
    /** The question asked. */
    title?: string;
    /** Slot for the control that takes the answer — a Rating, two buttons. */
    children?: ReactNode;
}
export declare const Support: import("react").ForwardRefExoticComponent<SupportProps & import("react").RefAttributes<ViewRef>> & {
    Header: import("react").ForwardRefExoticComponent<SupportHeaderProps & import("react").RefAttributes<ViewRef>>;
    Status: import("react").ForwardRefExoticComponent<SupportStatusProps & import("react").RefAttributes<ViewRef>>;
    Channels: import("react").ForwardRefExoticComponent<SupportGroupProps & import("react").RefAttributes<ViewRef>>;
    Channel: import("react").ForwardRefExoticComponent<SupportChannelProps & import("react").RefAttributes<ViewRef>>;
    Topics: import("react").ForwardRefExoticComponent<SupportTopicsProps & import("react").RefAttributes<ViewRef>>;
    Topic: import("react").ForwardRefExoticComponent<SupportTopicProps & import("react").RefAttributes<ViewRef>>;
    Conversations: import("react").ForwardRefExoticComponent<SupportGroupProps & import("react").RefAttributes<ViewRef>>;
    Conversation: import("react").ForwardRefExoticComponent<SupportConversationProps & import("react").RefAttributes<ViewRef>>;
    Articles: import("react").ForwardRefExoticComponent<SupportGroupProps & import("react").RefAttributes<ViewRef>>;
    Article: import("react").ForwardRefExoticComponent<SupportArticleProps & import("react").RefAttributes<ViewRef>>;
    Agent: import("react").ForwardRefExoticComponent<SupportAgentProps & import("react").RefAttributes<ViewRef>>;
    Ticket: import("react").ForwardRefExoticComponent<SupportTicketProps & import("react").RefAttributes<ViewRef>>;
    Handoff: import("react").ForwardRefExoticComponent<SupportHandoffProps & import("react").RefAttributes<ViewRef>>;
    Note: import("react").ForwardRefExoticComponent<SupportNoteProps & import("react").RefAttributes<ViewRef>>;
    Replies: import("react").ForwardRefExoticComponent<SupportRepliesProps & import("react").RefAttributes<ViewRef>>;
    Reply: import("react").ForwardRefExoticComponent<SupportReplyProps & import("react").RefAttributes<ViewRef>>;
    Resolution: import("react").ForwardRefExoticComponent<SupportResolutionProps & import("react").RefAttributes<ViewRef>>;
};
export type SupportVariants = VariantProps<typeof supportVariants>;
export {};
//# sourceMappingURL=index.d.ts.map