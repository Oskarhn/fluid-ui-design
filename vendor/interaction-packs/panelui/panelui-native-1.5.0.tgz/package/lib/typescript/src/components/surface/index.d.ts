import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
declare const surfaceVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        default: "bg-surface";
        secondary: "bg-surface-secondary";
        tertiary: "bg-surface-tertiary";
        transparent: "bg-transparent";
    };
    padding: {
        none: "";
        sm: "p-2.5";
        default: "p-4";
        lg: "p-6";
    };
    bordered: {
        true: "border border-border";
    };
    elevated: {
        true: "shadow-sm";
    };
}, undefined, "overflow-hidden rounded-3xl", {
    variant: {
        default: "bg-surface";
        secondary: "bg-surface-secondary";
        tertiary: "bg-surface-tertiary";
        transparent: "bg-transparent";
    };
    padding: {
        none: "";
        sm: "p-2.5";
        default: "p-4";
        lg: "p-6";
    };
    bordered: {
        true: "border border-border";
    };
    elevated: {
        true: "shadow-sm";
    };
}, undefined, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        default: "bg-surface";
        secondary: "bg-surface-secondary";
        tertiary: "bg-surface-tertiary";
        transparent: "bg-transparent";
    };
    padding: {
        none: "";
        sm: "p-2.5";
        default: "p-4";
        lg: "p-6";
    };
    bordered: {
        true: "border border-border";
    };
    elevated: {
        true: "shadow-sm";
    };
}, undefined>>;
export interface SurfaceProps extends ViewProps, VariantProps<typeof surfaceVariants> {
    className?: string;
    /**
     * A hairline border. A surface the same colour as what it sits on needs one
     * to read as a distinct plane rather than dissolving into the background.
     */
    bordered?: boolean;
    /**
     * A soft shadow lifting the surface off the page. Off by default because a
     * nested surface reads its depth from its fill, not from a shadow it would
     * only cast onto its parent.
     */
    elevated?: boolean;
    /** Inner spacing. `none` is for a surface wrapping a bled image or a chart. */
    padding?: 'none' | 'sm' | 'default' | 'lg';
}
export declare const Surface: import("react").ForwardRefExoticComponent<SurfaceProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map