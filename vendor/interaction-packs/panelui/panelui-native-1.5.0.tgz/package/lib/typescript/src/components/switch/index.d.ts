import { type PressableProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { ViewRef } from '../../primitives/refs.js';
declare const switchVariants: import("tailwind-variants").TVReturnType<{
    size: {
        xs: {
            track: string;
            thumb: string;
        };
        sm: {
            track: string;
            thumb: string;
        };
        md: {
            track: string;
            thumb: string;
        };
        lg: {
            track: string;
            thumb: string;
        };
        xl: {
            track: string;
            thumb: string;
        };
    };
    disabled: {
        true: {
            track: string;
        };
    };
}, {
    track: string;
    activeTrack: string;
    thumb: string;
}, undefined, {
    size: {
        xs: {
            track: string;
            thumb: string;
        };
        sm: {
            track: string;
            thumb: string;
        };
        md: {
            track: string;
            thumb: string;
        };
        lg: {
            track: string;
            thumb: string;
        };
        xl: {
            track: string;
            thumb: string;
        };
    };
    disabled: {
        true: {
            track: string;
        };
    };
}, {
    track: string;
    activeTrack: string;
    thumb: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        xs: {
            track: string;
            thumb: string;
        };
        sm: {
            track: string;
            thumb: string;
        };
        md: {
            track: string;
            thumb: string;
        };
        lg: {
            track: string;
            thumb: string;
        };
        xl: {
            track: string;
            thumb: string;
        };
    };
    disabled: {
        true: {
            track: string;
        };
    };
}, {
    track: string;
    activeTrack: string;
    thumb: string;
}>>;
/** How big a switch is. */
export type SwitchSize = NonNullable<VariantProps<typeof switchVariants>['size']>;
export interface SwitchProps extends VariantProps<typeof switchVariants>, Pick<PressableProps, 'accessibilityLabel' | 'accessibilityHint' | 'accessibilityLabelledBy'> {
    className?: string;
    value: boolean;
    onValueChange?: (value: boolean) => void;
    disabled?: boolean;
    /**
     * Render the platform's own switch instead of this one. Requires the
     * optional `@expo/ui` package; without it this prop does nothing.
     *
     * **Theme tokens do not apply** — the platform draws the control, so
     * `className` and `size` are ignored.
     */
    native?: boolean;
    /** Names the control to assistive technology; native mode also draws it. */
    label?: string;
    /**
     * Tick the haptic engine each time the switch is flipped — a toggle you feel
     * click rather than one that merely slides. Needs the optional
     * `expo-haptics`, and is silent without it. Ignored in `native` mode, where
     * the platform control owns its own feedback.
     */
    haptics?: boolean;
    /**
     * Set to `false` to draw only the track, with no press and no role of its
     * own. Use it when a whole row is the switch: the row is the one
     * `Pressable` with `accessibilityRole="switch"`, and a second switch inside
     * it would be announced twice and take two Tab stops.
     */
    interactive?: boolean;
}
export declare const Switch: import("react").ForwardRefExoticComponent<SwitchProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map