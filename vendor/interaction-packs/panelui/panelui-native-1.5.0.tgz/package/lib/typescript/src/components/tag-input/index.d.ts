/**
 * TagInput — a field whose value is a list of tokens rather than a string.
 *
 * The value is whatever gets typed. That is the whole distinction from a
 * `Combobox` in `multiple` mode: a Combobox picks from a set of options you
 * supply, so it needs a list, a filter and a surface to float that list on. A
 * tag field has no options and no list — labels on a task, recipients on a
 * message, keywords on a post — so it carries none of that machinery and never
 * opens a portal.
 *
 * ```tsx
 * <TagInput
 *   label="Topics"
 *   defaultValue={['expo', 'reanimated']}
 *   placeholder="Add a topic"
 * />
 * ```
 *
 * ## Three ways a tag gets committed
 *
 * Return commits what has been typed. So does any of `delimiters` — a comma by
 * default — which is what makes pasting `design, research, ops` land as three
 * tags instead of one long one. And `blurBehavior` decides what a field that
 * loses focus mid-word does with the leftover.
 *
 * ## Backspace asks first
 *
 * Backspace on an empty field marks the last tag rather than taking it: the
 * tag turns destructive, and a second backspace removes it. A held backspace
 * repeats, and a field that deleted on the first one would empty itself in the
 * time it takes to notice — the mark is the beat that lets you stop.
 */
import { type ReactNode } from 'react';
import { type TextInputProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type ChipVariant } from '../chip/index.js';
import type { TextInputRef } from '../../primitives/refs.js';
declare const tagInputVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        outline: {
            field: string;
        };
        filled: {
            field: string;
        };
    };
    size: {
        sm: {
            field: string;
            input: string;
            clear: string;
        };
        md: {
            field: string;
            input: string;
            clear: string;
        };
        lg: {
            field: string;
            input: string;
            clear: string;
        };
    };
    disabled: {
        true: {
            field: string;
        };
    };
}, {
    container: string;
    field: string;
    input: string;
    clear: string;
    description: string;
    error: string;
    count: string;
}, undefined, {
    variant: {
        outline: {
            field: string;
        };
        filled: {
            field: string;
        };
    };
    size: {
        sm: {
            field: string;
            input: string;
            clear: string;
        };
        md: {
            field: string;
            input: string;
            clear: string;
        };
        lg: {
            field: string;
            input: string;
            clear: string;
        };
    };
    disabled: {
        true: {
            field: string;
        };
    };
}, {
    container: string;
    field: string;
    input: string;
    clear: string;
    description: string;
    error: string;
    count: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        outline: {
            field: string;
        };
        filled: {
            field: string;
        };
    };
    size: {
        sm: {
            field: string;
            input: string;
            clear: string;
        };
        md: {
            field: string;
            input: string;
            clear: string;
        };
        lg: {
            field: string;
            input: string;
            clear: string;
        };
    };
    disabled: {
        true: {
            field: string;
        };
    };
}, {
    container: string;
    field: string;
    input: string;
    clear: string;
    description: string;
    error: string;
    count: string;
}>>;
type TagInputVariantProps = VariantProps<typeof tagInputVariants>;
export type TagInputVariant = NonNullable<TagInputVariantProps['variant']>;
export type TagInputSize = NonNullable<TagInputVariantProps['size']>;
/** Why a tag was turned away, for a caller that wants to say so. */
export type TagRejection = 'duplicate' | 'max' | 'invalid';
/** What a field that loses focus mid-word does with the leftover text. */
export type TagBlurBehavior = 'add' | 'clear' | 'keep';
export interface TagInputProps extends Omit<TextInputProps, 'value' | 'defaultValue' | 'onChangeText' | 'editable' | 'multiline' | 'children'>, Omit<TagInputVariantProps, 'disabled'> {
    /** Classes for the field box — the bordered container the tags sit in. */
    className?: string;
    /** Classes for the outer column that also holds the label and the error. */
    containerClassName?: string;
    /** The tags, controlled. Pair it with `onValueChange`. */
    value?: string[];
    /** The tags to start with, when the field keeps its own value. */
    defaultValue?: string[];
    /** Called with the whole list whenever a tag is added or removed. */
    onValueChange?: (tags: string[]) => void;
    /**
     * The text being typed, controlled. Only needed to drive the draft from
     * outside — the tags themselves are `value`.
     */
    inputValue?: string;
    /** Called as the draft text changes, before it becomes a tag. */
    onInputValueChange?: (text: string) => void;
    /** The label above the field, and what the input is announced as. */
    label?: string;
    /** A line under the field, replaced by `errorMessage` when there is one. */
    description?: string;
    /** Error message. When set, the field renders in its invalid state. */
    errorMessage?: string;
    /** Marks the field required — an asterisk on the label, and the a11y state. */
    isRequired?: boolean;
    /** Dims the field and stops it being reached at all. */
    disabled?: boolean;
    /** Shows the tags but takes away the input and the ✕ on each one. */
    readOnly?: boolean;
    /**
     * The most tags the field accepts. Past it nothing more is committed and
     * `onReject` is called with `'max'`, unless `allowOverflow` is set.
     */
    max?: number;
    /**
     * Let the list go past `max` anyway. The field reports itself invalid while
     * it is over, which is the point: some forms want the count shown as wrong
     * rather than the typing refused.
     */
    allowOverflow?: boolean;
    /** Accept a tag the list already holds. Off by default. */
    allowDuplicates?: boolean;
    /**
     * Characters that end a tag as they are typed. A comma by default, which is
     * what makes a pasted `a, b, c` land as three tags rather than one.
     */
    delimiters?: string[];
    /**
     * What happens to text still in the field when it loses focus. `add` commits
     * it and clears it if it was accepted, leaving it in place if it was not, so
     * a rejected word is still there to fix. `clear` drops it. `keep` leaves it
     * exactly as typed.
     */
    blurBehavior?: TagBlurBehavior;
    /**
     * Decide whether a tag may be added, given the list it would join. Return
     * `false` to turn it away — `onReject` is then called with `'invalid'`.
     */
    validate?: (tag: string, tags: string[]) => boolean;
    /** Called when a tag was turned away, with the reason it was. */
    onReject?: (tag: string, reason: TagRejection) => void;
    /** Which Chip variant the tags are drawn as. */
    chipVariant?: ChipVariant;
    /** Draw the tag yourself — an avatar before the label, a count after it. */
    renderTag?: (tag: string, index: number) => ReactNode;
    /** A ✕ at the end of the field that empties it. */
    clearable?: boolean;
    /** Shows `3 / 8` under the field. Needs `max`. */
    showCount?: boolean;
    /**
     * A tick under the finger as a tag lands or leaves. Off by default — needs
     * the optional `expo-haptics`, and is silent without it.
     */
    haptics?: boolean;
}
export declare const TagInput: import("react").ForwardRefExoticComponent<TagInputProps & import("react").RefAttributes<TextInputRef>>;
export {};
//# sourceMappingURL=index.d.ts.map