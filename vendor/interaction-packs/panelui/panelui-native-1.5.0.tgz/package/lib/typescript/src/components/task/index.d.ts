/**
 * Task — one step an agent took, and what it did while it was there.
 *
 * The header is the step; the body is the detail nobody reads unless something
 * went wrong. Open by default, because a task that is running is the thing the
 * reader is watching — and it stays open afterwards rather than folding itself
 * away, because unlike a reasoning trace the steps are the record of what
 * happened and are worth scrolling back through.
 *
 * ```tsx
 * <Task status="running">
 *   <Task.Trigger title="Searching the codebase" />
 *   <Task.Content>
 *     <Task.Item>
 *       Read <Task.File>calendar/index.tsx</Task.File>
 *     </Task.Item>
 *   </Task.Content>
 * </Task>
 * ```
 *
 * ## Where the props come from
 *
 * With the AI SDK a task is a tool-call part: `part.type` is `tool-<name>` and
 * `part.state` runs `input-streaming` → `input-available` → `output-available`
 * or `output-error`. Those map onto `status` as pending, running, complete and
 * error; `part.input` is usually what the body should say.
 */
import { type ReactNode } from 'react';
import { type PressableProps, type ViewProps } from 'react-native';
export type TaskStatus = 'pending' | 'running' | 'complete' | 'error';
export interface TaskProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /**
     * Where the step has got to. Drives the leading glyph, and puts a shimmer on
     * the title while it is `running`.
     */
    status?: TaskStatus;
    /** Controlled open state. */
    open?: boolean;
    /** Initial state when uncontrolled. Open — the steps are the record. */
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    children?: ReactNode;
}
declare function TaskRoot({ className, status, open: openProp, defaultOpen, onOpenChange, children, ...props }: TaskProps): import("react").JSX.Element;
declare namespace TaskRoot {
    var displayName: string;
}
export interface TaskTriggerProps extends Omit<PressableProps, 'children' | 'style'> {
    className?: string;
    /** What the step is. Shimmers while the status is `running`. */
    title?: string;
    /** Leading glyph. Derived from `status` when not given. */
    icon?: ReactNode;
    /** Replaces the whole row. */
    children?: ReactNode;
}
declare function TaskTrigger({ className, title, icon, children, onPress, ...props }: TaskTriggerProps): import("react").JSX.Element;
declare namespace TaskTrigger {
    var displayName: string;
}
export interface TaskContentProps extends Omit<ViewProps, 'children'> {
    className?: string;
    children?: ReactNode;
}
declare function TaskContent({ className, children, ...props }: TaskContentProps): import("react").JSX.Element;
declare namespace TaskContent {
    var displayName: string;
}
export interface TaskItemProps extends Omit<ViewProps, 'children'> {
    className?: string;
    children?: ReactNode;
}
/** One line of what the step did. */
declare function TaskItem({ className, children, ...props }: TaskItemProps): import("react").JSX.Element;
declare namespace TaskItem {
    var displayName: string;
}
export interface TaskFileProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** A glyph for the file's kind, drawn before the name. */
    icon?: ReactNode;
    children?: ReactNode;
}
/**
 * A filename inside a line, drawn as a chip.
 *
 * Bordered rather than merely monospaced, because a path in the middle of a
 * sentence is otherwise indistinguishable from the sentence — and the paths
 * are the part of a task line anyone actually scans for.
 */
declare function TaskFile({ className, icon, children, ...props }: TaskFileProps): import("react").JSX.Element;
declare namespace TaskFile {
    var displayName: string;
}
export declare const Task: typeof TaskRoot & {
    Trigger: typeof TaskTrigger;
    Content: typeof TaskContent;
    Item: typeof TaskItem;
    File: typeof TaskFile;
};
export {};
//# sourceMappingURL=index.d.ts.map