import { type TextInputProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import type { KeyboardAvoidanceMode } from '../../hooks/use-keyboard-avoidance.js';
import type { TextInputRef } from '../../primitives/refs.js';
declare const textareaVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        outline: {
            field: string;
        };
        filled: {
            field: string;
        };
    };
    size: {
        xs: {
            field: string;
        };
        sm: {
            field: string;
        };
        md: {
            field: string;
        };
        lg: {
            field: string;
        };
        xl: {
            field: string;
        };
    };
    disabled: {
        true: {
            field: string;
        };
    };
    /** Past the limit the counter is the error, so it is tinted like one. */
    over: {
        true: {
            count: string;
        };
    };
}, {
    container: string;
    field: string;
    footer: string;
    description: string;
    error: string;
    count: string;
}, undefined, {
    variant: {
        outline: {
            field: string;
        };
        filled: {
            field: string;
        };
    };
    size: {
        xs: {
            field: string;
        };
        sm: {
            field: string;
        };
        md: {
            field: string;
        };
        lg: {
            field: string;
        };
        xl: {
            field: string;
        };
    };
    disabled: {
        true: {
            field: string;
        };
    };
    /** Past the limit the counter is the error, so it is tinted like one. */
    over: {
        true: {
            count: string;
        };
    };
}, {
    container: string;
    field: string;
    footer: string;
    description: string;
    error: string;
    count: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        outline: {
            field: string;
        };
        filled: {
            field: string;
        };
    };
    size: {
        xs: {
            field: string;
        };
        sm: {
            field: string;
        };
        md: {
            field: string;
        };
        lg: {
            field: string;
        };
        xl: {
            field: string;
        };
    };
    disabled: {
        true: {
            field: string;
        };
    };
    /** Past the limit the counter is the error, so it is tinted like one. */
    over: {
        true: {
            count: string;
        };
    };
}, {
    container: string;
    field: string;
    footer: string;
    description: string;
    error: string;
    count: string;
}>>;
type TextareaVariantProps = VariantProps<typeof textareaVariants>;
export interface TextareaProps extends Omit<TextInputProps, 'multiline' | 'numberOfLines'>, Omit<TextareaVariantProps, 'disabled' | 'over'> {
    className?: string;
    containerClassName?: string;
    label?: string;
    description?: string;
    /** Error message. When set, the field renders in its invalid state. */
    errorMessage?: string;
    /** Marks the field required — an asterisk on the label, and the a11y state. */
    isRequired?: boolean;
    disabled?: boolean;
    /** How many lines of text the field is tall before it scrolls or grows. */
    rows?: number;
    /**
     * Grow with the text, one line at a time, up to `maxRows` — after which the
     * field holds its height and scrolls instead. Without it the field stays at
     * `rows` and scrolls from the first line past it.
     */
    autoGrow?: boolean;
    /** The tallest `autoGrow` will go. Ignored without it. */
    maxRows?: number;
    /**
     * Show how much of `maxLength` is used, under the field. Needs `maxLength`;
     * a counter with no limit to count towards says nothing.
     */
    showCount?: boolean;
    /**
     * Keep the field clear of the software keyboard. Moves by exactly the
     * overlap, and not at all when the field is already clear — or when the
     * keyboard belongs to a different field. The overlap is re-read every frame
     * while the field is focused, so the field keeps its place in the page as it
     * scrolls under and back out of the keyboard.
     *
     * Install `react-native-keyboard-controller` for this to behave on Android.
     *
     * Do not toggle this at runtime — it changes which component renders the
     * container, which would remount the field and drop focus.
     */
    avoidKeyboard?: boolean;
    /**
     * How the field gets clear. `lift` moves it up by its overlap and follows
     * the scroll — right for a field in the flow of a page. `dock` makes it
     * travel with the keyboard, for a composer already pinned near the bottom
     * edge; pair it with `keyboardBottomInset`.
     */
    keyboardMode?: KeyboardAvoidanceMode;
    /** Gap kept between the field and the keyboard. `keyboardMode="lift"` only. */
    keyboardOffset?: number;
    /**
     * How far above the bottom edge the field already sits — usually the safe
     * area inset. `keyboardMode="dock"` only.
     */
    keyboardBottomInset?: number;
}
export declare const Textarea: import("react").ForwardRefExoticComponent<TextareaProps & import("react").RefAttributes<TextInputRef>>;
export {};
//# sourceMappingURL=index.d.ts.map