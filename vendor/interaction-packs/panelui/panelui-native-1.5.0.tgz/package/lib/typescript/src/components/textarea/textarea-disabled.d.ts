export declare function textareaIsDisabled(disabled: boolean | undefined, editable: boolean | undefined): boolean;
//# sourceMappingURL=textarea-disabled.d.ts.map