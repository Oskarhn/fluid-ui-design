/**
 * ThemeSelector — light, dark, or whatever the device is set to.
 *
 * Three miniatures of a screen, the chosen one ringed. A row of words would
 * take a third of the space and say the same thing, but "System" is the option
 * people hesitate over, and a picture of a screen split down the middle
 * explains it in less time than a sentence does.
 *
 * ```tsx
 * <ThemeSelector label="Choose a theme" />
 * ```
 *
 * ## It reads the theme rather than remembering it
 *
 * There is already one answer to "which theme is this" — Uniwind's — so the
 * selector asks for it instead of keeping a copy that can disagree. Change the
 * theme anywhere else in the app and the ring moves. Pass `value` to show
 * something else, for a settings screen that stages a choice before applying
 * it.
 *
 * ## Light and dark stay inside the family
 *
 * A reader in Moon who picks Light gets Moon's light theme, not the default
 * one. System is the exception, and cannot be otherwise: the device knows only
 * light and dark, so following it means following those two.
 */
import { type ReactNode } from 'react';
import { type PressableProps, type ViewProps } from 'react-native';
import { type ThemePreviewVariant } from './theme-preview.js';
export type { ThemePreviewVariant } from './theme-preview.js';
/** What the selector chooses between. */
export type ThemeSelection = 'system' | 'light' | 'dark';
/** How big the miniatures are drawn. */
export type ThemeSelectorSize = 'sm' | 'md';
/**
 * Which of the three the app is on, read from the theme itself.
 *
 * `hasAdaptiveThemes` is the part that makes this possible: it is true exactly
 * while the theme is following the device, which is the one thing the theme's
 * own name cannot tell you — `system` resolves to `light` or `dark` the moment
 * it is applied, and the two are indistinguishable afterwards.
 */
export declare function useThemeSelection(): ThemeSelection;
export interface ThemeSelectorProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /**
     * Show this as chosen instead of whatever the app is actually on. For a
     * settings screen that stages a choice before applying it; left unset, the
     * selector reads the live theme.
     */
    value?: ThemeSelection;
    /** Fires with the option pressed, before the theme changes. */
    onValueChange?: (value: ThemeSelection) => void;
    /**
     * Apply the choice. On by default — a theme selector that does not select a
     * theme is a radio group. Turn it off to store the choice and apply it
     * yourself, which is what an app that persists the preference wants.
     */
    applyTheme?: boolean;
    /** The heading above the row. Left out, there is none. */
    label?: string;
    /**
     * Which miniature is drawn. `window` is an app screen with a panel on it;
     * `card` is a framed card with an accent, cut on the diagonal for system.
     */
    variant?: ThemePreviewVariant;
    /**
     * How wide the miniatures are drawn. `sm` for a settings row that has other
     * things on it; `md` when choosing the theme is what the screen is for.
     */
    size?: ThemeSelectorSize;
    /** Stop the row being pressed, and dim it to say so. */
    disabled?: boolean;
    /**
     * The options, in the order you want them. Left out, the selector draws
     * system, light and dark in that order — which is the whole component.
     */
    children?: ReactNode;
}
declare function ThemeSelectorRoot({ className, value, onValueChange, applyTheme, label, variant, size, disabled, children, ...props }: ThemeSelectorProps): import("react").JSX.Element;
declare namespace ThemeSelectorRoot {
    var displayName: string;
}
export interface ThemeSelectorOptionProps extends Omit<PressableProps, 'children' | 'onPress'> {
    className?: string;
    /** Which of the three this option chooses. */
    value: ThemeSelection;
    /** What it is called under the miniature. Defaults to System, Light or Dark. */
    label?: string;
    /** Replaces the drawn miniature. */
    children?: ReactNode;
}
/**
 * One of the three.
 *
 * The whole thing is the target — the miniature and the word under it — because
 * at this size the word is the easier of the two to hit and pressing it should
 * not miss.
 */
declare function ThemeSelectorOption({ className, value, label, children, ...props }: ThemeSelectorOptionProps): import("react").JSX.Element;
declare namespace ThemeSelectorOption {
    var displayName: string;
}
export declare const ThemeSelector: typeof ThemeSelectorRoot & {
    Option: typeof ThemeSelectorOption;
};
//# sourceMappingURL=index.d.ts.map