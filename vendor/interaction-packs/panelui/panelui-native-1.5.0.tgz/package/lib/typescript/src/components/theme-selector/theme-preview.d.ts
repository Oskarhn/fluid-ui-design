/**
 * The three miniatures a theme selector is made of.
 *
 * Drawn from fixed neutrals rather than from theme tokens, which is the one
 * thing about this file that is not obvious. A preview built out of the active
 * theme's colours shows the reader the theme they already have, three times —
 * the light option has to look light while the app around it is dark, or it is
 * not a preview of anything.
 *
 * The greys are the ones a screenshot of an app would actually have: a ground,
 * a surface sitting on it, a mark, and the lines of text. Two sets, and the
 * system option draws both.
 */
import { type ReactNode } from 'react';
/** Which of the three a preview is drawing. */
export type ThemePreviewMode = 'system' | 'light' | 'dark';
/** How the miniature is drawn. */
export type ThemePreviewVariant = 'window' | 'card';
export interface ThemePreviewProps {
    mode: ThemePreviewMode;
    variant?: ThemePreviewVariant;
    width: number;
}
/**
 * One miniature.
 *
 * `width` rather than a scale factor: the option's box is what decides the
 * size, and everything inside is drawn against a fixed box and scaled by the
 * viewBox — so the geometry above never has to know how big it ended up.
 */
export declare function ThemePreview({ mode, variant, width }: ThemePreviewProps): ReactNode;
//# sourceMappingURL=theme-preview.d.ts.map