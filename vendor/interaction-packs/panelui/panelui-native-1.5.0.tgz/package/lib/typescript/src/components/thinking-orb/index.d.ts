import { type ViewProps } from 'react-native';
export type ThinkingOrbState = 'working' | 'searching' | 'solving' | 'listening' | 'composing' | 'shaping';
export interface ThinkingOrbProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** Which of the six animations to show. */
    state?: ThinkingOrbState;
    /**
     * Side of the orb in pixels.
     *
     * Two tunings ship, and they are separate designs rather than one scaled:
     * at or below 32 the orb switches to far fewer, proportionally much larger
     * dots moving faster, because a faithful lattice at that size is grey mush.
     */
    size?: number;
    /** Multiplier on the state's own speed. */
    speed?: number;
    /** Freeze on the current frame. */
    paused?: boolean;
    /** Ink colour. Defaults to the theme's foreground, so the orb inverts with it. */
    color?: string;
    /** Overrides the per-state default announced to screen readers. */
    accessibilityLabel?: string;
}
export declare function ThinkingOrb({ className, state, size, speed, paused, color, accessibilityLabel, style, ...props }: ThinkingOrbProps): import("react").JSX.Element;
export declare namespace ThinkingOrb {
    var displayName: string;
}
//# sourceMappingURL=index.d.ts.map