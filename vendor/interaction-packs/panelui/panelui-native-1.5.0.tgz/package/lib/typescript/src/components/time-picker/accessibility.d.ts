/** Resolve a standard adjustable action without wrapping past either bound. */
export declare function indexForAccessibilityAction(index: number, length: number, actionName: string, disabled?: boolean): number | undefined;
/** Keep the numeric adjustable range aligned with the values the face offers. */
export declare function accessibilityValueForIndex(index: number, length: number, text: string): {
    min: number;
    max: number;
    now: number;
    text: string;
};
//# sourceMappingURL=accessibility.d.ts.map