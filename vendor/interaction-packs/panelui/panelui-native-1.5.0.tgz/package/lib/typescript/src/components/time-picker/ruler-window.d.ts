/** Maximum tick cells mounted by the ruler, regardless of the minute step. */
export declare const RULER_WINDOW_SIZE = 121;
export interface RulerWindow {
    start: number;
    end: number;
}
/**
 * A chunked, overscanned slice around the visible tick. It moves only once per
 * WINDOW_SHIFT ticks, leaving at least forty ticks ahead of a normal scroll.
 */
export declare function rulerWindow(itemCount: number, visibleIndex: number): RulerWindow;
//# sourceMappingURL=ruler-window.d.ts.map