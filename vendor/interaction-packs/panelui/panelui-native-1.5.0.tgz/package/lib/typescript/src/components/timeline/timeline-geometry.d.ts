export declare const TIMELINE_WIDE_COLUMN = 268;
export declare const TIMELINE_NARROW_COLUMN = 76;
export declare function timelineColumnWidth(requested: number | undefined, filled: boolean): number;
/** Left edge of each column in render order. */
export declare function timelineColumnOffsets(widths: readonly number[]): number[];
//# sourceMappingURL=timeline-geometry.d.ts.map