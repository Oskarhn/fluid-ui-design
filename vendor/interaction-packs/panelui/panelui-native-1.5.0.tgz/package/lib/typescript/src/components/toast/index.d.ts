/**
 * Toast — transient notification.
 *
 * Three ways to raise one, because the right amount of ceremony differs: a
 * bare string, a config object with a title, description and action, or a
 * custom component when none of that fits. The anatomy underneath is the same
 * in all three.
 *
 * The viewport is mounted for you by PanelUIProvider; `useToast()` works
 * anywhere below it.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type TextProps } from '../../primitives/text.js';
import { type ButtonProps } from '../button/index.js';
import { toast, type ToastHandle, type ToastItem, type ToastPlacement, type ToastVariant } from './toast-store.js';
declare const toastVariants: import("tailwind-variants").TVReturnType<{
    variant: {
        default: {
            root: string;
            title: string;
        };
        info: {
            root: string;
            title: string;
        };
        success: {
            root: string;
            title: string;
        };
        warning: {
            root: string;
            title: string;
        };
        destructive: {
            root: string;
            title: string;
        };
    };
}, {
    root: string;
    indicator: string;
    content: string;
    title: string;
    description: string;
}, undefined, {
    variant: {
        default: {
            root: string;
            title: string;
        };
        info: {
            root: string;
            title: string;
        };
        success: {
            root: string;
            title: string;
        };
        warning: {
            root: string;
            title: string;
        };
        destructive: {
            root: string;
            title: string;
        };
    };
}, {
    root: string;
    indicator: string;
    content: string;
    title: string;
    description: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    variant: {
        default: {
            root: string;
            title: string;
        };
        info: {
            root: string;
            title: string;
        };
        success: {
            root: string;
            title: string;
        };
        warning: {
            root: string;
            title: string;
        };
        destructive: {
            root: string;
            title: string;
        };
    };
}, {
    root: string;
    indicator: string;
    content: string;
    title: string;
    description: string;
}>>;
export interface ToastProps extends ViewProps, VariantProps<typeof toastVariants> {
    className?: string;
    /** Called when the close button is pressed or the toast is swiped away. */
    onHide?: () => void;
    children?: ReactNode;
}
export interface ToastIndicatorProps extends ViewProps {
    className?: string;
    iconProps?: {
        size?: number;
        color?: string;
    };
    children?: ReactNode;
}
export interface ToastCloseProps extends Omit<ViewProps, 'accessibilityLabel'> {
    className?: string;
    /**
     * What a screen reader calls the button. Defaults to "Dismiss notification";
     * pass your own in an app that is not in English.
     */
    accessibilityLabel?: string;
}
export declare const Toast: {
    ({ className, variant, onHide, children, ...props }: ToastProps): import("react").JSX.Element;
    displayName: string;
} & {
    Indicator: {
        ({ className, iconProps, children, ...props }: ToastIndicatorProps): import("react").JSX.Element;
        displayName: string;
    };
    Content: {
        ({ className, ...props }: ViewProps & {
            className?: string;
        }): import("react").JSX.Element;
        displayName: string;
    };
    Title: {
        ({ className, ...props }: TextProps): import("react").JSX.Element;
        displayName: string;
    };
    Description: {
        ({ className, ...props }: TextProps): import("react").JSX.Element;
        displayName: string;
    };
    Action: {
        ({ variant, size, onPress, ...props }: ButtonProps): import("react").JSX.Element;
        displayName: string;
    };
    Close: {
        ({ className, accessibilityLabel, ...props }: ToastCloseProps): import("react").JSX.Element;
        displayName: string;
    };
};
/**
 * Renders the toast queue. PanelUIProvider mounts this automatically — you
 * only need it directly if you build your own provider.
 */
export declare function ToastViewport(): import("react").JSX.Element | null;
/**
 * Access the toast API.
 *
 * ```tsx
 * const { toast } = useToast();
 * toast.show({ variant: 'success', label: 'Saved' });
 * ```
 */
export declare function useToast(): {
    toast: {
        show: (options: import("./toast-store.js").ToastOptions | string) => string;
        hide: (id: string) => void;
        hideAll: () => void;
    };
};
export { toast, type ToastItem, type ToastPlacement, type ToastVariant, type ToastHandle };
export type { ToastOptions } from './toast-store.js';
//# sourceMappingURL=index.d.ts.map