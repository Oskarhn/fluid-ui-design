/**
 * Toast queue.
 *
 * A module-level store rather than React state, so `toast.show()` works from
 * anywhere — event handlers, API clients, code outside the component tree —
 * without threading a context through. The viewport subscribes with
 * `useSyncExternalStore`.
 */
import type { ReactNode } from 'react';
export type ToastVariant = 'default' | 'info' | 'success' | 'warning' | 'destructive';
export type ToastPlacement = 'top' | 'bottom';
/** Handle given to action callbacks so they can dismiss their own toast. */
export interface ToastHandle {
    id: string;
    hide: () => void;
}
export interface ToastOptions {
    variant?: ToastVariant;
    placement?: ToastPlacement;
    /** Title line. */
    label?: string;
    description?: string;
    /** Overrides the variant's default status icon. Pass `null` for no icon. */
    icon?: ReactNode;
    /** Renders a trailing action button when set. */
    actionLabel?: string;
    onActionPress?: (handle: ToastHandle) => void;
    /** Show a close button. Defaults to true when there is no action. */
    closable?: boolean;
    /** Milliseconds before auto-dismiss. `0` keeps it up until dismissed. */
    duration?: number;
    /** Fully custom rendering. Receives the same handle as action callbacks. */
    component?: (handle: ToastHandle) => ReactNode;
}
export interface ToastItem extends ToastOptions {
    id: string;
}
export declare class ToastStore {
    private items;
    private snapshot;
    private listeners;
    private timers;
    private timersPaused;
    subscribe: (listener: () => void) => () => void;
    getSnapshot: () => readonly ToastItem[];
    show: (options: ToastOptions | string) => string;
    hide: (id: string) => void;
    hideAll: () => void;
    /** Pause auto-dismiss countdowns while their viewport is not visible. */
    pauseTimers: () => void;
    /** Resume each auto-dismiss countdown from its remaining visible time. */
    resumeTimers: () => void;
    private startTimer;
    private emit;
}
export declare const toastStore: ToastStore;
/**
 * Imperative toast API. Also returned from `useToast()`.
 *
 * ```ts
 * toast.show('Saved');
 * toast.show({ variant: 'success', label: 'Deployed', actionLabel: 'View' });
 * ```
 */
export declare const toast: {
    show: (options: ToastOptions | string) => string;
    hide: (id: string) => void;
    hideAll: () => void;
};
//# sourceMappingURL=toast-store.d.ts.map