/**
 * Tooltip — a small label that names the thing under your finger.
 *
 * A popover is a panel you open and deal with; a tooltip is a whisper. It
 * carries a word or two about what a control does, appears without taking the
 * screen, and goes away on its own. That is why it is inverted by default, why
 * it is not dismissible with a scrim, and why it closes after a beat instead of
 * waiting to be told.
 *
 * The inversion is a default rather than a rule, because the whisper has a
 * larger sibling: a tooltip that carries a heading and a sentence stops reading
 * as a different layer and starts reading as a panel with the wrong colours.
 * `variant="surface"` makes it one, and the sizing props — `width`,
 * `minWidth`, `maxHeight`, `scrollable` — are what let it hold that much.
 *
 * On touch there is no hover to open it, so the gesture is a long press by
 * default — the platform's own "tell me more" gesture — with `openOn="press"`
 * for the cases where a tap should reveal it instead.
 *
 * ```tsx
 * <Tooltip label="Copy link">
 *   <Tooltip.Trigger>
 *     <IconButton icon={<LinkIcon />} />
 *   </Tooltip.Trigger>
 *   <Tooltip.Content>
 *     <Tooltip.Arrow />
 *     Copy link
 *   </Tooltip.Content>
 * </Tooltip>
 * ```
 *
 * Placement is a preference, not a promise: the trigger is measured when it is
 * pressed, the label measures itself on its first layout, and the two are
 * reconciled against the safe area — so `placement="top"` means *above, if
 * above fits*, and a trigger near the top edge shows its tooltip below instead.
 */
import { type ReactElement, type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type TextProps } from '../../primitives/text.js';
export type TooltipPlacement = 'top' | 'bottom' | 'left' | 'right';
export type TooltipAlign = 'start' | 'center' | 'end';
export type TooltipVariant = 'inverted' | 'surface';
export type TooltipOpenOn = 'longPress' | 'press';
export interface TooltipProps {
    children: ReactNode;
    /** Controlled open state. */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** Initial state when uncontrolled. */
    defaultOpen?: boolean;
    /**
     * Whether a long press or a plain press reveals the label. Long press is the
     * default because it does not steal a tappable control's own press.
     */
    openOn?: TooltipOpenOn;
    /**
     * How long the label stays up before hiding itself, in milliseconds. `0`
     * keeps it up until it is dismissed by a tap outside or the trigger again.
     */
    duration?: number;
    /**
     * The label's text, mirrored onto the trigger as its accessibility label so
     * a screen reader announces what the tooltip says without opening it. Set it
     * whenever the trigger has no text of its own — an icon-only button.
     */
    label?: string;
}
declare function TooltipRoot({ children, open, onOpenChange, defaultOpen, openOn, duration, label, }: TooltipProps): import("react").JSX.Element;
export interface TooltipTriggerProps {
    /**
     * Classes on the wrapper the child is measured through. It shrinks to the
     * child by default; widen it only if the label should be anchored to
     * something bigger than the control.
     */
    className?: string;
    children: ReactElement<{
        onPress?: (...args: unknown[]) => void;
        onLongPress?: (...args: unknown[]) => void;
        accessibilityLabel?: string;
        accessibilityHint?: string;
    }>;
}
/**
 * Wraps its child and reveals the label on it — a long press by default, a
 * press when the root asks for one. It is also what gets measured, so the
 * label knows where to sit.
 *
 * The child is wrapped in a view rather than handed a ref: the ref has to
 * survive whatever the child is — a button, a plain Pressable, an icon — and
 * only a wrapper we own is guaranteed to be measurable.
 *
 * That wrapper shrinks to its child on purpose. A view stretches to its parent
 * by default, and a wrapper that filled the row would be measured as the whole
 * row — putting a centred label over the middle of the screen rather than over
 * the control it names.
 */
declare function TooltipTrigger({ className, children }: TooltipTriggerProps): import("react").JSX.Element;
export interface TooltipContentProps extends ViewProps {
    className?: string;
    /** Preferred side of the trigger. Flipped when that side does not fit. */
    placement?: TooltipPlacement;
    /** Where the label sits along the trigger's other axis. */
    align?: TooltipAlign;
    /** Gap between the trigger and the label, in pixels. */
    offset?: number;
    /** Nudge along the alignment axis, in pixels. */
    alignOffset?: number;
    /**
     * Which set of colours the panel, its arrow and its text draw from.
     *
     * `inverted` is the default and right for a label: a whisper over the page
     * should read as a different layer rather than as another panel of it.
     * `surface` matches the popover — reach for it once the tooltip carries a
     * heading and a sentence, where the inversion stops reading as a whisper.
     */
    variant?: TooltipVariant;
    /**
     * `content-fit` sizes to the content, `trigger` matches the trigger's width,
     * `full` spans the safe area, and a number is that many pixels. Worth setting
     * for anything longer than a label, which would otherwise run to whatever
     * width the sentence happens to want.
     */
    width?: number | 'trigger' | 'full' | 'content-fit';
    /** Floor for the panel's width, in pixels. */
    minWidth?: number;
    /**
     * Ceiling for the panel's height, in pixels. Always clamped to the room
     * inside the safe area, which is also the default.
     */
    maxHeight?: number;
    /**
     * Scroll the body when it is taller than `maxHeight`. Off by default — a
     * label has nothing to scroll, and a scroller around one only adds a bounce.
     */
    scrollable?: boolean;
    children?: ReactNode;
}
declare function TooltipContent({ className, placement, align, offset, alignOffset, variant, width, minWidth, maxHeight, scrollable, children, onLayout: onLayoutProp, style, ...props }: TooltipContentProps): import("react").JSX.Element | null;
/** The label's default text, coloured to whatever the panel is made of. */
declare function TooltipText({ className, ...props }: TextProps): import("react").JSX.Element;
declare namespace TooltipText {
    var displayName: string;
}
export interface TooltipTitleProps extends TextProps {
    className?: string;
}
/** A heading, for a tooltip carrying more than a label. */
declare function TooltipTitle({ className, ...props }: TooltipTitleProps): import("react").JSX.Element;
declare namespace TooltipTitle {
    var displayName: string;
}
export interface TooltipDescriptionProps extends TextProps {
    className?: string;
}
/** The sentence under a `Tooltip.Title`, in the panel's secondary colour. */
declare function TooltipDescription({ className, ...props }: TooltipDescriptionProps): import("react").JSX.Element;
declare namespace TooltipDescription {
    var displayName: string;
}
export interface TooltipArrowProps extends ViewProps {
    className?: string;
}
/**
 * A small square rotated into a diamond, half-buried under the label so only
 * the point shows. It shares the label's fill and points at the trigger's
 * centre, which Content resolves and publishes — so when `align` shifts the
 * label off-centre, or a clamp slides it back on screen, the arrow stays over
 * the trigger rather than over the label's middle.
 */
declare function TooltipArrow({ className, style, ...props }: TooltipArrowProps): import("react").JSX.Element | null;
export declare const Tooltip: typeof TooltipRoot & {
    Trigger: typeof TooltipTrigger;
    Content: typeof TooltipContent;
    Arrow: typeof TooltipArrow;
    Title: typeof TooltipTitle;
    Description: typeof TooltipDescription;
    Text: typeof TooltipText;
};
export {};
//# sourceMappingURL=index.d.ts.map