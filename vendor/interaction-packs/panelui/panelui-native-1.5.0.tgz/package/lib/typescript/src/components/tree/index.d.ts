/**
 * Tree — a hierarchy you can open a level at a time.
 *
 * The shape behind a file browser, a folder of settings, a category picker, a
 * table of contents: rows that contain other rows, where a parent's children
 * only exist on screen once you ask for them. Accordion is the one-level
 * version of this and stops there — its items cannot hold items. A tree's can,
 * to any depth, and everything that follows from that is what this component
 * owns: which node a row sits under, how far in it is drawn, whether it is a
 * branch at all, and which of its ancestors are open.
 *
 * ```tsx
 * <Tree defaultExpanded={['src']} selectionMode="single">
 *   <Tree.Item value="src">
 *     <Tree.Trigger>
 *       <Tree.Indicator />
 *       <Tree.Label>src</Tree.Label>
 *     </Tree.Trigger>
 *     <Tree.Group>
 *       <Tree.Item value="src/index.ts">
 *         <Tree.Trigger>
 *           <Tree.Indicator />
 *           <Tree.Label>index.ts</Tree.Label>
 *         </Tree.Trigger>
 *       </Tree.Item>
 *     </Tree.Group>
 *   </Tree.Item>
 * </Tree>
 * ```
 *
 * A closed branch renders nothing below it — the subtree is unmounted, not
 * hidden — so the cost of a tree is what is open in it rather than what is in
 * it. A folder of ten thousand files that nobody has opened costs one row.
 *
 * An item is a branch because it holds a `Tree.Group`, not because it was
 * declared one, so there is no second fact to keep true. The exception is a
 * branch whose children have not been fetched yet: it has no group to be
 * detected by, so it says `hasChildren` and gets its chevron, and the fetch
 * hangs off `onExpandedChange`.
 *
 * Expansion and selection are separate pieces of state because they answer
 * separate questions — which parts of the hierarchy are open, and which row is
 * the chosen one — and a tree commonly needs one without the other. Either can
 * be controlled or left alone.
 */
import { type ReactNode } from 'react';
import { type PressableProps, type ViewProps } from 'react-native';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
export type TreeSize = 'sm' | 'default';
/** `none` makes the rows expanders only — nothing is ever the chosen one. */
export type TreeSelectionMode = 'none' | 'single' | 'multiple';
export interface TreeProps extends ViewProps {
    className?: string;
    /** Row density. `sm` for a sidebar or a picker inside a sheet. */
    size?: TreeSize;
    /** Whether a row can be the chosen one, and how many can be at once. */
    selectionMode?: TreeSelectionMode;
    /** Selected value(s), controlled. An array when `selectionMode` is `multiple`. */
    value?: string | string[];
    defaultValue?: string | string[];
    /** Handed back in the shape it was given — a string when single, an array when multiple. */
    onValueChange?: (value: string | string[]) => void;
    /** Values of the open branches, controlled. */
    expanded?: string[];
    defaultExpanded?: string[];
    /** Fires with the next set of open branches — the hook to load a branch's children on. */
    onExpandedChange?: (expanded: string[]) => void;
    /**
     * Whether pressing anywhere on a branch's row opens it, as well as selecting
     * it. Turn it off when selecting a branch has to be possible without opening
     * it; the chevron still opens it either way.
     */
    expandOnPress?: boolean;
    /** Draw a hairline down each level, connecting a branch to the rows inside it. */
    showLines?: boolean;
    /** How far one level is drawn in from its parent, in points. */
    indent?: number;
    children?: ReactNode;
}
export interface TreeItemProps extends ViewProps {
    className?: string;
    /** Identifies this node in the tree's expanded and selected state. */
    value: string;
    isDisabled?: boolean;
    /**
     * Marks the item as a branch when it has no `Tree.Group` to be detected by —
     * a folder whose contents are fetched the first time it is opened. It gets a
     * chevron, and opening it fires `onExpandedChange` with nothing to show yet.
     */
    hasChildren?: boolean;
    children?: ReactNode;
}
/** Pressable props are forwarded; `onPress` runs after the tree updates its state. */
export interface TreeTriggerProps extends Omit<PressableProps, 'children'> {
    className?: string;
    children?: ReactNode;
}
export interface TreeIndicatorProps extends ViewProps {
    className?: string;
    /** Replaces the default chevron. It is rotated for you while the branch is open. */
    children?: ReactNode;
}
export interface TreeIconProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface TreeActionsProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export interface TreeGroupProps extends ViewProps {
    className?: string;
    children?: ReactNode;
}
export declare const Tree: import("react").ForwardRefExoticComponent<TreeProps & import("react").RefAttributes<ViewRef>> & {
    Item: import("react").ForwardRefExoticComponent<TreeItemProps & import("react").RefAttributes<ViewRef>>;
    Trigger: import("react").ForwardRefExoticComponent<TreeTriggerProps & import("react").RefAttributes<ViewRef>>;
    Indicator: import("react").ForwardRefExoticComponent<TreeIndicatorProps & import("react").RefAttributes<ViewRef>>;
    Icon: import("react").ForwardRefExoticComponent<TreeIconProps & import("react").RefAttributes<ViewRef>>;
    Label: import("react").ForwardRefExoticComponent<TextProps & import("react").RefAttributes<TextRef>>;
    Actions: import("react").ForwardRefExoticComponent<TreeActionsProps & import("react").RefAttributes<ViewRef>>;
    Group: import("react").ForwardRefExoticComponent<TreeGroupProps & import("react").RefAttributes<ViewRef>>;
};
//# sourceMappingURL=index.d.ts.map