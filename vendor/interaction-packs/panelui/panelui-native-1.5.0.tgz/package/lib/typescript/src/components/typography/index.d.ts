/**
 * Typography — semantic text presets, and the marks that go on them.
 *
 * The type scale in one place, so headings stay consistent instead of being
 * rebuilt out of size and weight classes at each call site. Built on the Text
 * primitive, so every preset keeps `className` passthrough and theme colours.
 *
 * ```tsx
 * <Typography type="h2">Billing</Typography>
 * <Typography>Your plan renews on the 1st.</Typography>
 * <Typography underline>Terms of service</Typography>
 * ```
 *
 * A preset sets size, weight and tracking together; the marks — `underline`,
 * `italic`, `strike` — and `weight`, `align` and `transform` layer on top of
 * whichever preset is in force. They are props rather than class names because
 * the point of this component is that a screen never has to know which
 * utilities add up to "a bolded lead paragraph".
 *
 * React Native draws no list markers and has no blockquote, so
 * `Typography.List` and `Typography.Blockquote` build both out of a row and a
 * rule — which is exactly the kind of thing this component exists to stop
 * people rebuilding per screen.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type TextProps } from '../../primitives/text.js';
import type { TextRef, ViewRef } from '../../primitives/refs.js';
declare const typographyVariants: import("tailwind-variants").TVReturnType<{
    type: {
        h1: "text-4xl font-bold tracking-tight";
        h2: "text-3xl font-semibold tracking-tight";
        h3: "text-2xl font-semibold tracking-tight";
        h4: "text-xl font-semibold";
        h5: "text-lg font-semibold";
        h6: "text-base font-semibold";
        /** The sentence under a heading, set larger and quieter than body. */
        lead: "text-xl font-normal text-muted-foreground";
        body: "text-base font-normal";
        'body-sm': "text-sm font-normal";
        'body-xs': "text-xs font-normal";
        /** Body, one step up — for a number or a name that carries the row. */
        large: "text-lg font-semibold";
        small: "text-sm font-medium leading-tight";
        blockquote: "text-base font-normal italic";
        code: "font-mono text-sm text-foreground";
    };
    weight: {
        normal: "font-normal";
        medium: "font-medium";
        semibold: "font-semibold";
        bold: "font-bold";
    };
    align: {
        start: "text-start";
        end: "text-end";
        left: "text-left";
        center: "text-center";
        right: "text-right";
    };
    transform: {
        uppercase: "uppercase";
        lowercase: "lowercase";
        capitalize: "capitalize";
    };
    underline: {
        true: "underline";
    };
    italic: {
        true: "italic";
    };
    strike: {
        true: "line-through";
    };
    muted: {
        true: "text-muted-foreground";
    };
}, undefined, "text-foreground", {
    type: {
        h1: "text-4xl font-bold tracking-tight";
        h2: "text-3xl font-semibold tracking-tight";
        h3: "text-2xl font-semibold tracking-tight";
        h4: "text-xl font-semibold";
        h5: "text-lg font-semibold";
        h6: "text-base font-semibold";
        /** The sentence under a heading, set larger and quieter than body. */
        lead: "text-xl font-normal text-muted-foreground";
        body: "text-base font-normal";
        'body-sm': "text-sm font-normal";
        'body-xs': "text-xs font-normal";
        /** Body, one step up — for a number or a name that carries the row. */
        large: "text-lg font-semibold";
        small: "text-sm font-medium leading-tight";
        blockquote: "text-base font-normal italic";
        code: "font-mono text-sm text-foreground";
    };
    weight: {
        normal: "font-normal";
        medium: "font-medium";
        semibold: "font-semibold";
        bold: "font-bold";
    };
    align: {
        start: "text-start";
        end: "text-end";
        left: "text-left";
        center: "text-center";
        right: "text-right";
    };
    transform: {
        uppercase: "uppercase";
        lowercase: "lowercase";
        capitalize: "capitalize";
    };
    underline: {
        true: "underline";
    };
    italic: {
        true: "italic";
    };
    strike: {
        true: "line-through";
    };
    muted: {
        true: "text-muted-foreground";
    };
}, undefined, import("tailwind-variants").TVReturnTypeLike<{
    type: {
        h1: "text-4xl font-bold tracking-tight";
        h2: "text-3xl font-semibold tracking-tight";
        h3: "text-2xl font-semibold tracking-tight";
        h4: "text-xl font-semibold";
        h5: "text-lg font-semibold";
        h6: "text-base font-semibold";
        /** The sentence under a heading, set larger and quieter than body. */
        lead: "text-xl font-normal text-muted-foreground";
        body: "text-base font-normal";
        'body-sm': "text-sm font-normal";
        'body-xs': "text-xs font-normal";
        /** Body, one step up — for a number or a name that carries the row. */
        large: "text-lg font-semibold";
        small: "text-sm font-medium leading-tight";
        blockquote: "text-base font-normal italic";
        code: "font-mono text-sm text-foreground";
    };
    weight: {
        normal: "font-normal";
        medium: "font-medium";
        semibold: "font-semibold";
        bold: "font-bold";
    };
    align: {
        start: "text-start";
        end: "text-end";
        left: "text-left";
        center: "text-center";
        right: "text-right";
    };
    transform: {
        uppercase: "uppercase";
        lowercase: "lowercase";
        capitalize: "capitalize";
    };
    underline: {
        true: "underline";
    };
    italic: {
        true: "italic";
    };
    strike: {
        true: "line-through";
    };
    muted: {
        true: "text-muted-foreground";
    };
}, undefined>>;
export type TypographyType = NonNullable<VariantProps<typeof typographyVariants>['type']>;
export type TypographyWeight = NonNullable<VariantProps<typeof typographyVariants>['weight']>;
export interface TypographyProps extends Omit<TextProps, 'size' | 'weight'>, VariantProps<typeof typographyVariants> {
    className?: string;
    /**
     * Overrides the weight the preset sets. This is the one to reach for when a
     * paragraph needs a bolded run and a heading would be wrong.
     */
    weight?: TypographyWeight;
    /** Underlines the text — a link, a defined term, a signature line. */
    underline?: boolean;
    /** Slants the text. */
    italic?: boolean;
    /** Strikes the text through: an old price, a completed task. */
    strike?: boolean;
    /** Horizontal alignment within whatever the text is laid out in. */
    align?: 'left' | 'center' | 'right';
    /** Case, applied for display without changing the string underneath. */
    transform?: 'uppercase' | 'lowercase' | 'capitalize';
}
/** Heading levels, for `Typography.Heading`. */
type HeadingType = Extract<TypographyType, 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6'>;
/** Body sizes, for `Typography.Paragraph`. */
type ParagraphType = Extract<TypographyType, 'body' | 'body-sm' | 'body-xs' | 'lead' | 'large' | 'small'>;
export interface TypographyHeadingProps extends Omit<TypographyProps, 'type'> {
    type?: HeadingType;
}
export interface TypographyParagraphProps extends Omit<TypographyProps, 'type'> {
    type?: ParagraphType;
}
export interface TypographyCodeProps extends Omit<TypographyProps, 'type'> {
    /** Classes for the surface behind the code text. */
    containerClassName?: string;
}
export interface TypographyBlockquoteProps extends Omit<TypographyProps, 'type'> {
    /** Classes for the row that carries the rule. */
    containerClassName?: string;
}
export interface TypographyListProps extends ViewProps {
    className?: string;
    /** Numbered rather than bulleted. The numbers are drawn, not counted by CSS. */
    ordered?: boolean;
    children?: ReactNode;
}
export interface TypographyListItemProps extends Omit<TypographyProps, 'type'> {
    type?: ParagraphType;
}
export declare const Typography: import("react").ForwardRefExoticComponent<TypographyProps & import("react").RefAttributes<TextRef>> & {
    Heading: import("react").ForwardRefExoticComponent<TypographyHeadingProps & import("react").RefAttributes<TextRef>>;
    Paragraph: import("react").ForwardRefExoticComponent<TypographyParagraphProps & import("react").RefAttributes<TextRef>>;
    Code: import("react").ForwardRefExoticComponent<TypographyCodeProps & Pick<ViewProps, "testID"> & import("react").RefAttributes<ViewRef>>;
    Blockquote: import("react").ForwardRefExoticComponent<TypographyBlockquoteProps & import("react").RefAttributes<ViewRef>>;
    List: import("react").ForwardRefExoticComponent<TypographyListProps & import("react").RefAttributes<ViewRef>>;
    ListItem: import("react").ForwardRefExoticComponent<TypographyListItemProps & import("react").RefAttributes<TextRef>>;
};
export {};
//# sourceMappingURL=index.d.ts.map