import { type ViewProps } from 'react-native';
import type { ViewRef } from '../../primitives/refs.js';
/** The colour of a block, from the theme's roles. */
export type WeekHoursTone = 'primary' | 'muted' | 'success' | 'warning' | 'destructive' | 'info';
/** One filled stretch of a row. */
export interface WeekHoursBlock {
    /** Where it starts, in hours: 9.5 is half past nine. */
    start: number;
    /** Where it ends, in hours. */
    end: number;
    /** Its colour. Default `primary`. Use `muted` for time taken by someone else. */
    tone?: WeekHoursTone;
}
/** One row of the grid: a day, a room or a person. */
export interface WeekHoursRow {
    /** Identifies the row; it is what `onSelect` is called with. */
    key: string;
    /** The text at the start of the row, such as "Mon". */
    label: string;
    /** The filled stretches. */
    blocks: WeekHoursBlock[];
    /** Draws the row faded with no blocks, for a day that is not worked. */
    off?: boolean;
    /** Outlines the row, for the one being edited. */
    selected?: boolean;
    /** What a screen reader says for the row's label, when it differs from the text. */
    accessibilityLabel?: string;
}
/** One entry under the grid, explaining a tone. */
export interface WeekHoursLegendItem {
    label: string;
    /** The tone it explains. Default `primary`. */
    tone?: WeekHoursTone;
}
export interface WeekHoursGridProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** The rows, top to bottom. */
    rows: WeekHoursRow[];
    /** The first visible hour. Default 0. */
    from?: number;
    /** The last visible hour. Default 24. */
    to?: number;
    /**
     * The labels under the bars, spread evenly from `from` to `to`. Numbers are
     * written as two-digit hours; strings are shown as given.
     */
    ticks?: (number | string)[];
    /** The entries under the grid, explaining each tone. */
    legend?: WeekHoursLegendItem[];
    /** Makes each row a button, called with the row's `key`. */
    onSelect?: (key: string) => void;
    /** What a screen reader says for a row marked `off`. Default "off". */
    offLabel?: string;
}
export declare const WeekHoursGrid: import("react").ForwardRefExoticComponent<WeekHoursGridProps & import("react").RefAttributes<ViewRef>>;
//# sourceMappingURL=index.d.ts.map