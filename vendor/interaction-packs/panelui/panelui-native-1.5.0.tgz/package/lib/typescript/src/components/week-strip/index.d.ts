import { type ViewProps } from 'react-native';
import { type VariantProps } from 'tailwind-variants';
import { type DateLocale } from '../../utils/date.js';
import type { ViewRef } from '../../primitives/refs.js';
/** The colour of a mark, from the theme's roles. */
export type WeekStripTone = 'primary' | 'success' | 'warning' | 'destructive' | 'info' | 'muted';
/** What a day shows beneath its number, and in its corner. */
export interface WeekStripMarks {
    /** Up to three dots, one per kind of thing on the day. */
    dots?: WeekStripTone[];
    /** A short label in place of the dots, such as "3 free". Wins over `dots`. */
    label?: string;
    /** A small dot in the top corner, for a day that needs attention. */
    corner?: WeekStripTone;
}
declare const weekStripVariants: import("tailwind-variants").TVReturnType<{
    size: {
        sm: {
            cell: string;
            number: string;
        };
        md: {
            cell: string;
            number: string;
        };
    };
    selected: {
        true: {
            cell: string;
            weekday: string;
            number: string;
            label: string;
        };
    };
    today: {
        true: {
            cell: string;
        };
    };
    dim: {
        true: {
            cell: string;
        };
    };
}, {
    root: string;
    cell: string;
    weekday: string;
    number: string;
    marks: string;
    dot: string;
    label: string;
    corner: string;
}, undefined, {
    size: {
        sm: {
            cell: string;
            number: string;
        };
        md: {
            cell: string;
            number: string;
        };
    };
    selected: {
        true: {
            cell: string;
            weekday: string;
            number: string;
            label: string;
        };
    };
    today: {
        true: {
            cell: string;
        };
    };
    dim: {
        true: {
            cell: string;
        };
    };
}, {
    root: string;
    cell: string;
    weekday: string;
    number: string;
    marks: string;
    dot: string;
    label: string;
    corner: string;
}, import("tailwind-variants").TVReturnTypeLike<{
    size: {
        sm: {
            cell: string;
            number: string;
        };
        md: {
            cell: string;
            number: string;
        };
    };
    selected: {
        true: {
            cell: string;
            weekday: string;
            number: string;
            label: string;
        };
    };
    today: {
        true: {
            cell: string;
        };
    };
    dim: {
        true: {
            cell: string;
        };
    };
}, {
    root: string;
    cell: string;
    weekday: string;
    number: string;
    marks: string;
    dot: string;
    label: string;
    corner: string;
}>>;
/** How big the strip's days are. */
export type WeekStripSize = NonNullable<VariantProps<typeof weekStripVariants>['size']>;
export interface WeekStripProps extends Omit<ViewProps, 'children'> {
    className?: string;
    /** The selected day. */
    value?: Date | null;
    /** Called with the day that was pressed. */
    onValueChange?: (day: Date) => void;
    /**
     * Which week to show, as any day inside it. Defaults to the week of `value`,
     * or this week. Ignored when `scroll` is set.
     */
    week?: Date;
    /**
     * Lay out `length` days from `start` in fixed-width cells that scroll
     * sideways, instead of the seven days of one week filling the row.
     */
    scroll?: boolean;
    /** The first day of a scrolling strip. Defaults to today. */
    start?: Date;
    /** How many days a scrolling strip holds. Default 14. */
    length?: number;
    /**
     * The first day of the week, 0 for Sunday to 6 for Saturday, or `auto` to
     * ask the locale. Default 0.
     */
    weekStartsOn?: number | 'auto';
    /** The locale for weekday names and spoken dates. Defaults to the device's. */
    locale?: DateLocale;
    /** How big the days are. `sm` suits a header; `md` is the default. */
    size?: WeekStripSize;
    /** Days that cannot be picked. They are faded and do not respond. */
    disabled?: (day: Date) => boolean;
    /** Days that are faded but can still be picked, such as days in the past. */
    faded?: (day: Date) => boolean;
    /** What each day shows beneath its number and in its corner. */
    marks?: (day: Date) => WeekStripMarks | undefined;
    /** The day counted as today. Defaults to the current date. */
    today?: Date;
}
export declare const WeekStrip: import("react").ForwardRefExoticComponent<WeekStripProps & import("react").RefAttributes<ViewRef>>;
export {};
//# sourceMappingURL=index.d.ts.map