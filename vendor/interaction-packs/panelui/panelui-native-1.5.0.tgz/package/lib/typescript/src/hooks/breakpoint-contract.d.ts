export type BreakpointDefinition = Readonly<Record<string, number>>;
/** Validate declaration order once, when an app creates its responsive contract. */
export declare function breakpointEntries<const T extends BreakpointDefinition>(definition: T): [keyof T & string, number][];
/** Largest satisfied name, with `base` as the deterministic below-range fallback. */
export declare function breakpointAt<Name extends string>(entries: readonly (readonly [Name, number])[], width: number): Name | 'base';
//# sourceMappingURL=breakpoint-contract.d.ts.map