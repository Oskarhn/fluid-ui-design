export interface UseCopyToClipboardOptions {
    /** Milliseconds before `copied` flips back. */
    timeout?: number;
    onCopy?: () => void;
}
export interface UseCopyToClipboardResult {
    /** Writes `value` to the clipboard and sets `copied`. */
    copy: (value: string) => Promise<void>;
    copied: boolean;
}
/**
 * Copy text to the clipboard, with a temporary "copied" state.
 *
 * Requires `expo-clipboard`, which is an optional peer dependency — React
 * Native removed `Clipboard` from core, and pulling in a required native
 * module for one hook would cost every consumer who never calls it:
 *
 * ```sh
 * npx expo install expo-clipboard
 * ```
 *
 * ```tsx
 * const { copy, copied } = useCopyToClipboard();
 * <Button onPress={() => copy(url)}>{copied ? 'Copied' : 'Copy link'}</Button>
 * ```
 */
export declare function useCopyToClipboard({ timeout, onCopy, }?: UseCopyToClipboardOptions): UseCopyToClipboardResult;
//# sourceMappingURL=use-copy-to-clipboard.d.ts.map