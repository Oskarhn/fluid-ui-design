/**
 * A copy of `value` that only updates once it has stopped changing for
 * `delay` ms — for search fields, where you want the typed value on screen
 * immediately but the query fired once.
 *
 * ```tsx
 * const [query, setQuery] = useState('');
 * const debounced = useDebouncedValue(query, 300);
 * useEffect(() => { search(debounced); }, [debounced]);
 * ```
 */
export declare function useDebouncedValue<T>(value: T, delay?: number): T;
//# sourceMappingURL=use-debounced-value.d.ts.map