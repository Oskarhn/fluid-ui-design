export type DirectionValue = 'ltr' | 'rtl';
/** What the device is set to, for anything outside a provider. */
export declare const deviceDirection: () => DirectionValue;
export declare const DirectionContext: import("react").Context<DirectionValue | null>;
/**
 * The reading direction in force, for a component that has to flip maths Yoga
 * cannot flip for it. Safe with no provider mounted: it falls back to the
 * device's own setting.
 */
export declare function useDirection(): DirectionValue;
/**
 * `-1` in a right-to-left subtree, `1` otherwise.
 *
 * The form most of the pixel maths actually wants. A drag translation, an
 * indicator offset and a sweep are all a number that has to change sign, and
 * writing `dir === 'rtl' ? -x : x` at every one of them is where the sign
 * errors live.
 */
export declare function useDirectionSign(): 1 | -1;
//# sourceMappingURL=use-direction.d.ts.map