import { type LayoutChangeEvent, type ViewStyle } from 'react-native';
import { useAnimatedStyle, type AnimatedRef } from 'react-native-reanimated';
import type { ViewRef } from '../primitives/refs.js';
export type KeyboardAvoidanceMode = 'lift' | 'dock';
export interface UseKeyboardAvoidanceOptions {
    /** Set false to leave the element where it is. */
    enabled?: boolean;
    /**
     * Whether this element is the one that should get out of the keyboard's way.
     *
     * Defaults to true, which suits a composer or a toolbar: it rides the
     * keyboard whatever is focused. A *field* wants the opposite — pass its own
     * focus state, or every field on the screen lifts whenever any one of them
     * is tapped, and they all arrive at the same place on top of each other.
     */
    active?: boolean;
    /**
     * `lift` moves an in-flow element by its overlap with the keyboard and
     * tracks it as the page scrolls. `dock` travels with the keyboard outright,
     * for an element already pinned to the bottom edge.
     */
    mode?: KeyboardAvoidanceMode;
    /** Gap to keep between the element's bottom edge and the keyboard. `lift` only. */
    offset?: number;
    /**
     * How far above the bottom edge the element already sits — usually the safe
     * area inset it is offset by. Subtracted from the travel, since the keyboard
     * covers that strip too. `dock` only.
     */
    bottomInset?: number;
}
export interface UseKeyboardAvoidanceResult {
    /** Attach to the element that should stay visible. */
    ref: AnimatedRef<ViewRef>;
    /** Attach to the same element, so a re-layout at rest cannot leave it offset. */
    onLayout: (event: LayoutChangeEvent) => void;
    /** Apply to the same element. */
    animatedStyle: ReturnType<typeof useAnimatedStyle<ViewStyle>>;
}
/** True when the keyboard controller is driving this, rather than the fallback. */
export declare function hasKeyboardController(): boolean;
export declare function useKeyboardAvoidance({ enabled, active, mode, offset, bottomInset, }?: UseKeyboardAvoidanceOptions): UseKeyboardAvoidanceResult;
//# sourceMappingURL=use-keyboard-avoidance.d.ts.map