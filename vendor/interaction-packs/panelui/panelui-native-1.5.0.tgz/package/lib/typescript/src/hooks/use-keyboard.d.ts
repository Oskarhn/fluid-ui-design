export interface UseKeyboardResult {
    /** Height of the keyboard in px, or 0 when hidden. */
    height: number;
    isVisible: boolean;
}
/**
 * Keyboard height and visibility, on the JS thread.
 *
 * Use this when the value drives rendering — showing a hint, swapping a
 * layout. For *animating* against the keyboard, use Reanimated's
 * `useAnimatedKeyboard` instead: it runs on the UI thread and tracks the
 * keyboard frame-for-frame, where this fires once per show/hide.
 *
 * ```tsx
 * const { isVisible } = useKeyboard();
 * {isVisible ? null : <Footer />}
 * ```
 */
export declare function useKeyboard(): UseKeyboardResult;
//# sourceMappingURL=use-keyboard.d.ts.map