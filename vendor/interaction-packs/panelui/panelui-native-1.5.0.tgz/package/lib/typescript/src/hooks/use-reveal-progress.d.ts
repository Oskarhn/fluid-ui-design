import { type AnimatedRef, type SharedValue } from 'react-native-reanimated';
import type { ViewRef } from '../primitives/refs.js';
export interface UseRevealProgressOptions {
    /**
     * Where down the viewport the element's top sits when progress is `0`, as a
     * fraction of the viewport height. `0.9` starts it just before it appears.
     */
    start?: number;
    /**
     * Where down the viewport the element's bottom sits when progress reaches
     * `1`. Smaller values mean a longer scrub.
     */
    end?: number;
    /**
     * Drive the effect from a value of your own instead of from the scroll
     * position. Anything passed here is used as-is and nothing is measured.
     */
    progress?: SharedValue<number>;
    /** Set false to hold progress at `1`, as though the element had passed. */
    enabled?: boolean;
}
export interface UseRevealProgressResult {
    /** Attach to the element whose travel drives the effect. */
    ref: AnimatedRef<ViewRef>;
    /**
     * Attach to the same element. It is what says the element can be measured —
     * without it the effect still works, at the cost of a warning per frame for
     * every element that is mounted but not yet laid out.
     */
    onLayout: () => void;
    /** `0` before, `1` after, scrubbed between. */
    progress: SharedValue<number>;
}
export declare function useRevealProgress({ start, end, progress: external, enabled, }?: UseRevealProgressOptions): UseRevealProgressResult;
//# sourceMappingURL=use-reveal-progress.d.ts.map