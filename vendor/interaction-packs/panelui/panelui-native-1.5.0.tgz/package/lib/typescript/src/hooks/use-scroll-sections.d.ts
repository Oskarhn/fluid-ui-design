import type { LayoutChangeEvent, NativeScrollEvent, NativeSyntheticEvent } from 'react-native';
import { type SharedValue } from 'react-native-reanimated';
import type { ScrollViewRef } from '../primitives/refs.js';
export interface UseScrollSectionsOptions {
    /** Section ids, in the order they appear down the page. */
    ids: string[];
    /**
     * How far down the viewport the reading line sits, in pixels. Larger values
     * switch to the next section later.
     */
    offset?: number;
    /** How close to the bottom counts as "at the bottom", in pixels. */
    endThreshold?: number;
    /** Extra gap left above a section when scrolling to it. */
    scrollPadding?: number;
}
/**
 * Where the scroller is, as shared values.
 *
 * Written from the scroll handler on the JavaScript thread, which is where the
 * section tracking already runs — so they arrive at `scrollEventThrottle`
 * rather than every frame, and anything reading them should ease towards the
 * value rather than jumping to it.
 */
export interface ScrollSectionsPosition {
    /** Distance scrolled, in points. */
    offset: SharedValue<number>;
    /** Height of the visible area. */
    viewport: SharedValue<number>;
    /** Total height of the content. */
    content: SharedValue<number>;
}
export interface UseScrollSectionsResult {
    /** Attach to the ScrollView, so `scrollTo` has something to drive. */
    ref: React.RefObject<ScrollViewRef | null>;
    /** The section being read. */
    active: string | undefined;
    /**
     * The scroll position, for anything that needs how far through the page the
     * reader is rather than which part of it they are in.
     */
    scroll: ScrollSectionsPosition;
    /** Spread onto the ScrollView. */
    scrollProps: {
        onScroll: (event: NativeSyntheticEvent<NativeScrollEvent>) => void;
        onMomentumScrollEnd: () => void;
        onLayout: (event: LayoutChangeEvent) => void;
        onContentSizeChange: (width: number, height: number) => void;
        scrollEventThrottle: number;
    };
    /** `onLayout` for a section's wrapper: `onLayout={measure(id)}`. */
    measure: (id: string) => (event: LayoutChangeEvent) => void;
    /** Scroll a section to the top. Pass straight to a rail's `onValueChange`. */
    scrollTo: (id: string) => void;
}
export declare function useScrollSections({ ids, offset, endThreshold, scrollPadding, }: UseScrollSectionsOptions): UseScrollSectionsResult;
//# sourceMappingURL=use-scroll-sections.d.ts.map