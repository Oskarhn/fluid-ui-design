import { type SharedValue } from 'react-native-reanimated';
/** Milliseconds for a placeholder to dissolve once the data arrives. */
export declare const SKELETON_FADE = 220;
export interface UseSkeletonHandoffResult {
    /** True while the placeholder should render — through the fade, not just the wait. */
    mounted: boolean;
    /** The placeholder's opacity, `1` while loading and tweened to `0` after. */
    opacity: SharedValue<number>;
}
export declare function useSkeletonHandoff(loading: boolean, duration?: number): UseSkeletonHandoffResult;
//# sourceMappingURL=use-skeleton-handoff.d.ts.map