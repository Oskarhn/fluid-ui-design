/**
 * Icon set.
 *
 * Every glyph is a 24×24 stroked drawing, sized and coloured by the caller.
 * They exist so the library can draw its own chrome — chevrons, a close
 * button, a check inside a checkbox — without every consumer having to choose
 * an icon package before a Select will render.
 *
 * ## How a colour is resolved
 *
 * In one order, always: an explicit `color` prop, then the colour inherited
 * from an enclosing `IconColorProvider`, then the icon's own fallback.
 * Coloured surfaces such as Button provide the foreground that reads against
 * them, so an icon dropped into one follows the theme without the caller
 * hardcoding a hex — which is what breaks the moment the theme inverts.
 *
 * ## Weight
 *
 * `strokeWidth` defaults to 2 rather than to the drawing's own 1.5. The set is
 * drawn at 24 and used at 14–20, and a hairline that reads correctly at full
 * size thins to nothing at two thirds of it. A few glyphs carry their own
 * weight because they sit beside something they have to match: the check and
 * the bar inside a checkbox, the grip on a drag handle.
 *
 * ## Mirroring
 *
 * A glyph whose *meaning* is a horizontal direction mirrors in a right-to-left
 * subtree — the two side chevrons, the outward arrow, the send plane. Yoga
 * moves a chevron to the other end of its row but cannot turn the glyph
 * around, so without this an RTL list row ends up with a right-pointing
 * chevron on its left edge, pointing back at the text.
 *
 * Everything else is drawn once and left alone. The vertical axis does not
 * mirror, and an icon that is merely asymmetric — a magnifier, a pencil, a
 * play triangle — means the same thing either way round; flipping it would
 * only be a wrong drawing.
 *
 * A mirroring icon always carries a transform, identity included. Dropping the
 * prop leaves the last matrix the view was given in place, so a glyph mirrored
 * once stays mirrored when the direction flips back — the arrows in an app
 * that can switch direction at runtime end up pointing at the text one toggle
 * in, and never recover.
 *
 * ## The four drawn by hand
 *
 * Google, Facebook and Apple carry their own palettes, and a brand mark
 * repainted to match a surface is no longer the mark. `BadgeCheckIcon` is
 * two-tone by design — a solid badge with a check punched through it in a
 * second colour — and `checkColor` is a public prop that a single-colour
 * outline could only ignore. All four are drawn here rather than mapped.
 */
import { type ReactNode } from 'react';
import { type IconSvgElement } from '@hugeicons/react-native';
import { type SvgProps } from 'react-native-svg';
export interface IconProps extends SvgProps {
    /** Both dimensions — icons are always square. */
    size?: number;
    /** Overrides the inherited colour and the icon's own fallback. */
    color?: string;
    /** Line weight. Defaults to 2, or to the glyph's own where it has one. */
    strokeWidth?: number;
}
export declare function IconColorProvider({ color, children, }: {
    color: string | undefined;
    children: ReactNode;
}): import("react").JSX.Element;
/** The inherited icon colour, if a surface is providing one. */
export declare function useIconColor(): string | undefined;
/**
 * The defaults a glyph is drawn with when the caller passes nothing.
 * The second argument to `icon()`.
 */
export interface IconDefaults {
    /** Both dimensions at the size this glyph is normally drawn. */
    size: number;
    /** The colour used when neither a prop nor a provider supplies one. */
    color: string;
    /** Overrides `STROKE` for a glyph that has to match something beside it. */
    strokeWidth?: number;
    /** Whether the glyph's meaning is a horizontal direction. */
    flip?: boolean;
    /** Whether the glyph is a toggle that can be solid. See `ToggleIconProps`. */
    fillable?: boolean;
}
/**
 * Builds one icon from a glyph and the defaults it is normally drawn with.
 *
 * Exported so an app can add a glyph the set does not carry, and have it
 * behave exactly like the built-in icons: the same colour order (prop, then
 * `IconColorProvider`, then the default), the same line weight, the same
 * right-to-left mirror and the same `filled` toggle.
 *
 * ```tsx
 * import HgViewOffIcon from '@hugeicons/core-free-icons/ViewOffIcon';
 * import { icon } from 'panelui-native/icons';
 *
 * export const EyeOffIcon = icon(HgViewOffIcon, { size: 16, color: '#737373' });
 * ```
 *
 * A factory rather than seventy near-identical components: what varies between
 * them is data, and what does not — the colour order, the weight default, the
 * mirror, the fill toggle, the prop passthrough — is worth having in exactly
 * one place, where a fix reaches the whole set at once.
 */
export declare function icon(glyph: IconSvgElement, defaults: IconDefaults): ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
/** Another name for `icon()`, for code that prefers the `create` prefix. */
export declare const createIcon: typeof icon;
export declare const ChevronUpIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ChevronDownIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ChevronLeftIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ChevronRightIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ChevronsUpDownIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const EllipsisIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const MenuIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const XIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const SearchIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ArrowUpRightIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const PlusIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const MinusIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CheckIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CircleIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const GripVerticalIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const MaximizeIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const InfoIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CheckCircleIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const AlertTriangleIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ShieldAlertIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ShieldCheckIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const BellIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CalendarIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ClockIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const GlobeIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CompassIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CrosshairIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const BoldIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ItalicIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const HeadingIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ListIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ListOrderedIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ListChecksIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const QuoteIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CodeIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const PencilIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const KeyboardIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const FileIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const FolderIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const FolderOpenIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ImageIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const PaperclipIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CameraIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const VideoIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CameraSwitchIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const FlashIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const FlashOffIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const TimerIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const UploadIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const MicIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const AudioLinesIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const PlayIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const PauseIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const DownloadIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const PackageIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CopyIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const LinkIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ShareNodesIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const SendIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const SendArrowIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const TrashIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const RotateCcwIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const RotateCwIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
/** A square with an arrow turning round it — turn an image, rather than refresh. */
export declare const RotateSquareIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const RepeatIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const PlusSquareIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const EyeIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const LockIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const UnlockIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const StarIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const HeartIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const BookmarkIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const SparklesIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const MessageCircleIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CardIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const HeadsetIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const LifebuoyIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const HelpCircleIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const MailIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const CallIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const BugIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const BookIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const TicketIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ReceiptIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const SunIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const MoonIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ArrowUpIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
export declare const ArrowDownIcon: ({ size, color, strokeWidth, filled, style, ...props }: ToggleIconProps) => import("react").JSX.Element;
/**
 * The icons a post's action row is made of.
 *
 * These are the only ones in the set that take `filled`, and it is not a
 * stylistic choice: a like, a save and a vote are toggles, and the outline and
 * the solid are the two states of one control. Drawn as two different icons
 * they would swap shape under the finger; drawn as one that fills, the shape
 * stays put and only the inside changes.
 */
export interface ToggleIconProps extends IconProps {
    /** Solid rather than outlined — the on state of a like, a save, a vote. */
    filled?: boolean;
}
export interface BadgeCheckIconProps extends IconProps {
    /** The tick's colour when the rosette is solid. Defaults to white. */
    checkColor?: string;
}
/** Google "G", in the four official brand colours. */
export declare function GoogleIcon({ size, ...props }: Omit<IconProps, 'color'>): import("react").JSX.Element;
/** Facebook "f" mark. */
/** Facebook "f" mark. */
export declare function FacebookIcon({ size, ...props }: Omit<IconProps, 'color'>): import("react").JSX.Element;
/**
 * Apple mark. Monochrome by design, so unlike the other brand marks it does
 * follow the icon colour context — Apple's guidelines require it to match the
 * button's text colour.
 */
/**
 * Apple mark. Monochrome by design, so unlike the other brand marks it does
 * follow the icon colour context — Apple's guidelines require it to match the
 * button's text colour.
 */
export declare function AppleIcon({ size, color, ...props }: IconProps): import("react").JSX.Element;
/**
 * The verified rosette.
 *
 * Solid by default, unlike everything else here. A verification mark is a
 * claim about the account rather than a control, and an outlined one next to
 * an outlined like button reads as another thing you could press.
 */
export declare function BadgeCheckIcon({ size, color, checkColor, ...props }: BadgeCheckIconProps): import("react").JSX.Element;
//# sourceMappingURL=index.d.ts.map