import { type PressableProps } from 'react-native';
import type { ViewRef } from './refs.js';
export interface AnimatedPressableProps extends PressableProps {
    className?: string;
    /** Scale applied while pressed. Set to 1 to disable. Default 0.97. */
    pressScale?: number;
    /**
     * Opacity applied while pressed, as a fraction of the resting opacity. Set
     * to 1 to disable. Default 1.
     */
    pressOpacity?: number;
}
/**
 * Pressable with UI-thread press feedback (scale/opacity via Reanimated).
 * The shared base for every interactive PanelUI component.
 *
 * The animated style is applied after the `className` styles, so any key it
 * writes beats the same key from a class. That is why it writes `opacity` only
 * when the press actually fades: a component that dims itself when disabled
 * (`opacity-[0.64]`, or a caller's `disabled:opacity-50`) does it through the
 * class, and an animated `opacity: 1` at rest would undo it on every render.
 *
 * A pressable that does fade owns its opacity outright, so it reads the
 * resting value from `style` or `className` and fades from there rather than
 * from 1. Keep `pressOpacity` either 1 or not for the life of a component:
 * the style's keys follow it.
 */
export declare const AnimatedPressable: import("react").ForwardRefExoticComponent<AnimatedPressableProps & import("react").RefAttributes<ViewRef>>;
//# sourceMappingURL=animated-pressable.d.ts.map