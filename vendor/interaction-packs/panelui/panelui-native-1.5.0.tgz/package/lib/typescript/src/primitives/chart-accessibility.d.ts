import type { ViewProps } from 'react-native';
/**
 * The largest text scale a chart's axis labels follow: iOS's biggest size before
 * the accessibility range. Axis labels sit in fixed-width gutters at fixed
 * steps, so past this they overlap each other or clip. Screen readers still get
 * every value through the chart's accessibility data.
 */
export declare const CHART_AXIS_MAX_FONT_SCALE = 1.353;
export interface ChartAccessibilityProps<Datum> extends Pick<ViewProps, 'accessibilityLabel' | 'accessibilityHint'> {
    /** Overrides the spoken label for one data entry. */
    accessibilityLabelForDatum?: (datum: Datum, index: number) => string;
    /** Makes each data entry actionable without making the SVG geometry focusable. */
    onAccessibilityDatumPress?: (datum: Datum, index: number) => void;
}
export interface ChartAccessibilityItem<Datum> {
    datum: Datum;
    index: number;
    label: string;
}
/** Pure semantic projection, shared by tests and the native accessibility tree. */
export declare function chartAccessibilityModel<Datum>(chart: string, data: Datum[], valueOf: (datum: Datum) => [string, unknown][], labelForDatum?: (datum: Datum, index: number) => string): {
    summary: string;
    items: ChartAccessibilityItem<Datum>[];
};
export interface ChartAccessibilityDataProps<Datum> extends ChartAccessibilityProps<Datum> {
    chart: string;
    data: Datum[];
    valueOf: (datum: Datum) => [string, unknown][];
    disabled?: boolean;
}
/**
 * A compact semantic sibling to the visual plot. The SVG remains one
 * decorative subtree while screen readers receive one summary and one entry
 * per datum, rather than every path, grid line and marker.
 */
export declare function ChartAccessibilityData<Datum>({ chart, data, valueOf, disabled, accessibilityLabel, accessibilityHint, accessibilityLabelForDatum, onAccessibilityDatumPress, }: ChartAccessibilityDataProps<Datum>): import("react").FunctionComponentElement<Omit<ViewProps, "ref"> & {
    ref?: React.Ref<import("react-native").ViewInstance> | undefined;
}> | null;
//# sourceMappingURL=chart-accessibility.d.ts.map