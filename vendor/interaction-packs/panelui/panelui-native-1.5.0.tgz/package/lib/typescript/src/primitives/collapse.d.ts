/**
 * Collapse — a body that opens and closes by animating its own height.
 *
 * Height cannot be animated from `auto`, so the content is measured first and
 * the measurement is what gets animated to. While that is happening the content
 * is taken out of the flow, because a child of a view whose height is
 * mid-animation reports that animated height back and the panel then settles on
 * whatever it happened to measure.
 *
 * The moment the animation finishes, both go away and the content lays out
 * normally again. That is what lets a Collapse hold another Collapse — or hold
 * content that is still streaming in — without either of them being clipped to
 * a number that was true a frame ago.
 *
 * ```tsx
 * <Collapse open={open}>
 *   <Text>Anything, of any height.</Text>
 * </Collapse>
 * ```
 *
 * The alternative — unmounting the body and letting a layout transition on the
 * parent carry the change — is what `Accordion` does, and it is right when the
 * closed state should cost nothing. This is for a body that opens and closes
 * repeatedly and often while its content is still arriving, where remounting
 * would throw away scroll position and restart every animation inside it.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
/** Long enough to read as the panel opening, short enough not to be waited on. */
export declare const COLLAPSE_DURATION = 200;
export interface CollapseProps extends Omit<ViewProps, 'children'> {
    open: boolean;
    /** Classes on the measured content, not on the clipping frame. */
    className?: string;
    duration?: number;
    children?: ReactNode;
}
export declare function Collapse({ open, className, duration, children, ...props }: CollapseProps): import("react").JSX.Element;
export declare namespace Collapse {
    var displayName: string;
}
//# sourceMappingURL=collapse.d.ts.map