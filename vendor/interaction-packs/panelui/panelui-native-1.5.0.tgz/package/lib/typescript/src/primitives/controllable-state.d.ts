import { type Dispatch, type SetStateAction } from 'react';
export interface ControllableStateOptions<T> {
    /** Accepted owner state. `undefined` selects uncontrolled ownership. */
    value: T | undefined;
    /** Initial state used only while uncontrolled. */
    defaultValue: T;
    /** Reports a distinct requested value exactly once per setter invocation. */
    onChange?: (value: T) => void;
    /** Reports accepted state changes, whether requested or externally reset. */
    onSettled?: (value: T) => void;
    /** Normalize defaults, controlled values, and requests through one boundary. */
    normalize?: (value: T) => T;
    /** Equality used for no-op requests and accepted settlement. */
    isEqual?: (left: T, right: T) => boolean;
    /** Stable semantic identity for controlled objects recreated by their owner. */
    getValueKey?: (value: T) => unknown;
}
export interface ControllableStateResult<T> {
    /** State accepted by the current owner; controlled requests never render optimistically. */
    value: T;
    setValue: Dispatch<SetStateAction<T>>;
    isControlled: boolean;
}
/**
 * Owner-driven controlled/uncontrolled state with an explicit settlement edge.
 *
 * Switching from controlled to uncontrolled retains the last accepted owner
 * value instead of resurrecting a stale default. Switching into controlled
 * mode adopts the prop immediately. `undefined` is the ownership sentinel and
 * therefore cannot itself be a controlled value; use `null` for empty state.
 */
export declare function useControllableState<T>({ value: valueProp, defaultValue, onChange, onSettled, normalize, isEqual, getValueKey, }: ControllableStateOptions<T>): ControllableStateResult<T>;
//# sourceMappingURL=controllable-state.d.ts.map