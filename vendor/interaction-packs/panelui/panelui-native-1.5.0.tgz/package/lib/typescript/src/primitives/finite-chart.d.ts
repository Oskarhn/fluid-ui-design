/** Returns a number only when it is safe to use in chart arithmetic. */
export declare function finiteChartNumber(value: unknown): number | undefined;
/** Accepts an explicit domain only when both ends are finite. */
export declare function finiteChartDomain(domain: readonly [number, number] | undefined): [number, number] | undefined;
//# sourceMappingURL=finite-chart.d.ts.map