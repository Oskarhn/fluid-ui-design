interface FocusDocument {
    activeElement?: FocusTarget | null;
    body?: FocusTarget | null;
    documentElement?: FocusTarget | null;
}
interface FocusTarget {
    disabled?: boolean;
    isConnected?: boolean;
    focus: (options?: {
        preventScroll?: boolean;
    }) => void;
    getAttribute?: (name: string) => string | null;
}
type RestoreFocus = () => boolean;
/** Restores nested overlays in last-opened order, even when parents close first. */
export declare class FocusRestorationStore {
    private owners;
    acquire(owner: string, restore: RestoreFocus): (() => void);
    private restoreReleasedOwners;
}
/** Captures the current browser focus without evaluating DOM APIs on native. */
export declare function captureFocusRestore(document?: FocusDocument | undefined): RestoreFocus;
export {};
//# sourceMappingURL=focus-restoration-store.d.ts.map