import { type ViewProps } from 'react-native';
import type { ViewRef } from './refs.js';
/** How the material treats what is behind it. */
export type GlassVariant = 'regular' | 'clear';
/**
 * Corner radius in points — one number for all four, or a top and a bottom.
 *
 * The two-sided form is for a surface with an edge that is not a real edge: a
 * sheet docked to the bottom of the screen rounds its top and leaves its
 * bottom square, because the screen edge is where it ends.
 */
export type GlassRadius = number | {
    top?: number;
    bottom?: number;
};
/**
 * True when the real material can be drawn — for a caller that wants to know
 * before it commits to a look. It says nothing about Reduce Transparency, which
 * is a live preference and belongs to the hook.
 */
export declare const hasGlass: boolean;
/**
 * Whether the material will actually be drawn right now: the API is present
 * *and* the user has not switched Reduce Transparency on.
 *
 * For a component that changes shape around the material — dropping a fill, a
 * border or a shadow the glass replaces — so that it makes the same decision
 * `Glass` makes and never strips the fill while leaving nothing behind it.
 */
export declare function useGlassMaterial(): boolean;
export interface GlassProps extends ViewProps {
    /**
     * How much of what is behind shows through. `regular` is the everyday
     * material; `clear` is thinner, for something over its own artwork.
     */
    variant?: GlassVariant;
    /** Tints the material. Takes a colour, not a token name. */
    tint?: string;
    /**
     * Corner radius in points. The material rounds itself to this, so give it
     * the same shape the container is drawn with — clipping a square material
     * to a rounded parent throws away the lit edge that makes it read as glass.
     */
    radius?: GlassRadius;
    /**
     * Let the material answer touch the way the platform's own controls do:
     * it brightens and swells under the finger and the highlight follows it.
     *
     * For a material that *is* a button. The platform only tracks touches that
     * land inside the glass view, so with this on the content is hosted inside
     * the material rather than above it — a pressable written as a child still
     * gets its press, and the glass reacts to the same touch.
     */
    interactive?: boolean;
    /** Applied only when the material cannot be drawn. Give it a real surface. */
    fallbackClassName?: string;
    className?: string;
}
export declare function Glass({ variant, tint, radius, interactive, fallbackClassName, className, children, style, ...props }: GlassProps): import("react").JSX.Element;
export declare namespace Glass {
    var displayName: string;
}
export interface GlassContainerProps extends ViewProps {
    /**
     * How close two pieces of glass have to be before they merge, in points.
     * Inside it their edges flow into one another; a piece moving past
     * another blends with it and pulls free as it leaves.
     */
    spacing?: number;
    className?: string;
}
/**
 * Lets the glass inside it merge.
 *
 * On its own each piece of the material is a separate object with its own
 * lit edge. Inside a container, pieces within `spacing` of each other flow
 * together — which is what makes a button that opens into other buttons look
 * like one thing dividing rather than several things arriving. A plain view
 * wherever the material is not drawn, so it can be written unconditionally.
 */
export declare const GlassContainer: import("react").ForwardRefExoticComponent<GlassContainerProps & import("react").RefAttributes<ViewRef>>;
//# sourceMappingURL=glass.d.ts.map