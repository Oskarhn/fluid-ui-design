/** Tracks modal owners without unisolating the app while a nested modal remains. */
export declare class ModalIsolationStore {
    private owners;
    private listeners;
    acquire: (owner: string) => (() => void);
    subscribe: (listener: () => void) => (() => void);
    getSnapshot: () => boolean;
    private emit;
}
//# sourceMappingURL=modal-isolation-store.d.ts.map