import type { ReactNode } from 'react';
/** One portal's content, and whether it is on its way out. */
export interface PortalEntry {
    node: ReactNode;
    /**
     * Set for the one frame between the owner going away and the content being
     * removed. The host stops the entry taking touches while it is set.
     */
    leaving: boolean;
}
export type PortalMap = ReadonlyMap<string, PortalEntry>;
/** Runs `callback` on a later frame and returns a function that cancels it. */
export type PortalScheduler = (callback: () => void) => () => void;
/**
 * What every portal has put on screen, keyed by portal.
 *
 * Removal takes two commits rather than one. An overlay's views usually carry
 * an `exiting` animation, and Reanimated keeps a removed view on screen until
 * that animation ends. The view keeps the props it had when it was removed but
 * not its handlers, so a full-screen backdrop left fading out takes every touch
 * and does nothing with it: a tap on the button that opened the overlay is
 * simply lost. So `unmount` first marks the entry `leaving`, which the host
 * turns into `pointerEvents="none"`, and removes it a frame later. Whatever
 * stays behind to animate has already stopped taking touches.
 */
export declare class PortalStore {
    private portals;
    private snapshot;
    private listeners;
    private pending;
    private schedule;
    constructor(schedule?: PortalScheduler);
    mount: (key: string, node: ReactNode) => void;
    unmount: (key: string) => void;
    subscribe: (listener: () => void) => () => void;
    getSnapshot: () => PortalMap;
    private cancel;
    private emit;
}
//# sourceMappingURL=portal-store.d.ts.map