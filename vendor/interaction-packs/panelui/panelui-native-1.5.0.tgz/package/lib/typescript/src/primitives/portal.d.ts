import { type ReactNode } from 'react';
export declare function PortalProvider({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
/** Renders children into the nearest PortalHost (above everything else). */
export declare function Portal({ children }: {
    children: ReactNode;
}): null;
/** A portal that owns modal focus until it unmounts. */
export declare function ModalPortal({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
/** A non-isolating portal that returns browser focus to what opened it. */
export declare function FocusRestorePortal({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
/** Whether any modal portal currently owns focus. */
export declare function useModalIsolationActive(): boolean;
/** Mount point for portaled content. PanelUIProvider renders one automatically. */
export declare function PortalHost(): import("react").JSX.Element;
//# sourceMappingURL=portal.d.ts.map