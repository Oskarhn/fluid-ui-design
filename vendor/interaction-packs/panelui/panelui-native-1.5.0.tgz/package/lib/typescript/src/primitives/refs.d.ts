import type { ComponentRef } from 'react';
import type { FlatListProps, ScrollView, Text, TextInput, TextInputProps, View } from 'react-native';
/** What a ref on a `View`-rooted component points at. */
export interface ViewRef extends ComponentRef<typeof View> {
}
/** What a ref on a `Text`-rooted component points at. */
export interface TextRef extends ComponentRef<typeof Text> {
}
/** What a ref on a `TextInput`-rooted component points at: `focus()`, `clear()`, `isFocused()`. */
export interface TextInputRef extends ComponentRef<typeof TextInput> {
}
/** What a ref on a `ScrollView` points at: `scrollTo`, `scrollToEnd`, `flashScrollIndicators`. */
export interface ScrollViewRef extends ComponentRef<typeof ScrollView> {
}
/** The event `TextInput`'s `onKeyPress` receives. */
export type KeyPressEvent = Parameters<NonNullable<TextInputProps['onKeyPress']>>[0];
/** The event `TextInput`'s `onSubmitEditing` receives. */
export type SubmitEditingEvent = Parameters<NonNullable<TextInputProps['onSubmitEditing']>>[0];
/** The event `TextInput`'s `onSelectionChange` receives. */
export type SelectionChangeEvent = Parameters<NonNullable<TextInputProps['onSelectionChange']>>[0];
/** The event `TextInput`'s `onContentSizeChange` receives. */
export type ContentSizeChangeEvent = Parameters<NonNullable<TextInputProps['onContentSizeChange']>>[0];
/** One entry of what a list reports as visible. */
export type ViewTokenOf<T> = Parameters<NonNullable<FlatListProps<T>['onViewableItemsChanged']>>[0]['viewableItems'][number];
//# sourceMappingURL=refs.d.ts.map