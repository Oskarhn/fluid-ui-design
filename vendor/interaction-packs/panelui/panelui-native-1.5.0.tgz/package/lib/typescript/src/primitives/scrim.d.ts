/**
 * Scrim — the layer behind an overlay.
 *
 * An overlay needs the screen behind it to recede. There are two honest ways to
 * do that: dim it, or blur it. Dimming is free and always works; blurring reads
 * as more physical — the content behind stays legible as shape and colour while
 * losing its detail — but it needs a native view to do it.
 *
 * `expo-blur` is resolved lazily and only when `blur` is asked for, so a project
 * that never blurs anything installs nothing. When it is asked for and the
 * package is missing, this falls back to a dim rather than failing: a blur you
 * cannot draw is better shown as a darkened screen than as a crash.
 * Reduce Transparency replaces the blur with an opaque, tint-aware surface.
 *
 * It fills its parent and does not intercept touches itself — the overlay layers
 * its own dismiss `Pressable` over it — so it is purely the visual backdrop.
 */
import { type ComponentType, type Ref, type RefObject } from 'react';
import { View, type ViewProps } from 'react-native';
import { type DerivedValue } from 'react-native-reanimated';
type BlurTint = 'light' | 'dark' | 'default' | 'systemMaterial';
/** True when a real blur can be drawn — for a caller that wants to know. */
export declare const hasBlur: boolean;
/**
 * `expo-blur`'s BlurTargetView, or null when the installed version has none.
 *
 * Android cannot blur whatever happens to be behind a view. It blurs one view
 * it has been pointed at, and that view has to be a BlurTargetView wrapping
 * the content. A component that owns the content passing under its blur — a
 * scroller under a header — wraps it in one and hands the ref to the blur.
 */
export declare const BlurTargetView: ComponentType<ViewProps & {
    ref?: Ref<View>;
}> | null;
/**
 * Whether this device can draw a blur at all, given a target on Android. The
 * Android blur is held to API 31 and later, where it runs on the GPU; below
 * that it costs every frame of a scroll, and a component falls back to its
 * plain surface instead.
 */
export declare const canBlurHere: boolean;
/**
 * The extra props a BlurView needs to blur on Android: the method, and the
 * target it samples. Empty on every other platform, where the blur reads
 * whatever is behind it.
 */
export declare function androidBlurProps(target: RefObject<View | null> | null | undefined): {
    blurMethod?: undefined;
    blurTarget?: undefined;
} | {
    blurMethod: "dimezisBlurViewSdk31Plus";
    blurTarget: RefObject<((props: Omit<ViewProps, "ref"> & {
        ref?: React.Ref<import("react-native").ViewInstance> | undefined;
    }) => React.ReactNode) | null>;
};
/**
 * Whether the device asks for Reduce Transparency: `true`, `false`, or `null`
 * while the platform has not answered yet. Exported because every material in
 * the library has to respect the same preference, and two copies of this would
 * be two answers.
 */
export declare function useReduceTransparency(): boolean | null;
export interface ScrimProps extends Omit<ViewProps, 'children'> {
    /**
     * Frost the backdrop instead of dimming it. Falls back to a dim where it
     * can't: without `expo-blur`, and on Android, where an overlay has no view
     * of the app behind it to point a blur at.
     */
    blur?: boolean;
    /** Blur strength, 0–100. */
    intensity?: number;
    /** Which way the blur tints. */
    tint?: BlurTint;
    /**
     * The dim used when not blurring, when blur is unavailable, and over the
     * opaque Reduce Transparency fallback. A popover passes a lighter one than a dialog.
     */
    dimClassName?: string;
    /**
     * How far the backdrop is in, from `0` to `1`, read on the UI thread.
     *
     * For an overlay the finger can pull partway out — a viewer dragged towards
     * dismissal — where the backdrop has to follow the finger instead of running
     * its own fade. The blur's radius tracks it, and the dim and the opaque
     * fallback track it as opacity. Left out, the scrim fades itself in and out.
     */
    progress?: DerivedValue<number>;
}
export declare function Scrim({ blur, intensity, tint, dimClassName, progress, style, ...props }: ScrimProps): import("react").JSX.Element;
export declare namespace Scrim {
    var displayName: string;
}
export {};
//# sourceMappingURL=scrim.d.ts.map