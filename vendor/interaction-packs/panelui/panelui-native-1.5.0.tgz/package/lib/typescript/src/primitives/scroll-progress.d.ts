/**
 * ScrollProgress — publishes a scroll container's position so children can
 * animate against it.
 *
 * Scroll-driven effects all need the same two numbers: where the scroller is,
 * and how tall its viewport is. Every component that wanted them measuring for
 * itself would mean one scroll listener per effect and one measurement pass per
 * effect per frame, for two values that are the same for all of them.
 *
 * It wraps the scroll view you already have rather than replacing it — the
 * child is cloned with an animated scroll handler composed onto it, the same
 * way `ScrollFade` does — so a `FlatList`, a `SectionList` or your own
 * scrollable all work, and nothing has to be rewritten to adopt it.
 *
 * ```tsx
 * <ScrollProgress>
 *   <ScrollView>
 *     <ScrollText>…</ScrollText>
 *   </ScrollView>
 * </ScrollProgress>
 * ```
 *
 * Both values are shared values, so the whole chain from scroll event to
 * animated style stays on the UI thread and nothing re-renders as you scroll.
 */
import { type ReactNode } from 'react';
import { type ViewProps } from 'react-native';
import { type SharedValue } from 'react-native-reanimated';
export interface ScrollProgressValue {
    /** Distance scrolled, in pixels. */
    offset: SharedValue<number>;
    /** Height of the visible area. */
    viewport: SharedValue<number>;
    /** Total height of the content. */
    content: SharedValue<number>;
    /**
     * Window-space top edge of the scroller. What turns an element's measured
     * `pageY` into a position inside *this* viewport rather than the screen's —
     * they differ by whatever sits above the scroller, and assuming they do not
     * is why scroll effects drift under a header.
     */
    top: SharedValue<number>;
}
/**
 * The nearest enclosing scroll container's position, or `null` outside one.
 *
 * It returns null rather than throwing because every consumer of this also
 * takes an explicit `progress` prop — a component that can be driven by hand
 * should not insist on a provider it does not need.
 */
export declare function useScrollProgress(): ScrollProgressValue | null;
export interface ScrollProgressProps extends ViewProps {
    className?: string;
    /** Exactly one scrollable — a ScrollView, FlatList, or anything like them. */
    children?: ReactNode;
}
export declare function ScrollProgress({ className, children, ...props }: ScrollProgressProps): import("react").JSX.Element;
export declare namespace ScrollProgress {
    var displayName: string;
}
//# sourceMappingURL=scroll-progress.d.ts.map