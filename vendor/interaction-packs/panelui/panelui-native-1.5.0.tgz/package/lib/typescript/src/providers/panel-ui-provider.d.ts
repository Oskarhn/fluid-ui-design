import { type ReactNode } from 'react';
export interface PanelUIProviderProps {
    children: ReactNode;
    /**
     * Classes for the themed page surface. Defaults to `bg-background`, which
     * follows the active theme. Pass your own to change the page colour.
     */
    className?: string;
    /**
     * Set to false to render without the themed page background — do this only
     * if you paint the app background yourself.
     */
    background?: boolean;
    /**
     * Tell the keyboard controller that the Android status bar is translucent,
     * so it measures the keyboard against the right window inset.
     *
     * Reach for it only where the app draws under the status bar without being
     * edge-to-edge. Under edge-to-edge — the default from Expo SDK 54 — the
     * controller detects that for itself and this is ignored, so leave it unset
     * there rather than passing `false`: a value it has to ignore is a warning
     * in development.
     *
     * Android only, and inert without `react-native-keyboard-controller`.
     */
    statusBarTranslucent?: boolean;
    /**
     * The same, for a translucent Android navigation bar.
     *
     * Android only, and inert without `react-native-keyboard-controller`.
     */
    navigationBarTranslucent?: boolean;
}
/**
 * Root provider for PanelUI. Owns three things:
 * the gesture handler root, the themed page background, and the portal host
 * used by overlay components (Dialog, BottomSheet, Select).
 *
 * The background lives here because native wrappers like SafeAreaView do not
 * accept `className` — putting `bg-background` on one silently does nothing,
 * leaving the page unthemed while its children follow the theme.
 *
 * Theme switching is handled natively by Uniwind — use the `useTheme()` hook
 * exported from panelui-native.
 */
export declare function PanelUIProvider({ children, className, background, statusBarTranslucent, navigationBarTranslucent, }: PanelUIProviderProps): import("react").JSX.Element;
//# sourceMappingURL=panel-ui-provider.d.ts.map