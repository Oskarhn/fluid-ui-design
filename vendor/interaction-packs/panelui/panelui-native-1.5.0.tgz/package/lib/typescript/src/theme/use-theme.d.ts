/** Themes shipped in `panelui-native/theme.css`. */
export type PanelTheme = 'light' | 'dark' | 'moon' | 'moon-dark' | 'grass' | 'grass-dark';
export type ThemeName = PanelTheme | 'system';
/** Light/dark mode within a theme family. */
export type ThemeMode = 'light' | 'dark';
/** A theme family — one look, in its light and dark form. */
export interface PanelThemeFamily {
    /** Stable id, e.g. `'moon'`. */
    id: string;
    /** Short display name, for a theme picker. */
    name: string;
    light: PanelTheme;
    dark: PanelTheme;
    /** Representative colour for a swatch, as `[light, dark]`. */
    swatch: [string, string];
}
/**
 * The theme families PanelUI ships. Each sets its own palette *and* its own
 * radius scale, so switching family changes the shape of the UI as well as
 * its colour — Panel is the default, Moon is sharp and monochrome,
 * Grass is soft and green.
 *
 * Everything beyond `panel` must be registered in your metro config, or
 * `setTheme` throws "it was not registered":
 *
 * ```js
 * withUniwindConfig(config, {
 *   cssEntryFile: './src/global.css',
 *   extraThemes: ['moon', 'moon-dark', 'grass', 'grass-dark'],
 * });
 * ```
 */
export declare const PANEL_THEMES: readonly PanelThemeFamily[];
/** Every concrete theme name, in registration order. */
export declare const PANEL_THEME_NAMES: readonly PanelTheme[];
/** The names to pass as `extraThemes` in your metro config. */
export declare const PANEL_EXTRA_THEMES: readonly string[];
/**
 * Applies a theme, and tells the operating system which side of light and dark
 * it is on.
 *
 * Uniwind keeps the system appearance in step only for `light` and `dark`.
 * Every other name resets it to the device's own setting, so `grass-dark` on a
 * phone set to Light leaves everything the system draws — the native tab bar,
 * alerts, action sheets, the keyboard — in light. The correction runs in the
 * same tick as the theme change, so no frame is drawn with the two disagreeing.
 *
 * `system` is left alone: pinning the appearance there would stop the app
 * hearing about the device changing.
 */
declare function applyTheme(name: ThemeName): void;
/**
 * Sets the theme from outside React — at module scope before the app mounts,
 * from a deep link, or from a settings store.
 *
 * Use this rather than calling `Uniwind.setTheme` directly: it is the same
 * change, plus the system appearance that a named theme needs to match.
 * `useTheme` and `useThemeMode` go through it too.
 *
 * ```ts
 * // app/_layout.tsx, before the root component
 * PanelUITheme.setTheme('grass-dark');
 * ```
 */
export declare const PanelUITheme: {
    readonly setTheme: typeof applyTheme;
};
/**
 * Reactive access to the current Uniwind theme plus a setter.
 * Theme changes are applied natively by Uniwind without re-rendering the tree.
 */
export declare function useTheme(): {
    /** The active theme name, e.g. `'dark'` or `'moon-dark'`. */
    theme: PanelTheme;
    /** Switch theme by name, or `'system'` to follow the device. */
    setTheme: typeof applyTheme;
};
/**
 * Theme family and light/dark mode as two separate axes — what a picker like
 * "choose a brand, then toggle the sun" actually needs.
 *
 * Named themes are not adaptive in Uniwind, so each brand ships as a
 * light/dark pair. Toggling the mode keeps the current family, so a user in
 * Moon dark lands in Moon light rather than the default theme.
 *
 * ```tsx
 * const { family, mode, setFamily, toggleMode } = useThemeMode();
 * ```
 */
export declare function useThemeMode(): {
    /** The active theme family. */
    family: PanelThemeFamily;
    /** `'light'` or `'dark'` within that family. */
    mode: ThemeMode;
    /** Switch brand, staying in the current light/dark mode. */
    setFamily: (id: string) => void;
    /** Set the mode, staying in the current family. */
    setMode: (next: ThemeMode) => void;
    /** Flip light ↔ dark within the current family. */
    toggleMode: () => void;
};
export {};
//# sourceMappingURL=use-theme.d.ts.map