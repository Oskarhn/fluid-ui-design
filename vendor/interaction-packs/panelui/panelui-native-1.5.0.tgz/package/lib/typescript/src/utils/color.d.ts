/**
 * Colour arithmetic, in the model a picker is shaped like.
 *
 * A picker's controls *are* HSV: a square of saturation against brightness
 * under one hue, with the hue itself on a separate scale. Storing anything
 * else means converting on every frame of a drag and, worse, losing the
 * position of the thumb — a fully black colour is `#000` whatever its hue and
 * saturation were, so a round trip through RGB throws away where the finger
 * was. HSV is kept as the truth and everything here converts *out* of it.
 *
 * Every function is a worklet. The drag never leaves the UI thread, so the
 * hue behind the square, the thumb fill and the preview swatch all need these
 * on the same frame the finger moved, and a JS-only helper would put a bridge
 * hop in the middle of that.
 */
/** A colour in the model the picker stores: hue, saturation, value, alpha. */
export interface HsvaColor {
    /** Hue in degrees, `0`–`360`. */
    h: number;
    /** Saturation, `0`–`1`. */
    s: number;
    /** Value — brightness — `0`–`1`. */
    v: number;
    /** Alpha, `0`–`1`. */
    a: number;
}
/** How a colour is written when it leaves the picker. */
export type ColorFormat = 'hex' | 'rgb' | 'hsl';
/** HSV to 8-bit RGB. */
export declare function hsvToRgb(h: number, s: number, v: number): {
    r: number;
    g: number;
    b: number;
};
/** 8-bit RGB to HSV. Hue is undefined for a grey, and comes back as `0`. */
export declare function rgbToHsv(r: number, g: number, b: number): {
    h: number;
    s: number;
    v: number;
};
/** HSV to HSL, for `format="hsl"`. Both are cylinders; only the axis differs. */
export declare function hsvToHsl(h: number, s: number, v: number): {
    h: number;
    s: number;
    l: number;
};
/**
 * An `rgba()` string, which is what a style wants. Used for every animated
 * fill in the picker, so it stays cheap: no allocation beyond the string, and
 * no branch on the alpha.
 */
export declare function hsvToCss(h: number, s: number, v: number, a?: number): string;
/**
 * A `#rrggbb` string, gaining a `#rrggbbaa` alpha pair only when the colour is
 * actually translucent — an opaque colour written with a trailing `ff` is the
 * same colour spelled in a way half the CSS parsers in the world reject.
 */
export declare function hsvToHex(h: number, s: number, v: number, a?: number): string;
/** Writes a stored colour out in one of the three formats a consumer asks for. */
export declare function formatColor(color: HsvaColor, format?: ColorFormat): string;
/**
 * Reads `#rgb`, `#rgba`, `#rrggbb`, `#rrggbbaa`, `rgb()`, `rgba()`, `hsl()`
 * and `hsla()`, and returns `null` for anything else — including the named
 * colours, which would mean shipping a lookup table of 148 words to parse a
 * string a caller almost never writes.
 *
 * `null` rather than a thrown error or a silent black: a picker handed a value
 * it cannot read should keep the one it has, and only a distinguishable "no"
 * lets the caller do that.
 */
export declare function parseColor(input: string): HsvaColor | null;
/** Whether `parseColor` can read this string. */
export declare function isValidColor(input: string): boolean;
//# sourceMappingURL=color.d.ts.map