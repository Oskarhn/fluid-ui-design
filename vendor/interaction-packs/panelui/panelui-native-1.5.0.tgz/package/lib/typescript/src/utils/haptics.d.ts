/** Whether a haptic will actually be felt. */
export declare function hasHaptics(): boolean;
/**
 * The light tick for moving between options — a segmented control, a picker,
 * a section marker. Deliberately not an impact: selection is the lightest of
 * the feedbacks, and anything heavier gets tiring when it fires on scroll.
 *
 * Fire-and-forget. A rejected haptic is not worth an unhandled rejection, and
 * there is nothing useful to do about one.
 */
export declare function selectionTick(): void;
/**
 * The knock for a thing coming loose or landing — a row lifted out of a list,
 * a card dropped into place.
 *
 * An impact rather than a selection because it marks a change of state rather
 * than a change of value: the finger is now holding something it was not
 * holding a moment ago, and the lightest feedback is not enough to say so.
 * `medium` is the one that reads as picking something up without reading as an
 * error.
 *
 * Falls back to a selection tick where the style constants are missing, and to
 * nothing at all where the package is.
 */
export declare function impactKnock(): void;
//# sourceMappingURL=haptics.d.ts.map