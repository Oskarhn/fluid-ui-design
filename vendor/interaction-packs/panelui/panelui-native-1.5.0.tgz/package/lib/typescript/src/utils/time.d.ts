/**
 * Time-of-day helpers for TimePicker.
 *
 * A time here is `{ hour, minute }` on a 24-hour clock, not a `Date`. A `Date`
 * cannot hold a time without also holding a day, so every caller with only a
 * time has to invent a date to carry it and strip it off again afterwards —
 * and the two conversions are where the daylight-saving bugs live. The pair of
 * numbers is the whole value, and `timeFromDate` / `timeToDate` are here for
 * the boundaries where a `Date` is genuinely what you have.
 *
 * Three rules hold throughout:
 *
 * - **`hour` is always 0–23**, whatever the picker is displaying. A 12-hour
 *   face is a rendering choice; storing 7pm as `{ hour: 7 }` with a separate
 *   meridiem flag means every comparison has to know about the flag.
 * - **Minutes wrap into hours, and hours wrap into the day.** Stepping forward
 *   from 23:45 gives 00:00, not 24:00, so arithmetic can never produce a time
 *   that does not exist.
 * - **Formatting goes through `Intl`, never through string concatenation.**
 *   Whether the meridiem is "PM", "pm" or absent entirely, and whether it
 *   leads or trails, belongs to the locale.
 */
/** A time of day. `hour` is 0–23 regardless of how it is displayed. */
export interface TimeValue {
    hour: number;
    minute: number;
}
/** Which face a time is written on. `24` drops the meridiem entirely. */
export type HourCycle = 12 | 24;
/** Minutes since midnight — the form every comparison here works in. */
export declare function timeToMinutes(value: TimeValue): number;
/** The inverse, wrapping into the day so the result is always a real time. */
export declare function minutesToTime(minutes: number): TimeValue;
/** Negative if `a` is earlier, positive if later, `0` if the same time. */
export declare function compareTime(a: TimeValue, b: TimeValue): number;
export declare function isSameTime(a: TimeValue | null | undefined, b: TimeValue | null | undefined): boolean;
/**
 * Holds a time inside a span, both ends inclusive and either one optional.
 *
 * Clamping rather than wrapping: a value outside the span is a value the
 * caller has been refused, and the nearest allowed time is the useful answer.
 */
export declare function clampTime(value: TimeValue, min?: TimeValue, max?: TimeValue): TimeValue;
export declare function isTimeInRange(value: TimeValue, min?: TimeValue, max?: TimeValue): boolean;
/**
 * Rounds a time to the nearest multiple of `step` minutes.
 *
 * Rounding, not flooring: at a 30-minute step, 7:29 is a finger that stopped
 * just short of half past rather than someone asking for seven o'clock.
 */
export declare function roundToStep(value: TimeValue, step: number): TimeValue;
/** Every time in the day at `step`-minute intervals, from midnight. */
export declare function timesOfDay(step: number): TimeValue[];
/** The hour as it is written on the face: 1–12, or 0–23. */
export declare function displayHour(hour: number, hourCycle: HourCycle): number;
/** Rebuilds a 0–23 hour from what the face shows and which half of the day. */
export declare function hourFromDisplay(displayed: number, meridiem: 'am' | 'pm', hourCycle: HourCycle): number;
export declare function meridiemOf(hour: number): 'am' | 'pm';
/**
 * The meridiem labels in the caller's locale, as `[am, pm]`.
 *
 * Read out of `Intl` rather than hardcoded, because "AM" is not universal —
 * and taken from the *parts* rather than from the formatted string, since
 * pulling it back out of "7:00 PM" means knowing where the locale puts it.
 */
export declare function meridiemLabels(locale?: string): [string, string];
/** Two digits, so a column of minutes is a column and not a ragged edge. */
export declare function padTwo(value: number): string;
export interface FormatTimeOptions {
    hourCycle?: HourCycle;
    locale?: string;
}
/**
 * One time as one line of text, in the caller's locale.
 *
 * Falls back to `H:MM` shapes if `Intl` is unavailable or throws on the tag —
 * a picker that renders nothing is worse than one that renders plainly.
 */
export declare function formatTime(value: TimeValue, { hourCycle, locale }?: FormatTimeOptions): string;
/** The time part of a `Date`, for callers whose value arrives as one. */
export declare function timeFromDate(date: Date): TimeValue;
/**
 * A time put back onto a day. Defaults to today, and seconds are zeroed —
 * a picker with no seconds column has no opinion about them, and carrying the
 * ones that happened to be on the clock makes two equal times unequal.
 */
export declare function timeToDate(value: TimeValue, day?: Date): Date;
//# sourceMappingURL=time.d.ts.map