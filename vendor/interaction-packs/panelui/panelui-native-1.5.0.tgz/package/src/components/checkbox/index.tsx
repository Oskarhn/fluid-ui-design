import { forwardRef, useEffect, type ReactNode } from 'react';
import { Pressable, View, type PressableProps } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { tv, type VariantProps } from 'tailwind-variants';
import { useCSSVariable } from 'uniwind';
import { CheckIcon, MinusIcon } from '../../icons';
import { Text } from '../../primitives/text';
import type { ViewRef } from '../../primitives/refs';

const checkboxVariants = tv({
  slots: {
    row: 'min-h-12 min-w-12 flex-row items-center gap-2.5',
    box: 'h-5 w-5 items-center justify-center rounded-md border border-input bg-background',
    fill: 'absolute inset-0 items-center justify-center rounded-md bg-primary',
    content: 'flex-1 gap-0.5',
    label: 'text-sm text-foreground',
    description: 'text-sm text-muted-foreground',
  },
  variants: {
    /*
     * The box, its tick and the text beside it move together. The row does
     * not: it stays 48 points tall at every size, because that is the touch
     * target and a smaller box is not a reason for a smaller one.
     *
     * Listed before `variant` so the card keeps the label weight it sets.
     */
    size: {
      xs: {
        row: 'gap-2',
        box: 'h-3.5 w-3.5 rounded-sm',
        fill: 'rounded-sm',
        label: 'text-xs',
        description: 'text-xs',
      },
      sm: {
        row: 'gap-2',
        box: 'h-4 w-4 rounded-sm',
        fill: 'rounded-sm',
        label: 'text-[13px]',
        description: 'text-xs',
      },
      md: {},
      lg: {
        row: 'gap-3',
        box: 'h-6 w-6',
        label: 'text-base',
      },
      xl: {
        row: 'gap-3',
        box: 'h-7 w-7 rounded-lg',
        fill: 'rounded-lg',
        label: 'text-lg',
        description: 'text-base',
      },
    },
    variant: {
      default: {},
      /**
       * The whole surface is the target — for pickable options where the
       * checkbox is a confirmation rather than the affordance itself.
       */
      card: {
        row: 'w-full items-start gap-3 rounded-xl border border-border bg-card p-4',
        label: 'text-base font-medium',
      },
    },
    checked: {
      true: {},
    },
    disabled: {
      true: { row: 'opacity-50' },
    },
  },
  compoundVariants: [
    {
      variant: 'card',
      checked: true,
      class: { row: 'border-primary bg-accent', label: 'text-accent-foreground' },
    },
  ],
  defaultVariants: {
    variant: 'default',
    size: 'md',
  },
});

/** How big a checkbox is. */
export type CheckboxSize = NonNullable<VariantProps<typeof checkboxVariants>['size']>;

/** The tick and the dash, sized to leave the same share of the box around them. */
const GLYPH_SIZE: Record<CheckboxSize, number> = { xs: 8, sm: 10, md: 12, lg: 14, xl: 16 };

export interface CheckboxProps
  extends VariantProps<typeof checkboxVariants>,
    Omit<
      PressableProps,
      | 'children'
      | 'disabled'
      | 'onPress'
      | 'style'
      | 'accessibilityRole'
      | 'accessibilityState'
    > {
  /**
   * Styles the pressable row — layout, border, fill. It does not reach the
   * label: text colour is not inherited from a view in React Native, so use
   * `labelClassName` for that.
   */
  className?: string;
  checked: boolean;
  onCheckedChange?: (checked: boolean) => void;
  /**
   * A third, in-between state for a box that governs a group of others — some
   * on, some off. It fills like a checked box but shows a dash rather than a
   * tick, and announces itself as `mixed` to a screen reader. Pressing it
   * resolves the ambiguity by turning the whole group on, so the press reports
   * `true`. `indeterminate` overrides `checked` for what is drawn.
   */
  indeterminate?: boolean;
  disabled?: boolean;
  /**
   * Optional label rendered next to the box; pressing it also toggles.
   *
   * A string is the usual case. Pass text nodes instead to put a link inside
   * the sentence — `<>I agree to the <Text onPress={open}>Terms</Text></>` —
   * and the link's own press wins over the toggle. A screen reader cannot
   * read a node as the checkbox's name, so pass `accessibilityLabel` with it.
   */
  label?: ReactNode;
  /** Classes for the label text, merged over the defaults — e.g. `text-black`. */
  labelClassName?: string;
  /**
   * Classes for the view holding the label and description, merged over
   * `flex-1 gap-0.5`. The default makes the text fill the row; pass
   * `flex-none` to size it to the text when the checkbox shares a line with
   * other content, such as a "Forgot password" link.
   */
  contentClassName?: string;
  /** Secondary line under the label, for extra context. */
  description?: string;
  /** Classes for the description text, merged over the defaults. */
  descriptionClassName?: string;
}

export const Checkbox = forwardRef<ViewRef, CheckboxProps>(
  (
    {
      className,
      checked,
      onCheckedChange,
      indeterminate,
      disabled,
      label,
      labelClassName,
      contentClassName,
      description,
      descriptionClassName,
      variant,
      size = 'md',
      accessibilityLabel,
      ...rest
    },
    ref
  ) => {
    // The dash and the tick share one fill, so the box is "on" for either —
    // what changes is the glyph, not whether the fill is shown.
    const on = checked || !!indeterminate;
    const progress = useSharedValue(on ? 1 : 0);
    const slots = checkboxVariants({ variant, size, checked: on, disabled: !!disabled });
    const checkColor = useCSSVariable('--color-primary-foreground');

    useEffect(() => {
      progress.value = on
        ? withSpring(1, { damping: 15, stiffness: 300, mass: 0.5 })
        : withTiming(0, { duration: 120 });
    }, [on, progress]);

    const fillStyle = useAnimatedStyle(() => ({
      opacity: progress.value,
      transform: [{ scale: 0.6 + progress.value * 0.4 }],
    }));

    const glyphColor = typeof checkColor === 'string' ? checkColor : '#fff';
    const box = (
      <View className={slots.box()}>
        <Animated.View style={fillStyle} className={slots.fill()}>
          {indeterminate ? (
            <MinusIcon size={GLYPH_SIZE[size]} color={glyphColor} />
          ) : (
            <CheckIcon size={GLYPH_SIZE[size]} color={glyphColor} />
          )}
        </Animated.View>
      </View>
    );

    return (
      <Pressable
        {...rest}
        ref={ref}
        accessibilityRole="checkbox"
        // `mixed` is the a11y state for a box that governs a partly-on group;
        // a plain boolean would tell a screen reader the group is fully one way.
        accessibilityState={{
          checked: indeterminate ? 'mixed' : checked,
          disabled: !!disabled,
        }}
        accessibilityLabel={
          accessibilityLabel ?? (typeof label === 'string' ? label : undefined)
        }
        accessibilityHint={description}
        disabled={disabled}
        // An indeterminate box resolves upward: the press turns the group on.
        onPress={() => onCheckedChange?.(indeterminate ? true : !checked)}
        // A description makes the row two lines tall — align the box to the
        // label rather than centring it against the whole block.
        className={slots.row({
          className:
            description && variant !== 'card'
              ? `items-start ${className ?? ''}`
              : className,
        })}
      >
        {/* The card lays out content first so the box sits top-right. */}
        {variant === 'card' ? null : box}
        {label || description ? (
          <View className={slots.content({ className: contentClassName })}>
            {label ? (
              <Text className={slots.label({ className: labelClassName })}>{label}</Text>
            ) : null}
            {description ? (
              <Text className={slots.description({ className: descriptionClassName })}>
                {description}
              </Text>
            ) : null}
          </View>
        ) : null}
        {variant === 'card' ? box : null}
      </Pressable>
    );
  }
);

Checkbox.displayName = 'Checkbox';
